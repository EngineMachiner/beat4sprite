local t = Def.ActorFrame{
	LoadActor("1.lua")..{
		OnCommand=cmd(addx,128;addy,192)
	};
	LoadActor("1.lua")..{
		OnCommand=cmd(addx,128;addy,96)
	};
	LoadActor("1.lua")..{
		OnCommand=cmd(addx,-128;addy,-192)
	};
	LoadActor("1.lua")..{
		OnCommand=cmd(addx,-128;addy,-96)
	};
	LoadActor("1.lua")..{
		OnCommand=cmd()
	};
};

return t;
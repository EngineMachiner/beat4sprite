local t = Def.ActorFrame{
		Def.Sprite{
		Texture = "1 5x1.png", 
		Frames = {{Delay= 0.25, Frame= 0}, {Delay= 0.25, Frame= 1}, {Delay= 0.25, Frame= 2}, {Delay= 0.25, Frame= 3}, {Delay= 0.25, Frame= 4}},
		OnCommand=cmd(x,124;y,116;effectclock,'beat')
	};
		Def.Sprite{
		Texture = "1 5x1.png", 
		Frames = {{Delay= 0.25, Frame= 0}, {Delay= 0.25, Frame= 1}, {Delay= 0.25, Frame= 2}, {Delay= 0.25, Frame= 3}, {Delay= 0.25, Frame= 4}},
		OnCommand=cmd(x,372;y,116;effectclock,'beat')
	};
		Def.Sprite{
		Texture = "1 5x1.png", 
		Frames = {{Delay= 0.25, Frame= 0}, {Delay= 0.25, Frame= 1}, {Delay= 0.25, Frame= 2}, {Delay= 0.25, Frame= 3}, {Delay= 0.25, Frame= 4}},
		OnCommand=cmd(x,620;y,116;effectclock,'beat')
	};
		Def.Sprite{
		Texture = "1 5x1.png", 
		Frames = {{Delay= 0.25, Frame= 0}, {Delay= 0.25, Frame= 1}, {Delay= 0.25, Frame= 2}, {Delay= 0.25, Frame= 3}, {Delay= 0.25, Frame= 4}},
		OnCommand=cmd(x,868;y,116;effectclock,'beat')
	};
		Def.Sprite{
		Texture = "1 5x1.png", 
		Frames = {{Delay= 0.25, Frame= 0}, {Delay= 0.25, Frame= 1}, {Delay= 0.25, Frame= 2}, {Delay= 0.25, Frame= 3}, {Delay= 0.25, Frame= 4}},
		OnCommand=cmd(x,124;y,348;effectclock,'beat')
	};
		Def.Sprite{
		Texture = "1 5x1.png", 
		Frames = {{Delay= 0.25, Frame= 0}, {Delay= 0.25, Frame= 1}, {Delay= 0.25, Frame= 2}, {Delay= 0.25, Frame= 3}, {Delay= 0.25, Frame= 4}},
		OnCommand=cmd(x,372;y,348;effectclock,'beat')
	};
		Def.Sprite{
		Texture = "1 5x1.png", 
		Frames = {{Delay= 0.25, Frame= 0}, {Delay= 0.25, Frame= 1}, {Delay= 0.25, Frame= 2}, {Delay= 0.25, Frame= 3}, {Delay= 0.25, Frame= 4}},
		OnCommand=cmd(x,620;y,348;effectclock,'beat')
	};
		Def.Sprite{
		Texture = "1 5x1.png", 
		Frames = {{Delay= 0.25, Frame= 0}, {Delay= 0.25, Frame= 1}, {Delay= 0.25, Frame= 2}, {Delay= 0.25, Frame= 3}, {Delay= 0.25, Frame= 4}},
		OnCommand=cmd(x,868;y,348;effectclock,'beat')
	};
		Def.Sprite{
		Texture = "1 5x1.png", 
		Frames = {{Delay= 0.25, Frame= 0}, {Delay= 0.25, Frame= 1}, {Delay= 0.25, Frame= 2}, {Delay= 0.25, Frame= 3}, {Delay= 0.25, Frame= 4}},
		OnCommand=cmd(x,124;y,580;effectclock,'beat')
	};
		Def.Sprite{
		Texture = "1 5x1.png", 
		Frames = {{Delay= 0.25, Frame= 0}, {Delay= 0.25, Frame= 1}, {Delay= 0.25, Frame= 2}, {Delay= 0.25, Frame= 3}, {Delay= 0.25, Frame= 4}},
		OnCommand=cmd(x,372;y,580;effectclock,'beat')
	};
		Def.Sprite{
		Texture = "1 5x1.png", 
		Frames = {{Delay= 0.25, Frame= 0}, {Delay= 0.25, Frame= 1}, {Delay= 0.25, Frame= 2}, {Delay= 0.25, Frame= 3}, {Delay= 0.25, Frame= 4}},
		OnCommand=cmd(x,620;y,580;effectclock,'beat')
	};
		Def.Sprite{
		Texture = "1 5x1.png", 
		Frames = {{Delay= 0.25, Frame= 0}, {Delay= 0.25, Frame= 1}, {Delay= 0.25, Frame= 2}, {Delay= 0.25, Frame= 3}, {Delay= 0.25, Frame= 4}},
		OnCommand=cmd(x,868;y,580;effectclock,'beat')
	};
};

return t;
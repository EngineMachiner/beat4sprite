return Def.ActorFrame{

	LoseFocusCommand=function(self)
		self:RunCommandsOnChildren(function(child) child:visible(false):finishtweening() end, {})
	end,
	LoadActor("sprite1.lua")..{
		OnCommand=cmd(y,0;linear,1.75*3.75;set_tween_uses_effect_delta,true;effectclock,"beat";y,-460;queuecommand,"On")
	};
	LoadActor("sprite1.lua")..{
		OnCommand=cmd(y,460;linear,1.75*3.75;set_tween_uses_effect_delta,true;effectclock,"beat";y,0;queuecommand,"On")
	};
}
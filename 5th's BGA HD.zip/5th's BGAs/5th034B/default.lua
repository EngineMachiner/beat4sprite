local t = Def.ActorFrame{
	LoadActor("1 (stretch)")..{
		OnCommand=cmd(Center;SetSize,640,480;set_use_effect_clock_for_texcoords,true;texcoordvelocity,-0.075*5,0;effectclock,'beat')
	};
	LoadActor("1 (stretch)")..{
		OnCommand=cmd(Center;addx,640;SetSize,640,480;set_use_effect_clock_for_texcoords,true;texcoordvelocity,-0.075*5,0;effectclock,'beat')
	};
	LoadActor("1 (stretch)")..{
		OnCommand=cmd(Center;addx,-640;SetSize,640,480;set_use_effect_clock_for_texcoords,true;texcoordvelocity,-0.075*5,0;effectclock,'beat')
	};
};

return t;
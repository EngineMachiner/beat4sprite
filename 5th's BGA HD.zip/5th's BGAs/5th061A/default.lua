local t = Def.ActorFrame{
	LoadActor("1.png")..{
		OnCommand=cmd(Center;SetSize,640,480)
	};
	LoadActor("1.png")..{
		OnCommand=cmd(Center;SetSize,640,480;addx,640;zoomx,-1)
	};
	LoadActor("1.png")..{
		OnCommand=cmd(Center;SetSize,640,480;addx,-640;zoomx,-1)
	};
		LoadActor("../Sprites/InnerEffect/Reverse", "Spheres 4x3.png")..{
		OnCommand=function(self)
			self:effectclock('beat')
		end
	},
};

return t;
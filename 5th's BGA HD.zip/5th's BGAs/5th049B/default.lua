local WDX2 if SCREEN_WIDTH > 640 then WDX2 = -80/4 else WDX2 = 0 end;
return Def.ActorFrame{

	LoseFocusCommand=function(self)
		self:RunCommandsOnChildren(function(child) child:visible(false):finishtweening() end, {})
	end,
		Def.Sprite{
		Texture = "1 TileStill 5x4.png", 
		Frames = {{Delay= 0.25/2, Frame= 0}, {Delay= 0.25/2, Frame= 1}, {Delay= 0.25/2, Frame= 2}, {Delay= 0.25/2, Frame= 3}, {Delay= 0.25/2, Frame= 4}, {Delay= 0.25/2, Frame= 5}, {Delay= 0.25/2, Frame= 6}, {Delay= 0.25/2, Frame= 7}, {Delay= 0.25/2, Frame= 8}, {Delay= 0.25/2, Frame= 9}, {Delay= 0.25/2, Frame= 10}, {Delay= 0.25/2, Frame= 11}, {Delay= 0.25/2, Frame= 12}, {Delay= 0.25/2, Frame= 13}, {Delay= 0.25/2, Frame= 14}, {Delay= 0.25/2, Frame= 15}, {Delay= 0.25/2, Frame= 16}, {Delay= 0.25/2, Frame= 17}, {Delay= 0.25/2, Frame= 18}, {Delay= 0.25/2, Frame= 19}, {Delay= 0.25/2, Frame= 20}},
		OnCommand=cmd(x,64;y,60;addx,WDX2;effectclock,"beat";setstate,math.random(0,19))
	};
		Def.Sprite{
		Texture = "1 TileStill 5x4.png", 
		Frames = {{Delay= 0.25/2, Frame= 0}, {Delay= 0.25/2, Frame= 1}, {Delay= 0.25/2, Frame= 2}, {Delay= 0.25/2, Frame= 3}, {Delay= 0.25/2, Frame= 4}, {Delay= 0.25/2, Frame= 5}, {Delay= 0.25/2, Frame= 6}, {Delay= 0.25/2, Frame= 7}, {Delay= 0.25/2, Frame= 8}, {Delay= 0.25/2, Frame= 9}, {Delay= 0.25/2, Frame= 10}, {Delay= 0.25/2, Frame= 11}, {Delay= 0.25/2, Frame= 12}, {Delay= 0.25/2, Frame= 13}, {Delay= 0.25/2, Frame= 14}, {Delay= 0.25/2, Frame= 15}, {Delay= 0.25/2, Frame= 16}, {Delay= 0.25/2, Frame= 17}, {Delay= 0.25/2, Frame= 18}, {Delay= 0.25/2, Frame= 19}, {Delay= 0.25/2, Frame= 20}},
		OnCommand=cmd(x,192;y,60;addx,WDX2;effectclock,"beat";setstate,math.random(0,19))
	};
		Def.Sprite{
		Texture = "1 TileStill 5x4.png", 
		Frames = {{Delay= 0.25/2, Frame= 0}, {Delay= 0.25/2, Frame= 1}, {Delay= 0.25/2, Frame= 2}, {Delay= 0.25/2, Frame= 3}, {Delay= 0.25/2, Frame= 4}, {Delay= 0.25/2, Frame= 5}, {Delay= 0.25/2, Frame= 6}, {Delay= 0.25/2, Frame= 7}, {Delay= 0.25/2, Frame= 8}, {Delay= 0.25/2, Frame= 9}, {Delay= 0.25/2, Frame= 10}, {Delay= 0.25/2, Frame= 11}, {Delay= 0.25/2, Frame= 12}, {Delay= 0.25/2, Frame= 13}, {Delay= 0.25/2, Frame= 14}, {Delay= 0.25/2, Frame= 15}, {Delay= 0.25/2, Frame= 16}, {Delay= 0.25/2, Frame= 17}, {Delay= 0.25/2, Frame= 18}, {Delay= 0.25/2, Frame= 19}, {Delay= 0.25/2, Frame= 20}},
		OnCommand=cmd(x,320;y,60;addx,WDX2;effectclock,"beat";setstate,math.random(0,19))
	};
		Def.Sprite{
		Texture = "1 TileStill 5x4.png", 
		Frames = {{Delay= 0.25/2, Frame= 0}, {Delay= 0.25/2, Frame= 1}, {Delay= 0.25/2, Frame= 2}, {Delay= 0.25/2, Frame= 3}, {Delay= 0.25/2, Frame= 4}, {Delay= 0.25/2, Frame= 5}, {Delay= 0.25/2, Frame= 6}, {Delay= 0.25/2, Frame= 7}, {Delay= 0.25/2, Frame= 8}, {Delay= 0.25/2, Frame= 9}, {Delay= 0.25/2, Frame= 10}, {Delay= 0.25/2, Frame= 11}, {Delay= 0.25/2, Frame= 12}, {Delay= 0.25/2, Frame= 13}, {Delay= 0.25/2, Frame= 14}, {Delay= 0.25/2, Frame= 15}, {Delay= 0.25/2, Frame= 16}, {Delay= 0.25/2, Frame= 17}, {Delay= 0.25/2, Frame= 18}, {Delay= 0.25/2, Frame= 19}, {Delay= 0.25/2, Frame= 20}},
		OnCommand=cmd(x,448;y,60;addx,WDX2;effectclock,"beat";setstate,math.random(0,19))
	};
		Def.Sprite{
		Texture = "1 TileStill 5x4.png", 
		Frames = {{Delay= 0.25/2, Frame= 0}, {Delay= 0.25/2, Frame= 1}, {Delay= 0.25/2, Frame= 2}, {Delay= 0.25/2, Frame= 3}, {Delay= 0.25/2, Frame= 4}, {Delay= 0.25/2, Frame= 5}, {Delay= 0.25/2, Frame= 6}, {Delay= 0.25/2, Frame= 7}, {Delay= 0.25/2, Frame= 8}, {Delay= 0.25/2, Frame= 9}, {Delay= 0.25/2, Frame= 10}, {Delay= 0.25/2, Frame= 11}, {Delay= 0.25/2, Frame= 12}, {Delay= 0.25/2, Frame= 13}, {Delay= 0.25/2, Frame= 14}, {Delay= 0.25/2, Frame= 15}, {Delay= 0.25/2, Frame= 16}, {Delay= 0.25/2, Frame= 17}, {Delay= 0.25/2, Frame= 18}, {Delay= 0.25/2, Frame= 19}, {Delay= 0.25/2, Frame= 20}},
		OnCommand=cmd(x,576;y,60;addx,WDX2;effectclock,"beat";setstate,math.random(0,19))
	};
		Def.Sprite{
		Texture = "1 TileStill 5x4.png", 
		Frames = {{Delay= 0.25/2, Frame= 0}, {Delay= 0.25/2, Frame= 1}, {Delay= 0.25/2, Frame= 2}, {Delay= 0.25/2, Frame= 3}, {Delay= 0.25/2, Frame= 4}, {Delay= 0.25/2, Frame= 5}, {Delay= 0.25/2, Frame= 6}, {Delay= 0.25/2, Frame= 7}, {Delay= 0.25/2, Frame= 8}, {Delay= 0.25/2, Frame= 9}, {Delay= 0.25/2, Frame= 10}, {Delay= 0.25/2, Frame= 11}, {Delay= 0.25/2, Frame= 12}, {Delay= 0.25/2, Frame= 13}, {Delay= 0.25/2, Frame= 14}, {Delay= 0.25/2, Frame= 15}, {Delay= 0.25/2, Frame= 16}, {Delay= 0.25/2, Frame= 17}, {Delay= 0.25/2, Frame= 18}, {Delay= 0.25/2, Frame= 19}, {Delay= 0.25/2, Frame= 20}},
		OnCommand=cmd(x,704;y,60;addx,WDX2;effectclock,"beat";setstate,math.random(0,19))
	};
		Def.Sprite{
		Texture = "1 TileStill 5x4.png", 
		Frames = {{Delay= 0.25/2, Frame= 0}, {Delay= 0.25/2, Frame= 1}, {Delay= 0.25/2, Frame= 2}, {Delay= 0.25/2, Frame= 3}, {Delay= 0.25/2, Frame= 4}, {Delay= 0.25/2, Frame= 5}, {Delay= 0.25/2, Frame= 6}, {Delay= 0.25/2, Frame= 7}, {Delay= 0.25/2, Frame= 8}, {Delay= 0.25/2, Frame= 9}, {Delay= 0.25/2, Frame= 10}, {Delay= 0.25/2, Frame= 11}, {Delay= 0.25/2, Frame= 12}, {Delay= 0.25/2, Frame= 13}, {Delay= 0.25/2, Frame= 14}, {Delay= 0.25/2, Frame= 15}, {Delay= 0.25/2, Frame= 16}, {Delay= 0.25/2, Frame= 17}, {Delay= 0.25/2, Frame= 18}, {Delay= 0.25/2, Frame= 19}, {Delay= 0.25/2, Frame= 20}},
		OnCommand=cmd(x,832;y,60;addx,WDX2;effectclock,"beat";setstate,math.random(0,19))
	};
		Def.Sprite{
		Texture = "1 TileStill 5x4.png", 
		Frames = {{Delay= 0.25/2, Frame= 0}, {Delay= 0.25/2, Frame= 1}, {Delay= 0.25/2, Frame= 2}, {Delay= 0.25/2, Frame= 3}, {Delay= 0.25/2, Frame= 4}, {Delay= 0.25/2, Frame= 5}, {Delay= 0.25/2, Frame= 6}, {Delay= 0.25/2, Frame= 7}, {Delay= 0.25/2, Frame= 8}, {Delay= 0.25/2, Frame= 9}, {Delay= 0.25/2, Frame= 10}, {Delay= 0.25/2, Frame= 11}, {Delay= 0.25/2, Frame= 12}, {Delay= 0.25/2, Frame= 13}, {Delay= 0.25/2, Frame= 14}, {Delay= 0.25/2, Frame= 15}, {Delay= 0.25/2, Frame= 16}, {Delay= 0.25/2, Frame= 17}, {Delay= 0.25/2, Frame= 18}, {Delay= 0.25/2, Frame= 19}, {Delay= 0.25/2, Frame= 20}},
		OnCommand=cmd(x,64;y,180;addx,WDX2;effectclock,"beat";setstate,math.random(0,19))
	};
		Def.Sprite{
		Texture = "1 TileStill 5x4.png", 
		Frames = {{Delay= 0.25/2, Frame= 0}, {Delay= 0.25/2, Frame= 1}, {Delay= 0.25/2, Frame= 2}, {Delay= 0.25/2, Frame= 3}, {Delay= 0.25/2, Frame= 4}, {Delay= 0.25/2, Frame= 5}, {Delay= 0.25/2, Frame= 6}, {Delay= 0.25/2, Frame= 7}, {Delay= 0.25/2, Frame= 8}, {Delay= 0.25/2, Frame= 9}, {Delay= 0.25/2, Frame= 10}, {Delay= 0.25/2, Frame= 11}, {Delay= 0.25/2, Frame= 12}, {Delay= 0.25/2, Frame= 13}, {Delay= 0.25/2, Frame= 14}, {Delay= 0.25/2, Frame= 15}, {Delay= 0.25/2, Frame= 16}, {Delay= 0.25/2, Frame= 17}, {Delay= 0.25/2, Frame= 18}, {Delay= 0.25/2, Frame= 19}, {Delay= 0.25/2, Frame= 20}},
		OnCommand=cmd(x,192;y,180;addx,WDX2;effectclock,"beat";setstate,math.random(0,19))
	};
		Def.Sprite{
		Texture = "1 TileStill 5x4.png", 
		Frames = {{Delay= 0.25/2, Frame= 0}, {Delay= 0.25/2, Frame= 1}, {Delay= 0.25/2, Frame= 2}, {Delay= 0.25/2, Frame= 3}, {Delay= 0.25/2, Frame= 4}, {Delay= 0.25/2, Frame= 5}, {Delay= 0.25/2, Frame= 6}, {Delay= 0.25/2, Frame= 7}, {Delay= 0.25/2, Frame= 8}, {Delay= 0.25/2, Frame= 9}, {Delay= 0.25/2, Frame= 10}, {Delay= 0.25/2, Frame= 11}, {Delay= 0.25/2, Frame= 12}, {Delay= 0.25/2, Frame= 13}, {Delay= 0.25/2, Frame= 14}, {Delay= 0.25/2, Frame= 15}, {Delay= 0.25/2, Frame= 16}, {Delay= 0.25/2, Frame= 17}, {Delay= 0.25/2, Frame= 18}, {Delay= 0.25/2, Frame= 19}, {Delay= 0.25/2, Frame= 20}},
		OnCommand=cmd(x,320;y,180;addx,WDX2;effectclock,"beat";setstate,math.random(0,19))
	};
		Def.Sprite{
		Texture = "1 TileStill 5x4.png", 
		Frames = {{Delay= 0.25/2, Frame= 0}, {Delay= 0.25/2, Frame= 1}, {Delay= 0.25/2, Frame= 2}, {Delay= 0.25/2, Frame= 3}, {Delay= 0.25/2, Frame= 4}, {Delay= 0.25/2, Frame= 5}, {Delay= 0.25/2, Frame= 6}, {Delay= 0.25/2, Frame= 7}, {Delay= 0.25/2, Frame= 8}, {Delay= 0.25/2, Frame= 9}, {Delay= 0.25/2, Frame= 10}, {Delay= 0.25/2, Frame= 11}, {Delay= 0.25/2, Frame= 12}, {Delay= 0.25/2, Frame= 13}, {Delay= 0.25/2, Frame= 14}, {Delay= 0.25/2, Frame= 15}, {Delay= 0.25/2, Frame= 16}, {Delay= 0.25/2, Frame= 17}, {Delay= 0.25/2, Frame= 18}, {Delay= 0.25/2, Frame= 19}, {Delay= 0.25/2, Frame= 20}},
		OnCommand=cmd(x,448;y,180;addx,WDX2;effectclock,"beat";setstate,math.random(0,19))
	};
		Def.Sprite{
		Texture = "1 TileStill 5x4.png", 
		Frames = {{Delay= 0.25/2, Frame= 0}, {Delay= 0.25/2, Frame= 1}, {Delay= 0.25/2, Frame= 2}, {Delay= 0.25/2, Frame= 3}, {Delay= 0.25/2, Frame= 4}, {Delay= 0.25/2, Frame= 5}, {Delay= 0.25/2, Frame= 6}, {Delay= 0.25/2, Frame= 7}, {Delay= 0.25/2, Frame= 8}, {Delay= 0.25/2, Frame= 9}, {Delay= 0.25/2, Frame= 10}, {Delay= 0.25/2, Frame= 11}, {Delay= 0.25/2, Frame= 12}, {Delay= 0.25/2, Frame= 13}, {Delay= 0.25/2, Frame= 14}, {Delay= 0.25/2, Frame= 15}, {Delay= 0.25/2, Frame= 16}, {Delay= 0.25/2, Frame= 17}, {Delay= 0.25/2, Frame= 18}, {Delay= 0.25/2, Frame= 19}, {Delay= 0.25/2, Frame= 20}},
		OnCommand=cmd(x,576;y,180;addx,WDX2;effectclock,"beat";setstate,math.random(0,19))
	};
		Def.Sprite{
		Texture = "1 TileStill 5x4.png", 
		Frames = {{Delay= 0.25/2, Frame= 0}, {Delay= 0.25/2, Frame= 1}, {Delay= 0.25/2, Frame= 2}, {Delay= 0.25/2, Frame= 3}, {Delay= 0.25/2, Frame= 4}, {Delay= 0.25/2, Frame= 5}, {Delay= 0.25/2, Frame= 6}, {Delay= 0.25/2, Frame= 7}, {Delay= 0.25/2, Frame= 8}, {Delay= 0.25/2, Frame= 9}, {Delay= 0.25/2, Frame= 10}, {Delay= 0.25/2, Frame= 11}, {Delay= 0.25/2, Frame= 12}, {Delay= 0.25/2, Frame= 13}, {Delay= 0.25/2, Frame= 14}, {Delay= 0.25/2, Frame= 15}, {Delay= 0.25/2, Frame= 16}, {Delay= 0.25/2, Frame= 17}, {Delay= 0.25/2, Frame= 18}, {Delay= 0.25/2, Frame= 19}, {Delay= 0.25/2, Frame= 20}},
		OnCommand=cmd(x,704;y,180;addx,WDX2;effectclock,"beat";setstate,math.random(0,19))
	};
		Def.Sprite{
		Texture = "1 TileStill 5x4.png", 
		Frames = {{Delay= 0.25/2, Frame= 0}, {Delay= 0.25/2, Frame= 1}, {Delay= 0.25/2, Frame= 2}, {Delay= 0.25/2, Frame= 3}, {Delay= 0.25/2, Frame= 4}, {Delay= 0.25/2, Frame= 5}, {Delay= 0.25/2, Frame= 6}, {Delay= 0.25/2, Frame= 7}, {Delay= 0.25/2, Frame= 8}, {Delay= 0.25/2, Frame= 9}, {Delay= 0.25/2, Frame= 10}, {Delay= 0.25/2, Frame= 11}, {Delay= 0.25/2, Frame= 12}, {Delay= 0.25/2, Frame= 13}, {Delay= 0.25/2, Frame= 14}, {Delay= 0.25/2, Frame= 15}, {Delay= 0.25/2, Frame= 16}, {Delay= 0.25/2, Frame= 17}, {Delay= 0.25/2, Frame= 18}, {Delay= 0.25/2, Frame= 19}, {Delay= 0.25/2, Frame= 20}},
		OnCommand=cmd(x,832;y,180;addx,WDX2;effectclock,"beat";setstate,math.random(0,19))
	};
		Def.Sprite{
		Texture = "1 TileStill 5x4.png", 
		Frames = {{Delay= 0.25/2, Frame= 0}, {Delay= 0.25/2, Frame= 1}, {Delay= 0.25/2, Frame= 2}, {Delay= 0.25/2, Frame= 3}, {Delay= 0.25/2, Frame= 4}, {Delay= 0.25/2, Frame= 5}, {Delay= 0.25/2, Frame= 6}, {Delay= 0.25/2, Frame= 7}, {Delay= 0.25/2, Frame= 8}, {Delay= 0.25/2, Frame= 9}, {Delay= 0.25/2, Frame= 10}, {Delay= 0.25/2, Frame= 11}, {Delay= 0.25/2, Frame= 12}, {Delay= 0.25/2, Frame= 13}, {Delay= 0.25/2, Frame= 14}, {Delay= 0.25/2, Frame= 15}, {Delay= 0.25/2, Frame= 16}, {Delay= 0.25/2, Frame= 17}, {Delay= 0.25/2, Frame= 18}, {Delay= 0.25/2, Frame= 19}, {Delay= 0.25/2, Frame= 20}},
		OnCommand=cmd(x,64;y,300;addx,WDX2;effectclock,"beat";setstate,math.random(0,19))
	};
		Def.Sprite{
		Texture = "1 TileStill 5x4.png", 
		Frames = {{Delay= 0.25/2, Frame= 0}, {Delay= 0.25/2, Frame= 1}, {Delay= 0.25/2, Frame= 2}, {Delay= 0.25/2, Frame= 3}, {Delay= 0.25/2, Frame= 4}, {Delay= 0.25/2, Frame= 5}, {Delay= 0.25/2, Frame= 6}, {Delay= 0.25/2, Frame= 7}, {Delay= 0.25/2, Frame= 8}, {Delay= 0.25/2, Frame= 9}, {Delay= 0.25/2, Frame= 10}, {Delay= 0.25/2, Frame= 11}, {Delay= 0.25/2, Frame= 12}, {Delay= 0.25/2, Frame= 13}, {Delay= 0.25/2, Frame= 14}, {Delay= 0.25/2, Frame= 15}, {Delay= 0.25/2, Frame= 16}, {Delay= 0.25/2, Frame= 17}, {Delay= 0.25/2, Frame= 18}, {Delay= 0.25/2, Frame= 19}, {Delay= 0.25/2, Frame= 20}},
		OnCommand=cmd(x,192;y,300;addx,WDX2;effectclock,"beat";setstate,math.random(0,19))
	};
		Def.Sprite{
		Texture = "1 TileStill 5x4.png", 
		Frames = {{Delay= 0.25/2, Frame= 0}, {Delay= 0.25/2, Frame= 1}, {Delay= 0.25/2, Frame= 2}, {Delay= 0.25/2, Frame= 3}, {Delay= 0.25/2, Frame= 4}, {Delay= 0.25/2, Frame= 5}, {Delay= 0.25/2, Frame= 6}, {Delay= 0.25/2, Frame= 7}, {Delay= 0.25/2, Frame= 8}, {Delay= 0.25/2, Frame= 9}, {Delay= 0.25/2, Frame= 10}, {Delay= 0.25/2, Frame= 11}, {Delay= 0.25/2, Frame= 12}, {Delay= 0.25/2, Frame= 13}, {Delay= 0.25/2, Frame= 14}, {Delay= 0.25/2, Frame= 15}, {Delay= 0.25/2, Frame= 16}, {Delay= 0.25/2, Frame= 17}, {Delay= 0.25/2, Frame= 18}, {Delay= 0.25/2, Frame= 19}, {Delay= 0.25/2, Frame= 20}},
		OnCommand=cmd(x,320;y,300;addx,WDX2;effectclock,"beat";setstate,math.random(0,19))
	};
		Def.Sprite{
		Texture = "1 TileStill 5x4.png", 
		Frames = {{Delay= 0.25/2, Frame= 0}, {Delay= 0.25/2, Frame= 1}, {Delay= 0.25/2, Frame= 2}, {Delay= 0.25/2, Frame= 3}, {Delay= 0.25/2, Frame= 4}, {Delay= 0.25/2, Frame= 5}, {Delay= 0.25/2, Frame= 6}, {Delay= 0.25/2, Frame= 7}, {Delay= 0.25/2, Frame= 8}, {Delay= 0.25/2, Frame= 9}, {Delay= 0.25/2, Frame= 10}, {Delay= 0.25/2, Frame= 11}, {Delay= 0.25/2, Frame= 12}, {Delay= 0.25/2, Frame= 13}, {Delay= 0.25/2, Frame= 14}, {Delay= 0.25/2, Frame= 15}, {Delay= 0.25/2, Frame= 16}, {Delay= 0.25/2, Frame= 17}, {Delay= 0.25/2, Frame= 18}, {Delay= 0.25/2, Frame= 19}, {Delay= 0.25/2, Frame= 20}},
		OnCommand=cmd(x,448;y,300;addx,WDX2;effectclock,"beat";setstate,math.random(0,19))
	};
		Def.Sprite{
		Texture = "1 TileStill 5x4.png", 
		Frames = {{Delay= 0.25/2, Frame= 0}, {Delay= 0.25/2, Frame= 1}, {Delay= 0.25/2, Frame= 2}, {Delay= 0.25/2, Frame= 3}, {Delay= 0.25/2, Frame= 4}, {Delay= 0.25/2, Frame= 5}, {Delay= 0.25/2, Frame= 6}, {Delay= 0.25/2, Frame= 7}, {Delay= 0.25/2, Frame= 8}, {Delay= 0.25/2, Frame= 9}, {Delay= 0.25/2, Frame= 10}, {Delay= 0.25/2, Frame= 11}, {Delay= 0.25/2, Frame= 12}, {Delay= 0.25/2, Frame= 13}, {Delay= 0.25/2, Frame= 14}, {Delay= 0.25/2, Frame= 15}, {Delay= 0.25/2, Frame= 16}, {Delay= 0.25/2, Frame= 17}, {Delay= 0.25/2, Frame= 18}, {Delay= 0.25/2, Frame= 19}, {Delay= 0.25/2, Frame= 20}},
		OnCommand=cmd(x,576;y,300;addx,WDX2;effectclock,"beat";setstate,math.random(0,19))
	};
		Def.Sprite{
		Texture = "1 TileStill 5x4.png", 
		Frames = {{Delay= 0.25/2, Frame= 0}, {Delay= 0.25/2, Frame= 1}, {Delay= 0.25/2, Frame= 2}, {Delay= 0.25/2, Frame= 3}, {Delay= 0.25/2, Frame= 4}, {Delay= 0.25/2, Frame= 5}, {Delay= 0.25/2, Frame= 6}, {Delay= 0.25/2, Frame= 7}, {Delay= 0.25/2, Frame= 8}, {Delay= 0.25/2, Frame= 9}, {Delay= 0.25/2, Frame= 10}, {Delay= 0.25/2, Frame= 11}, {Delay= 0.25/2, Frame= 12}, {Delay= 0.25/2, Frame= 13}, {Delay= 0.25/2, Frame= 14}, {Delay= 0.25/2, Frame= 15}, {Delay= 0.25/2, Frame= 16}, {Delay= 0.25/2, Frame= 17}, {Delay= 0.25/2, Frame= 18}, {Delay= 0.25/2, Frame= 19}, {Delay= 0.25/2, Frame= 20}},
		OnCommand=cmd(x,704;y,300;addx,WDX2;effectclock,"beat";setstate,math.random(0,19))
	};
		Def.Sprite{
		Texture = "1 TileStill 5x4.png", 
		Frames = {{Delay= 0.25/2, Frame= 0}, {Delay= 0.25/2, Frame= 1}, {Delay= 0.25/2, Frame= 2}, {Delay= 0.25/2, Frame= 3}, {Delay= 0.25/2, Frame= 4}, {Delay= 0.25/2, Frame= 5}, {Delay= 0.25/2, Frame= 6}, {Delay= 0.25/2, Frame= 7}, {Delay= 0.25/2, Frame= 8}, {Delay= 0.25/2, Frame= 9}, {Delay= 0.25/2, Frame= 10}, {Delay= 0.25/2, Frame= 11}, {Delay= 0.25/2, Frame= 12}, {Delay= 0.25/2, Frame= 13}, {Delay= 0.25/2, Frame= 14}, {Delay= 0.25/2, Frame= 15}, {Delay= 0.25/2, Frame= 16}, {Delay= 0.25/2, Frame= 17}, {Delay= 0.25/2, Frame= 18}, {Delay= 0.25/2, Frame= 19}, {Delay= 0.25/2, Frame= 20}},
		OnCommand=cmd(x,832;y,300;addx,WDX2;effectclock,"beat";setstate,math.random(0,19))
	};
		Def.Sprite{
		Texture = "1 TileStill 5x4.png", 
		Frames = {{Delay= 0.25/2, Frame= 0}, {Delay= 0.25/2, Frame= 1}, {Delay= 0.25/2, Frame= 2}, {Delay= 0.25/2, Frame= 3}, {Delay= 0.25/2, Frame= 4}, {Delay= 0.25/2, Frame= 5}, {Delay= 0.25/2, Frame= 6}, {Delay= 0.25/2, Frame= 7}, {Delay= 0.25/2, Frame= 8}, {Delay= 0.25/2, Frame= 9}, {Delay= 0.25/2, Frame= 10}, {Delay= 0.25/2, Frame= 11}, {Delay= 0.25/2, Frame= 12}, {Delay= 0.25/2, Frame= 13}, {Delay= 0.25/2, Frame= 14}, {Delay= 0.25/2, Frame= 15}, {Delay= 0.25/2, Frame= 16}, {Delay= 0.25/2, Frame= 17}, {Delay= 0.25/2, Frame= 18}, {Delay= 0.25/2, Frame= 19}, {Delay= 0.25/2, Frame= 20}},
		OnCommand=cmd(x,64;y,420;addx,WDX2;effectclock,"beat";setstate,math.random(0,19))
	};
		Def.Sprite{
		Texture = "1 TileStill 5x4.png", 
		Frames = {{Delay= 0.25/2, Frame= 0}, {Delay= 0.25/2, Frame= 1}, {Delay= 0.25/2, Frame= 2}, {Delay= 0.25/2, Frame= 3}, {Delay= 0.25/2, Frame= 4}, {Delay= 0.25/2, Frame= 5}, {Delay= 0.25/2, Frame= 6}, {Delay= 0.25/2, Frame= 7}, {Delay= 0.25/2, Frame= 8}, {Delay= 0.25/2, Frame= 9}, {Delay= 0.25/2, Frame= 10}, {Delay= 0.25/2, Frame= 11}, {Delay= 0.25/2, Frame= 12}, {Delay= 0.25/2, Frame= 13}, {Delay= 0.25/2, Frame= 14}, {Delay= 0.25/2, Frame= 15}, {Delay= 0.25/2, Frame= 16}, {Delay= 0.25/2, Frame= 17}, {Delay= 0.25/2, Frame= 18}, {Delay= 0.25/2, Frame= 19}, {Delay= 0.25/2, Frame= 20}},
		OnCommand=cmd(x,192;y,420;addx,WDX2;effectclock,"beat";setstate,math.random(0,19))
	};
		Def.Sprite{
		Texture = "1 TileStill 5x4.png", 
		Frames = {{Delay= 0.25/2, Frame= 0}, {Delay= 0.25/2, Frame= 1}, {Delay= 0.25/2, Frame= 2}, {Delay= 0.25/2, Frame= 3}, {Delay= 0.25/2, Frame= 4}, {Delay= 0.25/2, Frame= 5}, {Delay= 0.25/2, Frame= 6}, {Delay= 0.25/2, Frame= 7}, {Delay= 0.25/2, Frame= 8}, {Delay= 0.25/2, Frame= 9}, {Delay= 0.25/2, Frame= 10}, {Delay= 0.25/2, Frame= 11}, {Delay= 0.25/2, Frame= 12}, {Delay= 0.25/2, Frame= 13}, {Delay= 0.25/2, Frame= 14}, {Delay= 0.25/2, Frame= 15}, {Delay= 0.25/2, Frame= 16}, {Delay= 0.25/2, Frame= 17}, {Delay= 0.25/2, Frame= 18}, {Delay= 0.25/2, Frame= 19}, {Delay= 0.25/2, Frame= 20}},
		OnCommand=cmd(x,320;y,420;addx,WDX2;effectclock,"beat";setstate,math.random(0,19))
	};
		Def.Sprite{
		Texture = "1 TileStill 5x4.png", 
		Frames = {{Delay= 0.25/2, Frame= 0}, {Delay= 0.25/2, Frame= 1}, {Delay= 0.25/2, Frame= 2}, {Delay= 0.25/2, Frame= 3}, {Delay= 0.25/2, Frame= 4}, {Delay= 0.25/2, Frame= 5}, {Delay= 0.25/2, Frame= 6}, {Delay= 0.25/2, Frame= 7}, {Delay= 0.25/2, Frame= 8}, {Delay= 0.25/2, Frame= 9}, {Delay= 0.25/2, Frame= 10}, {Delay= 0.25/2, Frame= 11}, {Delay= 0.25/2, Frame= 12}, {Delay= 0.25/2, Frame= 13}, {Delay= 0.25/2, Frame= 14}, {Delay= 0.25/2, Frame= 15}, {Delay= 0.25/2, Frame= 16}, {Delay= 0.25/2, Frame= 17}, {Delay= 0.25/2, Frame= 18}, {Delay= 0.25/2, Frame= 19}, {Delay= 0.25/2, Frame= 20}},
		OnCommand=cmd(x,448;y,420;addx,WDX2;effectclock,"beat";setstate,math.random(0,19))
	};
		Def.Sprite{
		Texture = "1 TileStill 5x4.png", 
		Frames = {{Delay= 0.25/2, Frame= 0}, {Delay= 0.25/2, Frame= 1}, {Delay= 0.25/2, Frame= 2}, {Delay= 0.25/2, Frame= 3}, {Delay= 0.25/2, Frame= 4}, {Delay= 0.25/2, Frame= 5}, {Delay= 0.25/2, Frame= 6}, {Delay= 0.25/2, Frame= 7}, {Delay= 0.25/2, Frame= 8}, {Delay= 0.25/2, Frame= 9}, {Delay= 0.25/2, Frame= 10}, {Delay= 0.25/2, Frame= 11}, {Delay= 0.25/2, Frame= 12}, {Delay= 0.25/2, Frame= 13}, {Delay= 0.25/2, Frame= 14}, {Delay= 0.25/2, Frame= 15}, {Delay= 0.25/2, Frame= 16}, {Delay= 0.25/2, Frame= 17}, {Delay= 0.25/2, Frame= 18}, {Delay= 0.25/2, Frame= 19}, {Delay= 0.25/2, Frame= 20}},
		OnCommand=cmd(x,576;y,420;addx,WDX2;effectclock,"beat";setstate,math.random(0,19))
	};
		Def.Sprite{
		Texture = "1 TileStill 5x4.png", 
		Frames = {{Delay= 0.25/2, Frame= 0}, {Delay= 0.25/2, Frame= 1}, {Delay= 0.25/2, Frame= 2}, {Delay= 0.25/2, Frame= 3}, {Delay= 0.25/2, Frame= 4}, {Delay= 0.25/2, Frame= 5}, {Delay= 0.25/2, Frame= 6}, {Delay= 0.25/2, Frame= 7}, {Delay= 0.25/2, Frame= 8}, {Delay= 0.25/2, Frame= 9}, {Delay= 0.25/2, Frame= 10}, {Delay= 0.25/2, Frame= 11}, {Delay= 0.25/2, Frame= 12}, {Delay= 0.25/2, Frame= 13}, {Delay= 0.25/2, Frame= 14}, {Delay= 0.25/2, Frame= 15}, {Delay= 0.25/2, Frame= 16}, {Delay= 0.25/2, Frame= 17}, {Delay= 0.25/2, Frame= 18}, {Delay= 0.25/2, Frame= 19}, {Delay= 0.25/2, Frame= 20}},
		OnCommand=cmd(x,704;y,420;addx,WDX2;effectclock,"beat";setstate,math.random(0,19))
	};
		Def.Sprite{
		Texture = "1 TileStill 5x4.png", 
		Frames = {{Delay= 0.25/2, Frame= 0}, {Delay= 0.25/2, Frame= 1}, {Delay= 0.25/2, Frame= 2}, {Delay= 0.25/2, Frame= 3}, {Delay= 0.25/2, Frame= 4}, {Delay= 0.25/2, Frame= 5}, {Delay= 0.25/2, Frame= 6}, {Delay= 0.25/2, Frame= 7}, {Delay= 0.25/2, Frame= 8}, {Delay= 0.25/2, Frame= 9}, {Delay= 0.25/2, Frame= 10}, {Delay= 0.25/2, Frame= 11}, {Delay= 0.25/2, Frame= 12}, {Delay= 0.25/2, Frame= 13}, {Delay= 0.25/2, Frame= 14}, {Delay= 0.25/2, Frame= 15}, {Delay= 0.25/2, Frame= 16}, {Delay= 0.25/2, Frame= 17}, {Delay= 0.25/2, Frame= 18}, {Delay= 0.25/2, Frame= 19}, {Delay= 0.25/2, Frame= 20}},
		OnCommand=cmd(x,832;y,420;addx,WDX2;effectclock,"beat";setstate,math.random(0,19))
	};
	LoadActor("A.lua")..{
		OnCommand=cmd()
	};
}
local WDX2 if SCREEN_WIDTH > 640 then WDX2 = -80/1.5 else WDX2 = 0 end;
return Def.ActorFrame{
	LoseFocusCommand=function(self)
		self:RunCommandsOnChildren(function(child) child:visible(false):finishtweening() end, {})
	end,
	LoadActor("1.png")..{
		OnCommand=cmd(Center;SetSize,640,480)
	};
	LoadActor("1.png")..{
		OnCommand=cmd(Center;SetSize,640,480;addx,640;zoomx,-1)
	};
	LoadActor("1.png")..{
		OnCommand=cmd(Center;SetSize,640,480;addx,-640;zoomx,-1)
	};
	Def.Sprite{
		Texture = "2.png", 
		Frames = {{Delay= 0.5, Frame= 0}, {Delay= 0.5, Frame= 1}},
		OnCommand=function(self)
		self:x(80)
			:y(60)
			:addx(WDX2)
			:rotationy(0):linear(1):rotationy(90):linear(1):rotationy(0):queuecommand( "On" ):effectclock('beat')
			end
	};
		Def.Sprite{
		Texture = "2.png", 
		Frames = {{Delay= 0.5, Frame= 0}, {Delay= 0.5, Frame= 1}},
		OnCommand=function(self)
		self:x(240)
			:y(60)
			:addx(WDX2)
			:rotationy(0):linear(1):rotationy(90):linear(1):rotationy(0):queuecommand( "On" ):effectclock('beat')
			end	};
		Def.Sprite{
		Texture = "2.png", 
		Frames = {{Delay= 0.5, Frame= 0}, {Delay= 0.5, Frame= 1}},
		OnCommand=function(self)
		self:x(400)
			:y(60)
			:addx(WDX2)
			:rotationy(0):linear(1):rotationy(90):linear(1):rotationy(0):queuecommand( "On" ):effectclock('beat')
			end	};
		Def.Sprite{
		Texture = "2.png", 
		Frames = {{Delay= 0.5, Frame= 0}, {Delay= 0.5, Frame= 1}},
		OnCommand=function(self)
		self:x(560)
			:y(60)
			:addx(WDX2)
			:rotationy(0):linear(1):rotationy(90):linear(1):rotationy(0):queuecommand( "On" ):effectclock('beat')
			end	};
		Def.Sprite{
		Texture = "2.png", 
		Frames = {{Delay= 0.5, Frame= 0}, {Delay= 0.5, Frame= 1}},
		OnCommand=function(self)
		self:x(720)
			:y(60)
			:addx(WDX2)
			:rotationy(0):linear(1):rotationy(90):linear(1):rotationy(0):queuecommand( "On" ):effectclock('beat')
			end	};
		Def.Sprite{
		Texture = "2.png", 
		Frames = {{Delay= 0.5, Frame= 0}, {Delay= 0.5, Frame= 1}},
		OnCommand=function(self)
		self:x(880)
			:y(60)
			:addx(WDX2)
			:rotationy(0):linear(1):rotationy(90):linear(1):rotationy(0):queuecommand( "On" ):effectclock('beat')
			end	};
--
	Def.Sprite{
		Texture = "2.png", 
		Frames = {{Delay= 0.5, Frame= 0}, {Delay= 0.5, Frame= 1}},
		OnCommand=function(self)
		self:x(80)
			:y(SCREEN_CENTER_Y)
			:addx(WDX2)
			:rotationy(0):linear(1):rotationy(90):linear(1):rotationy(0):queuecommand( "On" ):effectclock('beat')
			end
	};
		Def.Sprite{
		Texture = "2.png", 
		Frames = {{Delay= 0.5, Frame= 0}, {Delay= 0.5, Frame= 1}},
		OnCommand=function(self)
		self:x(240)
			:y(SCREEN_CENTER_Y)
			:addx(WDX2)
			:rotationy(0):linear(1):rotationy(90):linear(1):rotationy(0):queuecommand( "On" ):effectclock('beat')
			end	};
		Def.Sprite{
		Texture = "2.png", 
		Frames = {{Delay= 0.5, Frame= 0}, {Delay= 0.5, Frame= 1}},
		OnCommand=function(self)
		self:x(400)
			:y(SCREEN_CENTER_Y)
			:addx(WDX2)
			:rotationy(0):linear(1):rotationy(90):linear(1):rotationy(0):queuecommand( "On" ):effectclock('beat')
			end	};
		Def.Sprite{
		Texture = "2.png", 
		Frames = {{Delay= 0.5, Frame= 0}, {Delay= 0.5, Frame= 1}},
		OnCommand=function(self)
		self:x(560)
			:y(SCREEN_CENTER_Y)
			:addx(WDX2)
			:rotationy(0):linear(1):rotationy(90):linear(1):rotationy(0):queuecommand( "On" ):effectclock('beat')
			end	};
		Def.Sprite{
		Texture = "2.png", 
		Frames = {{Delay= 0.5, Frame= 0}, {Delay= 0.5, Frame= 1}},
		OnCommand=function(self)
		self:x(720)
			:y(SCREEN_CENTER_Y)
			:addx(WDX2)
			:rotationy(0):linear(1):rotationy(90):linear(1):rotationy(0):queuecommand( "On" ):effectclock('beat')
			end	};
		Def.Sprite{
		Texture = "2.png", 
		Frames = {{Delay= 0.5, Frame= 0}, {Delay= 0.5, Frame= 1}},
		OnCommand=function(self)
		self:x(880)
			:y(SCREEN_CENTER_Y)
			:addx(WDX2)
			:rotationy(0):linear(1):rotationy(90):linear(1):rotationy(0):queuecommand( "On" ):effectclock('beat')
			end	};
---
	Def.Sprite{
		Texture = "2.png", 
		Frames = {{Delay= 0.5, Frame= 0}, {Delay= 0.5, Frame= 1}},
		OnCommand=function(self)
		self:x(80)
			:y(420)
			:addx(WDX2)
			:rotationy(0):linear(1):rotationy(90):linear(1):rotationy(0):queuecommand( "On" ):effectclock('beat')
			end
	};
		Def.Sprite{
		Texture = "2.png", 
		Frames = {{Delay= 0.5, Frame= 0}, {Delay= 0.5, Frame= 1}},
		OnCommand=function(self)
		self:x(240)
			:y(420)
			:addx(WDX2)
			:rotationy(0):linear(1):rotationy(90):linear(1):rotationy(0):queuecommand( "On" ):effectclock('beat')
			end	};
		Def.Sprite{
		Texture = "2.png", 
		Frames = {{Delay= 0.5, Frame= 0}, {Delay= 0.5, Frame= 1}},
		OnCommand=function(self)
		self:x(400)
			:y(420)
			:addx(WDX2)
			:rotationy(0):linear(1):rotationy(90):linear(1):rotationy(0):queuecommand( "On" ):effectclock('beat')
			end	};
		Def.Sprite{
		Texture = "2.png", 
		Frames = {{Delay= 0.5, Frame= 0}, {Delay= 0.5, Frame= 1}},
		OnCommand=function(self)
		self:x(560)
			:y(420)
			:addx(WDX2)
			:rotationy(0):linear(1):rotationy(90):linear(1):rotationy(0):queuecommand( "On" ):effectclock('beat')
			end	};
		Def.Sprite{
		Texture = "2.png", 
		Frames = {{Delay= 0.5, Frame= 0}, {Delay= 0.5, Frame= 1}},
		OnCommand=function(self)
		self:x(720)
			:y(420)
			:addx(WDX2)
			:rotationy(0):linear(1):rotationy(90):linear(1):rotationy(0):queuecommand( "On" ):effectclock('beat')
			end	};
		Def.Sprite{
		Texture = "2.png", 
		Frames = {{Delay= 0.5, Frame= 0}, {Delay= 0.5, Frame= 1}},
		OnCommand=function(self)
		self:x(880)
			:y(420)
			:addx(WDX2)
			:rotationy(0):linear(1):rotationy(90):linear(1):rotationy(0):queuecommand( "On" ):effectclock('beat')
			end	};
}
local WDX2 if SCREEN_WIDTH > 640 then WDX2 = -64/(1.5*2) else WDX2 = 0 end;
local t = Def.ActorFrame{
	LoadActor("1 (stretch)")..{
		OnCommand=cmd(x,64;y,60;addx,WDX2)
	};
	LoadActor("1 (stretch)")..{
		OnCommand=cmd(x,192;y,60;addx,WDX2)
	};
	LoadActor("1 (stretch)")..{
		OnCommand=cmd(x,320;y,60;addx,WDX2)
	};
	LoadActor("1 (stretch)")..{
		OnCommand=cmd(x,448;y,60;addx,WDX2)
	};
	LoadActor("1 (stretch)")..{
		OnCommand=cmd(x,576;y,60;addx,WDX2)
	};
	LoadActor("1 (stretch)")..{
		OnCommand=cmd(x,704;y,60;addx,WDX2)
	};
	LoadActor("1 (stretch)")..{
		OnCommand=cmd(x,832;y,60;addx,WDX2)
	};
	LoadActor("1 (stretch)")..{
		OnCommand=cmd(x,64;y,180;addx,WDX2)
	};
	LoadActor("1 (stretch)")..{
		OnCommand=cmd(x,192;y,180;addx,WDX2)
	};
	LoadActor("1 (stretch)")..{
		OnCommand=cmd(x,320;y,180;addx,WDX2)
	};
	LoadActor("1 (stretch)")..{
		OnCommand=cmd(x,448;y,180;addx,WDX2)
	};
	LoadActor("1 (stretch)")..{
		OnCommand=cmd(x,576;y,180;addx,WDX2)
	};
	LoadActor("1 (stretch)")..{
		OnCommand=cmd(x,704;y,180;addx,WDX2)
	};
	LoadActor("1 (stretch)")..{
		OnCommand=cmd(x,832;y,180;addx,WDX2)
	};
	LoadActor("1 (stretch)")..{
		OnCommand=cmd(x,64;y,300;addx,WDX2)
	};
	LoadActor("1 (stretch)")..{
		OnCommand=cmd(x,192;y,300;addx,WDX2)
	};
	LoadActor("1 (stretch)")..{
		OnCommand=cmd(x,320;y,300;addx,WDX2)
	};
	LoadActor("1 (stretch)")..{
		OnCommand=cmd(x,448;y,300;addx,WDX2)
	};
	LoadActor("1 (stretch)")..{
		OnCommand=cmd(x,576;y,300;addx,WDX2)
	};
	LoadActor("1 (stretch)")..{
		OnCommand=cmd(x,704;y,300;addx,WDX2)
	};
	LoadActor("1 (stretch)")..{
		OnCommand=cmd(x,832;y,300;addx,WDX2)
	};
	LoadActor("1 (stretch)")..{
		OnCommand=cmd(x,64;y,420;addx,WDX2)
	};
	LoadActor("1 (stretch)")..{
		OnCommand=cmd(x,192;y,420;addx,WDX2)
	};
	LoadActor("1 (stretch)")..{
		OnCommand=cmd(x,320;y,420;addx,WDX2)
	};
	LoadActor("1 (stretch)")..{
		OnCommand=cmd(x,448;y,420;addx,WDX2)
	};
	LoadActor("1 (stretch)")..{
		OnCommand=cmd(x,576;y,420;addx,WDX2)
	};
	LoadActor("1 (stretch)")..{
		OnCommand=cmd(x,704;y,420;addx,WDX2)
	};
	LoadActor("1 (stretch)")..{
		OnCommand=cmd(x,832;y,420;addx,WDX2)
	};
	LoadActor("2 (stretch)")..{
		OnCommand=cmd(x,64;y,60;texcoordvelocity,0.075*5,0.075*5;zoom,0.75;set_use_effect_clock_for_texcoords,true;effectclock,'beat')
	};
	LoadActor("2 (stretch)")..{
		OnCommand=cmd(x,192;y,60;texcoordvelocity,0.075*5,0.075*5;zoom,0.75;set_use_effect_clock_for_texcoords,true;effectclock,'beat')
	};
	LoadActor("2 (stretch)")..{
		OnCommand=cmd(x,320;y,60;texcoordvelocity,0.075*5,0.075*5;zoom,0.75;set_use_effect_clock_for_texcoords,true;effectclock,'beat')
	};
	LoadActor("2 (stretch)")..{
		OnCommand=cmd(x,448;y,60;texcoordvelocity,0.075*5,0.075*5;zoom,0.75;set_use_effect_clock_for_texcoords,true;effectclock,'beat')
	};
	LoadActor("2 (stretch)")..{
		OnCommand=cmd(x,576;y,60;texcoordvelocity,0.075*5,0.075*5;zoom,0.75;set_use_effect_clock_for_texcoords,true;effectclock,'beat')
	};
	LoadActor("2 (stretch)")..{
		OnCommand=cmd(x,704;y,60;texcoordvelocity,0.075*5,0.075*5;zoom,0.75;set_use_effect_clock_for_texcoords,true;effectclock,'beat')
	};
	LoadActor("2 (stretch)")..{
		OnCommand=cmd(x,832;y,60;texcoordvelocity,0.075*5,0.075*5;zoom,0.75;set_use_effect_clock_for_texcoords,true;effectclock,'beat')
	};
	LoadActor("2 (stretch)")..{
		OnCommand=cmd(x,64;y,180;texcoordvelocity,0.075*5,0.075*5;zoom,0.75;set_use_effect_clock_for_texcoords,true;effectclock,'beat')
	};
	LoadActor("2 (stretch)")..{
		OnCommand=cmd(x,192;y,180;texcoordvelocity,0.075*5,0.075*5;zoom,0.75;set_use_effect_clock_for_texcoords,true;effectclock,'beat')
	};
	LoadActor("2 (stretch)")..{
		OnCommand=cmd(x,320;y,180;texcoordvelocity,0.075*5,0.075*5;zoom,0.75;set_use_effect_clock_for_texcoords,true;effectclock,'beat')
	};
	LoadActor("2 (stretch)")..{
		OnCommand=cmd(x,448;y,180;texcoordvelocity,0.075*5,0.075*5;zoom,0.75;set_use_effect_clock_for_texcoords,true;effectclock,'beat')
	};
	LoadActor("2 (stretch)")..{
		OnCommand=cmd(x,576;y,180;texcoordvelocity,0.075*5,0.075*5;zoom,0.75;set_use_effect_clock_for_texcoords,true;effectclock,'beat')
	};
	LoadActor("2 (stretch)")..{
		OnCommand=cmd(x,704;y,180;texcoordvelocity,0.075*5,0.075*5;zoom,0.75;set_use_effect_clock_for_texcoords,true;effectclock,'beat')
	};
	LoadActor("2 (stretch)")..{
		OnCommand=cmd(x,832;y,180;texcoordvelocity,0.075*5,0.075*5;zoom,0.75;set_use_effect_clock_for_texcoords,true;effectclock,'beat')
	};
	LoadActor("2 (stretch)")..{
		OnCommand=cmd(x,64;y,300;texcoordvelocity,0.075*5,0.075*5;zoom,0.75;set_use_effect_clock_for_texcoords,true;effectclock,'beat')
	};
	LoadActor("2 (stretch)")..{
		OnCommand=cmd(x,192;y,300;texcoordvelocity,0.075*5,0.075*5;zoom,0.75;set_use_effect_clock_for_texcoords,true;effectclock,'beat')
	};
	LoadActor("2 (stretch)")..{
		OnCommand=cmd(x,320;y,300;texcoordvelocity,0.075*5,0.075*5;zoom,0.75;set_use_effect_clock_for_texcoords,true;effectclock,'beat')
	};
	LoadActor("2 (stretch)")..{
		OnCommand=cmd(x,448;y,300;texcoordvelocity,0.075*5,0.075*5;zoom,0.75;set_use_effect_clock_for_texcoords,true;effectclock,'beat')
	};
	LoadActor("2 (stretch)")..{
		OnCommand=cmd(x,576;y,300;texcoordvelocity,0.075*5,0.075*5;zoom,0.75;set_use_effect_clock_for_texcoords,true;effectclock,'beat')
	};
	LoadActor("2 (stretch)")..{
		OnCommand=cmd(x,704;y,300;texcoordvelocity,0.075*5,0.075*5;zoom,0.75;set_use_effect_clock_for_texcoords,true;effectclock,'beat')
	};
	LoadActor("2 (stretch)")..{
		OnCommand=cmd(x,832;y,300;texcoordvelocity,0.075*5,0.075*5;zoom,0.75;set_use_effect_clock_for_texcoords,true;effectclock,'beat')
	};
	LoadActor("2 (stretch)")..{
		OnCommand=cmd(x,64;y,420;texcoordvelocity,0.075*5,0.075*5;zoom,0.75;set_use_effect_clock_for_texcoords,true;effectclock,'beat')
	};
	LoadActor("2 (stretch)")..{
		OnCommand=cmd(x,192;y,420;texcoordvelocity,0.075*5,0.075*5;zoom,0.75;set_use_effect_clock_for_texcoords,true;effectclock,'beat')
	};
	LoadActor("2 (stretch)")..{
		OnCommand=cmd(x,320;y,420;texcoordvelocity,0.075*5,0.075*5;zoom,0.75;set_use_effect_clock_for_texcoords,true;effectclock,'beat')
	};
	LoadActor("2 (stretch)")..{
		OnCommand=cmd(x,448;y,420;texcoordvelocity,0.075*5,0.075*5;zoom,0.75;set_use_effect_clock_for_texcoords,true;effectclock,'beat')
	};
	LoadActor("2 (stretch)")..{
		OnCommand=cmd(x,576;y,420;texcoordvelocity,0.075*5,0.075*5;zoom,0.75;set_use_effect_clock_for_texcoords,true;effectclock,'beat')
	};
	LoadActor("2 (stretch)")..{
		OnCommand=cmd(x,704;y,420;texcoordvelocity,0.075*5,0.075*5;zoom,0.75;set_use_effect_clock_for_texcoords,true;effectclock,'beat')
	};
	LoadActor("2 (stretch)")..{
		OnCommand=cmd(x,832;y,420;texcoordvelocity,0.075*5,0.075*5;zoom,0.75;set_use_effect_clock_for_texcoords,true;effectclock,'beat')
	};
};

return t;
return Def.ActorFrame{
	OnCommand=function(self) self:playcommand("Repeat") end,
	
		Def.Sprite{
		Texture = "1.png", 
		Frames = {{Delay= 0.5, Frame= 0}, {Delay= 0.5, Frame= 1}},
		OnCommand=function(self)
		self:x(80)
		:y(60)
		:zoom(0):sleep(4):linear(0.25):zoom(1):sleep(4):linear(0.25):zoom(0):queuecommand("On")
		:set_tween_uses_effect_delta(true):effectclock('beat')
		end
	};
		Def.Sprite{
		Texture = "2.png", 
		Frames = {{Delay= 0.5, Frame= 0}, {Delay= 0.5, Frame= 1}},
		OnCommand=function(self)
		self:x(80+160)
		:y(60)
		:zoom(0):sleep(4.25):linear(0.25):zoom(1):sleep(4.25):linear(0.25):zoom(0):queuecommand("On")
		:set_tween_uses_effect_delta(true):effectclock('beat')
		end
	};
		Def.Sprite{
		Texture = "1.png", 
		Frames = {{Delay= 0.5, Frame= 0}, {Delay= 0.5, Frame= 1}},
		OnCommand=function(self)
		self:x(80+320)
		:y(60)
		:zoom(0):sleep(4.5):linear(0.25):zoom(1):sleep(4.5):linear(0.25):zoom(0):queuecommand("On")
		:set_tween_uses_effect_delta(true):effectclock('beat')
		end
	};
		Def.Sprite{
		Texture = "2.png", 
		Frames = {{Delay= 0.5, Frame= 0}, {Delay= 0.5, Frame= 1}},
		OnCommand=function(self)
		self:x(80+480)
		:y(60)
		:zoom(0):sleep(4.75):linear(0.25):zoom(1):sleep(4.75):linear(0.25):zoom(0):queuecommand("On")
		:set_tween_uses_effect_delta(true):effectclock('beat')
		end
	};
		Def.Sprite{
		Texture = "1.png", 
		Frames = {{Delay= 0.5, Frame= 0}, {Delay= 0.5, Frame= 1}},
		OnCommand=function(self)
		self:x(80+480)
		:y(60*3)
		:zoom(0):sleep(5):linear(0.25):zoom(1):sleep(5):linear(0.25):zoom(0):queuecommand("On")
		:set_tween_uses_effect_delta(true):effectclock('beat')
		end
	};
		Def.Sprite{
		Texture = "2.png", 
		Frames = {{Delay= 0.5, Frame= 0}, {Delay= 0.5, Frame= 1}},
		OnCommand=function(self)
		self:x(80+480)
		:y(60+240)
		:zoom(0):sleep(5.25):linear(0.25):zoom(1):sleep(5.25):linear(0.25):zoom(0):queuecommand("On")
		:set_tween_uses_effect_delta(true):effectclock('beat')
		end
	};
		Def.Sprite{
		Texture = "1.png", 
		Frames = {{Delay= 0.5, Frame= 0}, {Delay= 0.5, Frame= 1}},
		OnCommand=function(self)
		self:x(80+480)
		:y(60+360)
		:zoom(0):sleep(5.5):linear(0.25):zoom(1):sleep(5.5):linear(0.25):zoom(0):queuecommand("On")
		:set_tween_uses_effect_delta(true):effectclock('beat')
		end
	};
		Def.Sprite{
		Texture = "2.png", 
		Frames = {{Delay= 0.5, Frame= 0}, {Delay= 0.5, Frame= 1}},
		OnCommand=function(self)
		self:x(80+320)
		:y(60+360)
		:zoom(0):sleep(5.75):linear(0.25):zoom(1):sleep(5.75):linear(0.25):zoom(0):queuecommand("On")
		:set_tween_uses_effect_delta(true):effectclock('beat')
		end
	};
		Def.Sprite{
		Texture = "1.png", 
		Frames = {{Delay= 0.5, Frame= 0}, {Delay= 0.5, Frame= 1}},
		OnCommand=function(self)
		self:x(80+160)
		:y(60+360)
		:zoom(0):sleep(6):linear(0.25):zoom(1):sleep(6):linear(0.25):zoom(0):queuecommand("On")
		:set_tween_uses_effect_delta(true):effectclock('beat')
		end
	};
		Def.Sprite{
		Texture = "2.png", 
		Frames = {{Delay= 0.5, Frame= 0}, {Delay= 0.5, Frame= 1}},
		OnCommand=function(self)
		self:x(80)
		:y(60+360)
		:zoom(0):sleep(6.25):linear(0.25):zoom(1):sleep(6.25):linear(0.25):zoom(0):queuecommand("On")
		:set_tween_uses_effect_delta(true):effectclock('beat')
		end
	};
		Def.Sprite{
		Texture = "1.png", 
		Frames = {{Delay= 0.5, Frame= 0}, {Delay= 0.5, Frame= 1}},
		OnCommand=function(self)
		self:x(80)
		:y(60+240)
		:zoom(0):sleep(6.5):linear(0.25):zoom(1):sleep(6.5):linear(0.25):zoom(0):queuecommand("On")
		:set_tween_uses_effect_delta(true):effectclock('beat')
		end
	};
		Def.Sprite{
		Texture = "2.png", 
		Frames = {{Delay= 0.5, Frame= 0}, {Delay= 0.5, Frame= 1}},
		OnCommand=function(self)
		self:x(80)
		:y(60*3)
		:zoom(0):sleep(6.75):linear(0.25):zoom(1):sleep(6.75):linear(0.25):zoom(0):queuecommand("On")
		:set_tween_uses_effect_delta(true):effectclock('beat')
		end
	};
		Def.Sprite{
		Texture = "1.png", 
		Frames = {{Delay= 0.5, Frame= 0}, {Delay= 0.5, Frame= 1}},
		OnCommand=function(self)
		self:x(80+160)
		:y(60*3)
		:zoom(0):sleep(7):linear(0.25):zoom(1):sleep(7):linear(0.25):zoom(0):queuecommand("On")
		:set_tween_uses_effect_delta(true):effectclock('beat')
		end
	};
		Def.Sprite{
		Texture = "2.png", 
		Frames = {{Delay= 0.5, Frame= 0}, {Delay= 0.5, Frame= 1}},
		OnCommand=function(self)
		self:x(80+320)
		:y(60*3)
		:zoom(0):sleep(7.25):linear(0.25):zoom(1):sleep(7.25):linear(0.25):zoom(0):queuecommand("On")
		:set_tween_uses_effect_delta(true):effectclock('beat')
		end
	};
		Def.Sprite{
		Texture = "1.png", 
		Frames = {{Delay= 0.5, Frame= 0}, {Delay= 0.5, Frame= 1}},
		OnCommand=function(self)
		self:x(80+320)
		:y(60+240)
		:zoom(0):sleep(7.5):linear(0.25):zoom(1):sleep(7.5):linear(0.25):zoom(0):queuecommand("On")
		:set_tween_uses_effect_delta(true):effectclock('beat')
		end
	};
		Def.Sprite{
		Texture = "2.png", 
		Frames = {{Delay= 0.5, Frame= 0}, {Delay= 0.5, Frame= 1}},
		OnCommand=function(self)
		self:x(80+160)
		:y(60+240)
		:zoom(0):sleep(7.75):linear(0.25):zoom(1):sleep(7.75):linear(0.25):zoom(0):queuecommand("On")
		:set_tween_uses_effect_delta(true):effectclock('beat')
		end
	};
}
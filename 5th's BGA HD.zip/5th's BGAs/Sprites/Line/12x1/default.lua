local file = ...

return Def.ActorFrame{
	OnCommand=function(self) self:playcommand("Repeat") end,
	
		Def.Sprite{
		Texture = file, 
		Frames = {{Delay= 0.09, Frame= 0}, {Delay= 0.09, Frame= 1}, {Delay= 0.09, Frame= 2}, {Delay= 0.09, Frame= 3}, {Delay= 0.09, Frame= 4}, {Delay= 0.09, Frame= 5}, {Delay= 0.09, Frame= 6}, {Delay= 0.09, Frame= 7}, {Delay= 0.09, Frame= 8}, {Delay= 0.09, Frame= 9}, {Delay= 0.09, Frame= 10}, {Delay= 0.09, Frame= 11}},
		OnCommand=function(self)
		self:x(SCREEN_LEFT-64*2-math.random(64,64*4))
		:y(SCREEN_TOP)
		:linear(math.random(6.000,8.000))
		:x(SCREEN_RIGHT+64*2+math.random(64,64*4))
		:setstate(0)
		:effectclock("beat"):set_tween_uses_effect_delta(true)
		:queuecommand("On")
		end;
	};
	
		Def.Sprite{
		Texture = file, 
		Frames = {{Delay= 0.09, Frame= 0}, {Delay= 0.09, Frame= 1}, {Delay= 0.09, Frame= 2}, {Delay= 0.09, Frame= 3}, {Delay= 0.09, Frame= 4}, {Delay= 0.09, Frame= 5}, {Delay= 0.09, Frame= 6}, {Delay= 0.09, Frame= 7}, {Delay= 0.09, Frame= 8}, {Delay= 0.09, Frame= 9}, {Delay= 0.09, Frame= 10}, {Delay= 0.09, Frame= 11}},
		OnCommand=function(self)
		self:x(SCREEN_RIGHT+64*2+math.random(64,64*4))
		:y(SCREEN_CENTER_Y-64*2)
		:linear(math.random(6.000,8.000))
		:setstate(1)
		:effectclock("beat"):set_tween_uses_effect_delta(true)
		:x(SCREEN_LEFT-64*2-math.random(64,64*4))
		:queuecommand("On")
		end;
	};
	
		Def.Sprite{
		Texture = file, 
		Frames = {{Delay= 0.09, Frame= 0}, {Delay= 0.09, Frame= 1}, {Delay= 0.09, Frame= 2}, {Delay= 0.09, Frame= 3}, {Delay= 0.09, Frame= 4}, {Delay= 0.09, Frame= 5}, {Delay= 0.09, Frame= 6}, {Delay= 0.09, Frame= 7}, {Delay= 0.09, Frame= 8}, {Delay= 0.09, Frame= 9}, {Delay= 0.09, Frame= 10}, {Delay= 0.09, Frame= 11}},
		OnCommand=function(self)
		self:x(SCREEN_LEFT-64*2-math.random(64,64*4))
		:y(SCREEN_CENTER_Y)
		:linear(math.random(6.000,8.000))
		:setstate(2)
		:effectclock("beat"):set_tween_uses_effect_delta(true)
		:x(SCREEN_RIGHT+64*2+math.random(64,64*4))
		:queuecommand("On")
		end;
	};
	
		Def.Sprite{
		Texture = file, 
		Frames = {{Delay= 0.09, Frame= 0}, {Delay= 0.09, Frame= 1}, {Delay= 0.09, Frame= 2}, {Delay= 0.09, Frame= 3}, {Delay= 0.09, Frame= 4}, {Delay= 0.09, Frame= 5}, {Delay= 0.09, Frame= 6}, {Delay= 0.09, Frame= 7}, {Delay= 0.09, Frame= 8}, {Delay= 0.09, Frame= 9}, {Delay= 0.09, Frame= 10}, {Delay= 0.09, Frame= 11}},
		OnCommand=function(self)
		self:x(SCREEN_RIGHT+64*2+math.random(64,64*4))
		:y(SCREEN_CENTER_Y+64*2)
		:linear(math.random(6.000,8.000))
		:setstate(3)
		:effectclock("beat"):set_tween_uses_effect_delta(true)
		:x(SCREEN_LEFT-64*2-math.random(64,64*4))
		:queuecommand("On")
		end;
	};
	
		Def.Sprite{
		Texture = file, 
		Frames = {{Delay= 0.09, Frame= 0}, {Delay= 0.09, Frame= 1}, {Delay= 0.09, Frame= 2}, {Delay= 0.09, Frame= 3}, {Delay= 0.09, Frame= 4}, {Delay= 0.09, Frame= 5}, {Delay= 0.09, Frame= 6}, {Delay= 0.09, Frame= 7}, {Delay= 0.09, Frame= 8}, {Delay= 0.09, Frame= 9}, {Delay= 0.09, Frame= 10}, {Delay= 0.09, Frame= 11}},
		OnCommand=function(self)
		self:x(SCREEN_LEFT-64*2-math.random(64,64*4))
		:y(SCREEN_BOTTOM)
		:linear(math.random(6.000,8.000))
		:setstate(4)
		:effectclock("beat"):set_tween_uses_effect_delta(true)
		:x(SCREEN_RIGHT+64*2+math.random(64,64*4))
		:queuecommand("On")
		end;
	};
	
--

		Def.Sprite{
		Texture = file, 
		Frames = {{Delay= 0.09, Frame= 0}, {Delay= 0.09, Frame= 1}, {Delay= 0.09, Frame= 2}, {Delay= 0.09, Frame= 3}, {Delay= 0.09, Frame= 4}, {Delay= 0.09, Frame= 5}, {Delay= 0.09, Frame= 6}, {Delay= 0.09, Frame= 7}, {Delay= 0.09, Frame= 8}, {Delay= 0.09, Frame= 9}, {Delay= 0.09, Frame= 10}, {Delay= 0.09, Frame= 11}},
		OnCommand=function(self)
		self:y(SCREEN_TOP-64*2-math.random(64,64*4))
		:x(SCREEN_LEFT+64)
		:linear(math.random(6.000*2,8.000*2)/2)
		:setstate(5)
		:effectclock("beat"):set_tween_uses_effect_delta(true)
		:y(SCREEN_BOTTOM+64*2+math.random(64,64*4))
		:queuecommand("On")
		end;
	};
	
		Def.Sprite{
		Texture = file, 
		Frames = {{Delay= 0.09, Frame= 0}, {Delay= 0.09, Frame= 1}, {Delay= 0.09, Frame= 2}, {Delay= 0.09, Frame= 3}, {Delay= 0.09, Frame= 4}, {Delay= 0.09, Frame= 5}, {Delay= 0.09, Frame= 6}, {Delay= 0.09, Frame= 7}, {Delay= 0.09, Frame= 8}, {Delay= 0.09, Frame= 9}, {Delay= 0.09, Frame= 10}, {Delay= 0.09, Frame= 11}},
		OnCommand=function(self)
		self:y(SCREEN_BOTTOM+64*2+math.random(64,64*4))
		:x(SCREEN_CENTER_X-64*2)
		:linear(math.random(6.000*2,8.000*2)/2)
		:setstate(6)
		:effectclock("beat"):set_tween_uses_effect_delta(true)
		:y(SCREEN_TOP-64*2-math.random(64,64*4))
		:queuecommand("On")
		end;
	};
	
		Def.Sprite{
		Texture = file, 
		Frames = {{Delay= 0.09, Frame= 0}, {Delay= 0.09, Frame= 1}, {Delay= 0.09, Frame= 2}, {Delay= 0.09, Frame= 3}, {Delay= 0.09, Frame= 4}, {Delay= 0.09, Frame= 5}, {Delay= 0.09, Frame= 6}, {Delay= 0.09, Frame= 7}, {Delay= 0.09, Frame= 8}, {Delay= 0.09, Frame= 9}, {Delay= 0.09, Frame= 10}, {Delay= 0.09, Frame= 11}},
		OnCommand=function(self)
		self:y(SCREEN_TOP-64*2-math.random(64,64*4))
		:x(SCREEN_CENTER_X)
		:linear(math.random(6.000*2,8.000*2)/2)
		:setstate(7)
		:effectclock("beat"):set_tween_uses_effect_delta(true)
		:y(SCREEN_BOTTOM+64*2+math.random(64,64*4))
		:queuecommand("On")
		end;
	};
	
		Def.Sprite{
		Texture = file, 
		Frames = {{Delay= 0.09, Frame= 0}, {Delay= 0.09, Frame= 1}, {Delay= 0.09, Frame= 2}, {Delay= 0.09, Frame= 3}, {Delay= 0.09, Frame= 4}, {Delay= 0.09, Frame= 5}, {Delay= 0.09, Frame= 6}, {Delay= 0.09, Frame= 7}, {Delay= 0.09, Frame= 8}, {Delay= 0.09, Frame= 9}, {Delay= 0.09, Frame= 10}, {Delay= 0.09, Frame= 11}},
		OnCommand=function(self)
		self:y(SCREEN_BOTTOM+64*2+math.random(64,64*4))
		:x(SCREEN_CENTER_X+64*2)
		:linear(math.random(6.000*2,8.000*2)/2)
		:setstate(8)
		:effectclock("beat"):set_tween_uses_effect_delta(true)
		:y(SCREEN_TOP-64*2-math.random(64,64*4))
		:queuecommand("On")
		end;
	};
	
		Def.Sprite{
		Texture = file, 
		Frames = {{Delay= 0.09, Frame= 0}, {Delay= 0.09, Frame= 1}, {Delay= 0.09, Frame= 2}, {Delay= 0.09, Frame= 3}, {Delay= 0.09, Frame= 4}, {Delay= 0.09, Frame= 5}, {Delay= 0.09, Frame= 6}, {Delay= 0.09, Frame= 7}, {Delay= 0.09, Frame= 8}, {Delay= 0.09, Frame= 9}, {Delay= 0.09, Frame= 10}, {Delay= 0.09, Frame= 11}},
		OnCommand=function(self)
		self:y(SCREEN_TOP-64*2-math.random(64,64*4))
		:x(SCREEN_RIGHT-64)
		:linear(math.random(6.000*2,8.000*2)/2)
		:setstate(9)
		:effectclock("beat"):set_tween_uses_effect_delta(true)
		:y(SCREEN_BOTTOM+64*2+math.random(64,64*4))
		:queuecommand("On")
		end;
	};
}
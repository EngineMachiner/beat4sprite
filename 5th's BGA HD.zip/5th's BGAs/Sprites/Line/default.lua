local file = 

...

return Def.ActorFrame{
	OnCommand=function(self) self:playcommand("Repeat") end,
	
		Def.Sprite{
		Texture = file, 
		Frames = {{Delay= 0.5, Frame= 0}, {Delay= 0.5, Frame= 1}},
		OnCommand=function(self)
		self:x(SCREEN_LEFT-64*2-math.random(64,64*4))
		:zoom(2)
		:y(SCREEN_TOP)
		:linear(math.random(6.000,8.000))
		:x(SCREEN_RIGHT+64*2+math.random(64,64*4))
		:set_tween_uses_effect_delta(true):effectclock("beat")
		:queuecommand("On")
		end;
	};
	
		Def.Sprite{
		Texture = file, 
		Frames = {{Delay= 0.5, Frame= 0}, {Delay= 0.5, Frame= 1}},
		OnCommand=function(self)
		self:x(SCREEN_RIGHT+64*2+math.random(64,64*4))
		:zoom(2)
		:y(SCREEN_CENTER_Y-64*2)
		:linear(math.random(6.000,8.000))
		:x(SCREEN_LEFT-64*2-math.random(64,64*4))
		:set_tween_uses_effect_delta(true):effectclock("beat")
		:queuecommand("On")
		end;
	};
	
		Def.Sprite{
		Texture = file, 
		Frames = {{Delay= 0.5, Frame= 0}, {Delay= 0.5, Frame= 1}},
		OnCommand=function(self)
		self:x(SCREEN_LEFT-64*2-math.random(64,64*4))
		:zoom(2)
		:y(SCREEN_CENTER_Y)
		:linear(math.random(6.000,8.000))
		:x(SCREEN_RIGHT+64*2+math.random(64,64*4))
		:set_tween_uses_effect_delta(true):effectclock("beat")
		:queuecommand("On")
		end;
	};
	
		Def.Sprite{
		Texture = file, 
		Frames = {{Delay= 0.5, Frame= 0}, {Delay= 0.5, Frame= 1}},
		OnCommand=function(self)
		self:x(SCREEN_RIGHT+64*2+math.random(64,64*4))
		:zoom(2)
		:y(SCREEN_CENTER_Y+64*2)
		:linear(math.random(6.000,8.000))
		:x(SCREEN_LEFT-64*2-math.random(64,64*4))
		:set_tween_uses_effect_delta(true):effectclock("beat")
		:queuecommand("On")
		end;
	};
	
		Def.Sprite{
		Texture = file, 
		Frames = {{Delay= 0.5, Frame= 0}, {Delay= 0.5, Frame= 1}},
		OnCommand=function(self)
		self:x(SCREEN_LEFT-64*2-math.random(64,64*4))
		:zoom(2)
		:y(SCREEN_BOTTOM)
		:linear(math.random(6.000,8.000))
		:x(SCREEN_RIGHT+64*2+math.random(64,64*4))
		:set_tween_uses_effect_delta(true):effectclock("beat")
		:queuecommand("On")
		end;
	};
	
--

		Def.Sprite{
		Texture = file, 
		Frames = {{Delay= 0.5, Frame= 0}, {Delay= 0.5, Frame= 1}},
		OnCommand=function(self)
		self:y(SCREEN_TOP-64*2-math.random(64,64*4))
		:zoom(2)
		:x(SCREEN_LEFT+64)
		:linear(math.random(6.000*2,8.000*2)/2)
		:y(SCREEN_BOTTOM+64*2+math.random(64,64*4))
		:set_tween_uses_effect_delta(true):effectclock("beat")
		:queuecommand("On")
		end;
	};
	
		Def.Sprite{
		Texture = file, 
		Frames = {{Delay= 0.5, Frame= 0}, {Delay= 0.5, Frame= 1}},
		OnCommand=function(self)
		self:y(SCREEN_BOTTOM+64*2+math.random(64,64*4))
		:zoom(2)
		:x(SCREEN_CENTER_X-64*2)
		:linear(math.random(6.000*2,8.000*2)/2)
		:y(SCREEN_TOP-64*2-math.random(64,64*4))
		:set_tween_uses_effect_delta(true):effectclock("beat")
		:queuecommand("On")
		end;
	};
	
		Def.Sprite{
		Texture = file, 
		Frames = {{Delay= 0.5, Frame= 0}, {Delay= 0.5, Frame= 1}},
		OnCommand=function(self)
		self:y(SCREEN_TOP-64*2-math.random(64,64*4))
		:zoom(2)
		:x(SCREEN_CENTER_X)
		:linear(math.random(6.000*2,8.000*2)/2)
		:y(SCREEN_BOTTOM+64*2+math.random(64,64*4))
		:set_tween_uses_effect_delta(true):effectclock("beat")
		:queuecommand("On")
		end;
	};
	
		Def.Sprite{
		Texture = file, 
		Frames = {{Delay= 0.5, Frame= 0}, {Delay= 0.5, Frame= 1}},
		OnCommand=function(self)
		self:y(SCREEN_BOTTOM+64*2+math.random(64,64*4))
		:zoom(2)
		:x(SCREEN_CENTER_X+64*2)
		:linear(math.random(6.000*2,8.000*2)/2)
		:y(SCREEN_TOP-64*2-math.random(64,64*4))
		:set_tween_uses_effect_delta(true):effectclock("beat")
		:queuecommand("On")
		end;
	};
	
		Def.Sprite{
		Texture = file, 
		Frames = {{Delay= 0.5, Frame= 0}, {Delay= 0.5, Frame= 1}},
		OnCommand=function(self)
		self:y(SCREEN_TOP-64*2-math.random(64,64*4))
		:zoom(2)
		:x(SCREEN_RIGHT-64)
		:linear(math.random(6.000*2,8.000*2)/2)
		:y(SCREEN_BOTTOM+64*2+math.random(64,64*4))
		:set_tween_uses_effect_delta(true):effectclock("beat")
		:queuecommand("On")
		end;
	};
}
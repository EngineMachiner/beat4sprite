local v = {1,3}
local n = math.random(#v)

local dt = math.random(2.5,3)
local dt2 = math.random(1,6)

local dx = n*math.random(10,15*1.25)
local dx2 = n*math.random(0.3000,1.000)

local file = 

...
 
return Def.ActorFrame{
	OnCommand=function(self) self:playcommand("Repeat") end,

		Def.Sprite{
		Texture = "Burn 2x1.png", 
		Frames = {{Delay= 0.5, Frame= 0}, {Delay= 0.5, Frame= 1}},
		RepeatCommand=function(self)
		if n == 1 then 
			self:zoom(0.8) local dx = n*math.random(16,19*1.5) 
			self:x(-_screen.w+math.random(_screen.w,(_screen.w*2)))
			:setstate(math.random(0,5))
			:y(_screen.h+64*dt2/1.5)
			:linear(dx/5+dx2/5)
			:effectclock('beat'):set_tween_uses_effect_delta(true)
			:y(-_screen.h-64*dt2*n)
		else self:zoom(1) 
			self:x(-_screen.w+math.random(_screen.w,(_screen.w*2)))
			:setstate(math.random(0,5))
			:y(_screen.h+64*dt2/1.5)
			:linear(dx/5+dx2/5)
			:effectclock('beat'):set_tween_uses_effect_delta(true)
			:y(-_screen.h-64*dt2*n)
			end;
			self:queuecommand("Repeat")
			end;
	},

}
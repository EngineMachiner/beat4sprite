-- create a variable to be loaded in each Actor
-- the ... syntax is an argument that has been passed
-- in from another file
-- if no argument is passed in, load "(Something).png" as a fallback
local file = 

... or 
"2 Scissors 2x1.png"


return Def.ActorFrame{
	OnCommand=function(self) self:playcommand("Repeat") end,
	
	LoadActor( file )..{
		RepeatCommand=cmd(x,math.random(0, _screen.w);y,math.random(0, _screen.h);sleep,0.5;x,math.random(0, _screen.w);y,math.random(0, _screen.h); effectclock,'beat';  queuecommand,"Repeat");
	},

	LoadActor( file )..{
		RepeatCommand=cmd(x,math.random(0, _screen.w);y,math.random(0, _screen.h);sleep,0.5;x,math.random(0, _screen.w);y,math.random(0, _screen.h); effectclock,'beat';  queuecommand,"Repeat");
	},

	LoadActor( file )..{
		RepeatCommand=cmd(x,math.random(0, _screen.w);y,math.random(0, _screen.h);sleep,0.5;x,math.random(0, _screen.w);y,math.random(0, _screen.h); effectclock,'beat';  queuecommand,"Repeat");
	},

	LoadActor( file )..{
		RepeatCommand=cmd(x,math.random(0, _screen.w);y,math.random(0, _screen.h);sleep,0.5;x,math.random(0, _screen.w);y,math.random(0, _screen.h); effectclock,'beat';  queuecommand,"Repeat");
	},

	LoadActor( file )..{
		RepeatCommand=cmd(x,math.random(0, _screen.w);y,math.random(0, _screen.h);sleep,0.5;x,math.random(0, _screen.w);y,math.random(0, _screen.h); effectclock,'beat';  queuecommand,"Repeat");
	},

	LoadActor( file )..{
		RepeatCommand=cmd(x,math.random(0, _screen.w);y,math.random(0, _screen.h);sleep,0.5;x,math.random(0, _screen.w);y,math.random(0, _screen.h); effectclock,'beat';  queuecommand,"Repeat");
	},

	LoadActor( file )..{
		RepeatCommand=cmd(x,math.random(0, _screen.w);y,math.random(0, _screen.h);sleep,0.5;x,math.random(0, _screen.w);y,math.random(0, _screen.h); effectclock,'beat';  queuecommand,"Repeat");
	},

	LoadActor( file )..{
		RepeatCommand=cmd(x,math.random(0, _screen.w);y,math.random(0, _screen.h);sleep,0.5;x,math.random(0, _screen.w);y,math.random(0, _screen.h); effectclock,'beat';  queuecommand,"Repeat");
	},

	LoadActor( file )..{
		RepeatCommand=cmd(x,math.random(0, _screen.w);y,math.random(0, _screen.h);sleep,0.5;x,math.random(0, _screen.w);y,math.random(0, _screen.h); effectclock,'beat';  queuecommand,"Repeat");
	},
	
}
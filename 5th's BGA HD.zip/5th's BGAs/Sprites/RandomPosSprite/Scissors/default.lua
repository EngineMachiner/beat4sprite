-- create a variable to be loaded in each Actor
-- the ... syntax is an argument that has been passed
-- in from another file
-- if no argument is passed in, load "(Something).png" as a fallback
local file = 

... or 
"2 Scissors 2x1.png"


return Def.ActorFrame{
	OnCommand=function(self) self:playcommand("Repeat") end,
	
			Def.Sprite{
		Texture = file, 
		Frames = {{Delay= 0.5, Frame= 0}, {Delay= 0.5, Frame= 1}},
		RepeatCommand=cmd(zoom,2;effectclock,"beat";rainbow;effectoffset,0.1;rotationz,math.random(0,360);x,math.random(0, _screen.w);y,math.random(0, _screen.h);sleep,1;rotationz,math.random(0,360);x,math.random(0, _screen.w);y,math.random(0, _screen.h);setstate,math.random(0,1);  queuecommand,"Repeat");
	},

			Def.Sprite{
		Texture = file, 
		Frames = {{Delay= 0.5, Frame= 0}, {Delay= 0.5, Frame= 1}},
		RepeatCommand=cmd(zoom,2;effectclock,"beat";rainbow;effectoffset,0.2;rotationz,math.random(0,360);x,math.random(0, _screen.w);y,math.random(0, _screen.h);sleep,1;rotationz,math.random(0,360);x,math.random(0, _screen.w);y,math.random(0, _screen.h);setstate,math.random(0,1);  queuecommand,"Repeat");
	},

			Def.Sprite{
		Texture = file, 
		Frames = {{Delay= 0.5, Frame= 0}, {Delay= 0.5, Frame= 1}},
		RepeatCommand=cmd(zoom,2;effectclock,"beat";rainbow;effectoffset,0.3;rotationz,math.random(0,360);x,math.random(0, _screen.w);y,math.random(0, _screen.h);sleep,1;rotationz,math.random(0,360);x,math.random(0, _screen.w);y,math.random(0, _screen.h);setstate,math.random(0,1);  queuecommand,"Repeat");
	},

			Def.Sprite{
		Texture = file, 
		Frames = {{Delay= 0.5, Frame= 0}, {Delay= 0.5, Frame= 1}},
		RepeatCommand=cmd(zoom,2;effectclock,"beat";rainbow;effectoffset,0.4;rotationz,math.random(0,360);x,math.random(0, _screen.w);y,math.random(0, _screen.h);sleep,1;rotationz,math.random(0,360);x,math.random(0, _screen.w);y,math.random(0, _screen.h);setstate,math.random(0,1);  queuecommand,"Repeat");
	},

			Def.Sprite{
		Texture = file, 
		Frames = {{Delay= 0.5, Frame= 0}, {Delay= 0.5, Frame= 1}},
		RepeatCommand=cmd(zoom,2;effectclock,"beat";rainbow;effectoffset,0.5;rotationz,math.random(0,360);x,math.random(0, _screen.w);y,math.random(0, _screen.h);sleep,1;rotationz,math.random(0,360);x,math.random(0, _screen.w);y,math.random(0, _screen.h);setstate,math.random(0,1);  queuecommand,"Repeat");
	},

			Def.Sprite{
		Texture = file, 
		Frames = {{Delay= 0.5, Frame= 0}, {Delay= 0.5, Frame= 1}},
		RepeatCommand=cmd(zoom,2;effectclock,"beat";rainbow;effectoffset,0.6;rotationz,math.random(0,360);x,math.random(0, _screen.w);y,math.random(0, _screen.h);sleep,1;rotationz,math.random(0,360);x,math.random(0, _screen.w);y,math.random(0, _screen.h);setstate,math.random(0,1);  queuecommand,"Repeat");
	},

			Def.Sprite{
		Texture = file, 
		Frames = {{Delay= 0.5, Frame= 0}, {Delay= 0.5, Frame= 1}},
		RepeatCommand=cmd(zoom,2;effectclock,"beat";rainbow;effectoffset,0.7;rotationz,math.random(0,360);x,math.random(0, _screen.w);y,math.random(0, _screen.h);sleep,1;rotationz,math.random(0,360);x,math.random(0, _screen.w);y,math.random(0, _screen.h);setstate,math.random(0,1);  queuecommand,"Repeat");
	},

			Def.Sprite{
		Texture = file, 
		Frames = {{Delay= 0.5, Frame= 0}, {Delay= 0.5, Frame= 1}},
		RepeatCommand=cmd(zoom,2;effectclock,"beat";rainbow;effectoffset,0.8;rotationz,math.random(0,360);x,math.random(0, _screen.w);y,math.random(0, _screen.h);sleep,1;rotationz,math.random(0,360);x,math.random(0, _screen.w);y,math.random(0, _screen.h);setstate,math.random(0,1);  queuecommand,"Repeat");
	},

			Def.Sprite{
		Texture = file, 
		Frames = {{Delay= 0.5, Frame= 0}, {Delay= 0.5, Frame= 1}},
		RepeatCommand=cmd(zoom,2;effectclock,"beat";rainbow;effectoffset,0.9;rotationz,math.random(0,360);x,math.random(0, _screen.w);y,math.random(0, _screen.h);sleep,1;rotationz,math.random(0,360);x,math.random(0, _screen.w);y,math.random(0, _screen.h);setstate,math.random(0,1);  queuecommand,"Repeat");
	},
			Def.Sprite{
		Texture = file, 
		Frames = {{Delay= 0.5, Frame= 0}, {Delay= 0.5, Frame= 1}},
		RepeatCommand=cmd(zoom,2;effectclock,"beat";rainbow;effectoffset,1;rotationz,math.random(0,360);x,math.random(0, _screen.w);y,math.random(0, _screen.h);sleep,1;rotationz,math.random(0,360);x,math.random(0, _screen.w);y,math.random(0, _screen.h);setstate,math.random(0,1);  queuecommand,"Repeat");
	},
			Def.Sprite{
		Texture = file, 
		Frames = {{Delay= 0.5, Frame= 0}, {Delay= 0.5, Frame= 1}},
		RepeatCommand=cmd(zoom,2;effectclock,"beat";rainbow;effectoffset,1.1;rotationz,math.random(0,360);x,math.random(0, _screen.w);y,math.random(0, _screen.h);sleep,1;rotationz,math.random(0,360);x,math.random(0, _screen.w);y,math.random(0, _screen.h);setstate,math.random(0,1);  queuecommand,"Repeat");
	},
			Def.Sprite{
		Texture = file, 
		Frames = {{Delay= 0.5, Frame= 0}, {Delay= 0.5, Frame= 1}},
		RepeatCommand=cmd(zoom,2;effectclock,"beat";rainbow;effectoffset,1.2;rotationz,math.random(0,360);x,math.random(0, _screen.w);y,math.random(0, _screen.h);sleep,1;rotationz,math.random(0,360);x,math.random(0, _screen.w);y,math.random(0, _screen.h);setstate,math.random(0,1);  queuecommand,"Repeat");
	},
			Def.Sprite{
		Texture = file, 
		Frames = {{Delay= 0.5, Frame= 0}, {Delay= 0.5, Frame= 1}},
		RepeatCommand=cmd(zoom,2;effectclock,"beat";rainbow;effectoffset,1.3;rotationz,math.random(0,360);x,math.random(0, _screen.w);y,math.random(0, _screen.h);sleep,1;rotationz,math.random(0,360);x,math.random(0, _screen.w);y,math.random(0, _screen.h);setstate,math.random(0,1);  queuecommand,"Repeat");
	},
			Def.Sprite{
		Texture = file, 
		Frames = {{Delay= 0.5, Frame= 0}, {Delay= 0.5, Frame= 1}},
		RepeatCommand=cmd(zoom,2;effectclock,"beat";rainbow;effectoffset,1.4;rotationz,math.random(0,360);x,math.random(0, _screen.w);y,math.random(0, _screen.h);sleep,1;rotationz,math.random(0,360);x,math.random(0, _screen.w);y,math.random(0, _screen.h);setstate,math.random(0,1);  queuecommand,"Repeat");
	},
			Def.Sprite{
		Texture = file, 
		Frames = {{Delay= 0.5, Frame= 0}, {Delay= 0.5, Frame= 1}},
		RepeatCommand=cmd(zoom,2;effectclock,"beat";rainbow;effectoffset,1.5;rotationz,math.random(0,360);x,math.random(0, _screen.w);y,math.random(0, _screen.h);sleep,1;rotationz,math.random(0,360);x,math.random(0, _screen.w);y,math.random(0, _screen.h);setstate,math.random(0,1);  queuecommand,"Repeat");
	},
	
}
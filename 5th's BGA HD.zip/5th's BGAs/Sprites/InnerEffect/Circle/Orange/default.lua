-- create a variable to be loaded in each Actor
-- the ... syntax is an argument that has been passed
-- in from another file
-- if no argument is passed in, load "flower.png" as a fallback
local file = ...

-- These same things were happening again and again to EVERY actor
-- and the only thing different was the duration of the tween.
-- It makes sense to use a function here.  There is less code duplication
-- and less opportunity to make a typo somewhere, once.

return Def.ActorFrame{
	OnCommand=function(self) self:playcommand("Repeat") end,

	LoadActor( file )..{
		RepeatCommand=function(self)
			self:zoom(0.75/2):diffusealpha(0)
			:xy(SCREEN_CENTER_X+(64*2),SCREEN_CENTER_Y)
			:linear(1.2/2):zoom(0.75):diffusealpha(1):accelerate(0.015)
			:smooth(1)
			:addx(64*6):addy(-64*6)
			:zoom(0.75*2)
			:set_tween_uses_effect_delta(true)
			end;
	},
	
	LoadActor( file )..{
		RepeatCommand=function(self)
			self:zoom(0.75/2):diffusealpha(0)
			:xy(SCREEN_CENTER_X+(64),SCREEN_TOP+(64*2))
			:linear(1.4/2):zoom(0.75):diffusealpha(1):accelerate(0.015)
			:smooth(1)
			:addy(-64*4)
			:zoom(0.75*2)
			:set_tween_uses_effect_delta(true)
			end;
	},
	
	LoadActor( file )..{
		RepeatCommand=function(self)
			self:zoom(0.75/2):diffusealpha(0)
			:xy(SCREEN_CENTER_X-(64),SCREEN_TOP+(64*2))
			:linear(1.6/2):zoom(0.75):diffusealpha(1):accelerate(0.015)
			:smooth(1)
			:addx(-64*6):addy(-64*4)
			:set_tween_uses_effect_delta(true)
			:zoom(0.75*2)
			end;
	},
	
	LoadActor( file )..{
		RepeatCommand=function(self)
			self:zoom(0.75/2):diffusealpha(0)
			:xy(SCREEN_CENTER_X-(64*2),SCREEN_CENTER_Y)
			:linear(1.8/2):zoom(0.75):diffusealpha(1):accelerate(0.015)
			:set_tween_uses_effect_delta(true)
			:smooth(1)
			:addx(-64*6):addy(64*6)
			:zoom(0.75*2)
			end;
	},
	
	LoadActor( file )..{
		RepeatCommand=function(self)
			self:zoom(0.75/2):diffusealpha(0)
			:xy(SCREEN_CENTER_X-(64),SCREEN_BOTTOM-(64*2))
			:linear(2/2):zoom(0.75):diffusealpha(1):accelerate(0.015)
			:set_tween_uses_effect_delta(true)
			:smooth(1)
			:addy(64*4)
			:zoom(0.75*2)
			end;
	},
	
	LoadActor( file )..{
		RepeatCommand=function(self)
			self:zoom(0.75/2):diffusealpha(0)
			:xy(SCREEN_CENTER_X+(64),SCREEN_BOTTOM-(64*2))
			:linear(2.1/2):zoom(0.75):diffusealpha(1):accelerate(0.015)
			:set_tween_uses_effect_delta(true)
			:smooth(1):zoom(0.75*2)
			:addx(64*6):addy(64*4)
			end;
	},
}
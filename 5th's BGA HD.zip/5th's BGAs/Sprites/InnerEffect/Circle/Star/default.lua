-- create a variable to be loaded in each Actor
-- the ... syntax is an argument that has been passed
-- in from another file
-- if no argument is passed in, load "flower.png" as a fallback
local file = ...

-- These same things were happening again and again to EVERY actor
-- and the only thing different was the duration of the tween.
-- It makes sense to use a function here.  There is less code duplication
-- and less opportunity to make a typo somewhere, once.

return Def.ActorFrame{
	OnCommand=function(self) self:set_tween_uses_effect_delta(true) self:playcommand("Repeat") end,

		Def.Sprite{
		Texture = file, 
		Frames = {{Delay= 0.09, Frame= 0}, {Delay= 0.09, Frame= 1}, {Delay= 0.09, Frame= 2}, {Delay= 0.09, Frame= 3}, {Delay= 0.09, Frame= 4}, {Delay= 0.09, Frame= 5}, {Delay= 0.09, Frame= 6}, {Delay= 0.09, Frame= 7}, {Delay= 0.09, Frame= 8}, {Delay= 0.09, Frame= 9}, {Delay= 0.09, Frame= 10}, {Delay= 0.09, Frame= 11}},
		RepeatCommand=function(self)
			self:zoom(0.75*2):setstate(0)
			:xy(SCREEN_CENTER_X+(64*2),SCREEN_CENTER_Y):addx(64*8):addy(-64*8)
			:linear(2.1/2):zoom(0.75*4):diffusealpha(1):accelerate(0.015)
			:smooth(1)
			:xy(SCREEN_CENTER_X+(64*2),SCREEN_CENTER_Y)
			:zoom(0.75/2)
			:linear(1):diffusealpha(0):zoom(0)
			:effectclock('beat')
			end;
	},
	
		Def.Sprite{
		Texture = file, 
		Frames = {{Delay= 0.09, Frame= 0}, {Delay= 0.09, Frame= 1}, {Delay= 0.09, Frame= 2}, {Delay= 0.09, Frame= 3}, {Delay= 0.09, Frame= 4}, {Delay= 0.09, Frame= 5}, {Delay= 0.09, Frame= 6}, {Delay= 0.09, Frame= 7}, {Delay= 0.09, Frame= 8}, {Delay= 0.09, Frame= 9}, {Delay= 0.09, Frame= 10}, {Delay= 0.09, Frame= 11}},
		RepeatCommand=function(self)
			self:zoom(0.75*2):setstate(1)
			:xy(SCREEN_CENTER_X+(64),SCREEN_TOP+(64*2)):addy(-64*6)
			:linear(2/2):zoom(0.75*4):diffusealpha(1):accelerate(0.015)
			:smooth(1)
			:xy(SCREEN_CENTER_X+(64),SCREEN_TOP+(64*2))
			:zoom(0.75/2)
			:linear(1):diffusealpha(0):zoom(0)
			:effectclock('beat')
			end;
	},
	
		Def.Sprite{
		Texture = file, 
		Frames = {{Delay= 0.09, Frame= 0}, {Delay= 0.09, Frame= 1}, {Delay= 0.09, Frame= 2}, {Delay= 0.09, Frame= 3}, {Delay= 0.09, Frame= 4}, {Delay= 0.09, Frame= 5}, {Delay= 0.09, Frame= 6}, {Delay= 0.09, Frame= 7}, {Delay= 0.09, Frame= 8}, {Delay= 0.09, Frame= 9}, {Delay= 0.09, Frame= 10}, {Delay= 0.09, Frame= 11}},
		RepeatCommand=function(self)
			self:zoom(0.75*2):setstate(2)
			:xy(SCREEN_CENTER_X-(64),SCREEN_TOP+(64*2)):addx(-64*8):addy(-64*6)
			:linear(1.8/2):zoom(0.75*4):diffusealpha(1):accelerate(0.015)
			:smooth(1)
			:xy(SCREEN_CENTER_X-(64),SCREEN_TOP+(64*2))
			:effectclock('beat')
			:zoom(0.75/2)
			:linear(1):diffusealpha(0):zoom(0)
			end;
	},
	
		Def.Sprite{
		Texture = file, 
		Frames = {{Delay= 0.09, Frame= 0}, {Delay= 0.09, Frame= 1}, {Delay= 0.09, Frame= 2}, {Delay= 0.09, Frame= 3}, {Delay= 0.09, Frame= 4}, {Delay= 0.09, Frame= 5}, {Delay= 0.09, Frame= 6}, {Delay= 0.09, Frame= 7}, {Delay= 0.09, Frame= 8}, {Delay= 0.09, Frame= 9}, {Delay= 0.09, Frame= 10}, {Delay= 0.09, Frame= 11}},
		RepeatCommand=function(self)
			self:zoom(0.75*2):setstate(3)
			:xy(SCREEN_CENTER_X-(64*2),SCREEN_CENTER_Y):addx(-64*8):addy(64*8)
			:linear(1.6/2):zoom(0.75*4):diffusealpha(1):accelerate(0.015)
			:effectclock('beat')
			:smooth(1)
			:xy(SCREEN_CENTER_X-(64*2),SCREEN_CENTER_Y)
			:zoom(0.75/2)
			:linear(1):diffusealpha(0):zoom(0)
			end;
	},
	
		Def.Sprite{
		Texture = file, 
		Frames = {{Delay= 0.09, Frame= 0}, {Delay= 0.09, Frame= 1}, {Delay= 0.09, Frame= 2}, {Delay= 0.09, Frame= 3}, {Delay= 0.09, Frame= 4}, {Delay= 0.09, Frame= 5}, {Delay= 0.09, Frame= 6}, {Delay= 0.09, Frame= 7}, {Delay= 0.09, Frame= 8}, {Delay= 0.09, Frame= 9}, {Delay= 0.09, Frame= 10}, {Delay= 0.09, Frame= 11}},
		RepeatCommand=function(self)
			self:zoom(0.75*2):setstate(4)
			:xy(SCREEN_CENTER_X-(64),SCREEN_BOTTOM-(64*2)):addy(64*6)
			:linear(1.4/2):zoom(0.75*4):diffusealpha(1):accelerate(0.015)
			:effectclock('beat')
			:smooth(1)
			:xy(SCREEN_CENTER_X-(64),SCREEN_BOTTOM-(64*2))
			:zoom(0.75/2)
			:linear(1):diffusealpha(0):zoom(0)
			end;
	},
	
		Def.Sprite{
		Texture = file, 
		Frames = {{Delay= 0.09, Frame= 0}, {Delay= 0.09, Frame= 1}, {Delay= 0.09, Frame= 2}, {Delay= 0.09, Frame= 3}, {Delay= 0.09, Frame= 4}, {Delay= 0.09, Frame= 5}, {Delay= 0.09, Frame= 6}, {Delay= 0.09, Frame= 7}, {Delay= 0.09, Frame= 8}, {Delay= 0.09, Frame= 9}, {Delay= 0.09, Frame= 10}, {Delay= 0.09, Frame= 11}},
		RepeatCommand=function(self)
			self:zoom(0.75*2):setstate(5)
			:xy(SCREEN_CENTER_X+(64),SCREEN_BOTTOM-(64*2)):addx(64*8):addy(64*6)
			:linear(1.2/2):zoom(0.75*4):diffusealpha(1):accelerate(0.015)
			:effectclock('beat')
			:smooth(1):zoom(0.75/2)
			:xy(SCREEN_CENTER_X+(64),SCREEN_BOTTOM-(64*2))
			:zoom(0.75/2)
			:linear(1):diffusealpha(0):zoom(0)
			end;
	},
}
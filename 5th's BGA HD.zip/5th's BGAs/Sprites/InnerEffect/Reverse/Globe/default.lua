-- create a variable to be loaded in each Actor
-- the ... syntax is an argument that has been passed
-- in from another file
-- if no argument is passed in, load "flower.png" as a fallback

local SongBeat = math.random(2,4)
local file = ... or "flower.png"


-- These same things were happening again and again to EVERY actor
-- and the only thing different was the duration of the tween.
-- It makes sense to use a function here.  There is less code duplication
-- and less opportunity to make a typo somewhere, once.
local AnimateThisActor = function( self, start_x, start_y, tween_duration )
	self:xy( _screen.cx, _screen.cy )
		:zoom(0)
		:setstate(math.random(0,11))
		:linear( tween_duration+math.random(0.3500,0.7500) ):zoom(1):xy( start_x, start_y )
		:set_tween_uses_effect_delta(true):effectclock("beat")
		:queuecommand("Repeat")
end




return Def.ActorFrame{
	LoseFocusCommand=function(self)
		self:RunCommandsOnChildren( function(child) child:visible(false):finishtweening() end, {} )
	end,
	
	-- When the ActorFrame's OnCommand is called
	-- have it play "RepeatCommand" on all children.	
	OnCommand=function(self)
		self:playcommand("Repeat")
	end,
	
		Def.Sprite{
		Texture = file, 
				Frames = {{Delay= 0.25/2, Frame= 0}, {Delay= 0.25/2, Frame= 1}, {Delay= 0.25/2, Frame= 2}, {Delay= 0.25/2, Frame= 3}, {Delay= 0.25/2, Frame= 4}, {Delay= 0.25/2, Frame= 5}},
		RepeatCommand=function(self)
			AnimateThisActor(self:effectclock("beat"), _screen.w+70, -70,  SongBeat+math.random(0.2500,0.7500))
		end
	},
			Def.Sprite{
		Texture = file, 
				Frames = {{Delay= 0.25/2, Frame= 0}, {Delay= 0.25/2, Frame= 1}, {Delay= 0.25/2, Frame= 2}, {Delay= 0.25/2, Frame= 3}, {Delay= 0.25/2, Frame= 4}, {Delay= 0.25/2, Frame= 5}},
		RepeatCommand=function(self)
			AnimateThisActor(self:effectclock("beat"), _screen.cx, -70, SongBeat+math.random(0.2500,0.7500))
		end
	},
			Def.Sprite{
		Texture = file, 
				Frames = {{Delay= 0.25/2, Frame= 0}, {Delay= 0.25/2, Frame= 1}, {Delay= 0.25/2, Frame= 2}, {Delay= 0.25/2, Frame= 3}, {Delay= 0.25/2, Frame= 4}, {Delay= 0.25/2, Frame= 5}},
		RepeatCommand=function(self)
			AnimateThisActor(self:effectclock("beat"), -70, -70, SongBeat+math.random(0.2500,0.7500))
		end
	},
			Def.Sprite{
		Texture = file, 
				Frames = {{Delay= 0.25/2, Frame= 0}, {Delay= 0.25/2, Frame= 1}, {Delay= 0.25/2, Frame= 2}, {Delay= 0.25/2, Frame= 3}, {Delay= 0.25/2, Frame= 4}, {Delay= 0.25/2, Frame= 5}},
		RepeatCommand=function(self)
			AnimateThisActor(self:effectclock("beat"), -70, _screen.cy,  SongBeat+math.random(0.2500,0.7500))
		end
	},
			Def.Sprite{
		Texture = file, 
				Frames = {{Delay= 0.25/2, Frame= 0}, {Delay= 0.25/2, Frame= 1}, {Delay= 0.25/2, Frame= 2}, {Delay= 0.25/2, Frame= 3}, {Delay= 0.25/2, Frame= 4}, {Delay= 0.25/2, Frame= 5}},
		RepeatCommand=function(self)
			AnimateThisActor(self:effectclock("beat"), -70, _screen.h+70,  SongBeat+math.random(0.2500,0.7500))
		end
	},
			Def.Sprite{
		Texture = file, 
				Frames = {{Delay= 0.25/2, Frame= 0}, {Delay= 0.25/2, Frame= 1}, {Delay= 0.25/2, Frame= 2}, {Delay= 0.25/2, Frame= 3}, {Delay= 0.25/2, Frame= 4}, {Delay= 0.25/2, Frame= 5}},
		RepeatCommand=function(self)
			AnimateThisActor(self:effectclock("beat"), _screen.cx, _screen.h+70, SongBeat+math.random(0.2500,0.7500))
		end
	},
			Def.Sprite{
		Texture = file, 
				Frames = {{Delay= 0.25/2, Frame= 0}, {Delay= 0.25/2, Frame= 1}, {Delay= 0.25/2, Frame= 2}, {Delay= 0.25/2, Frame= 3}, {Delay= 0.25/2, Frame= 4}, {Delay= 0.25/2, Frame= 5}},
		RepeatCommand=function(self)
			AnimateThisActor(self:effectclock("beat"), _screen.w+70, _screen.h+70, SongBeat+math.random(0.2500,0.7500))
		end
	},
			Def.Sprite{
		Texture = file, 
				Frames = {{Delay= 0.25/2, Frame= 0}, {Delay= 0.25/2, Frame= 1}, {Delay= 0.25/2, Frame= 2}, {Delay= 0.25/2, Frame= 3}, {Delay= 0.25/2, Frame= 4}, {Delay= 0.25/2, Frame= 5}},
		RepeatCommand=function(self) 
			AnimateThisActor(self:effectclock("beat"), _screen.w+70, _screen.cy, SongBeat+math.random(0.2500,0.7500))
		end
	}
}
return Def.ActorFrame{
	LoseFocusCommand=function(self)
		self:RunCommandsOnChildren(function(child) child:visible(false):finishtweening() end, {})
	end,
	
		Def.Sprite{
		Texture = "1 5x1.png", 
		Frames = {{Delay= 0.25, Frame= 0}, {Delay= 0.25, Frame= 1}, {Delay= 0.25, Frame= 2}, {Delay= 0.25, Frame= 3}, {Delay= 0.25, Frame= 4}},
		OnCommand=cmd(x,64;y,60;effectclock,"beat")
	};
		Def.Sprite{
		Texture = "1 5x1.png", 
		Frames = {{Delay= 0.25, Frame= 0}, {Delay= 0.25, Frame= 1}, {Delay= 0.25, Frame= 2}, {Delay= 0.25, Frame= 3}, {Delay= 0.25, Frame= 4}},
		OnCommand=cmd(x,192;y,60;effectclock,"beat")
	};
		Def.Sprite{
		Texture = "1 5x1.png", 
		Frames = {{Delay= 0.25, Frame= 0}, {Delay= 0.25, Frame= 1}, {Delay= 0.25, Frame= 2}, {Delay= 0.25, Frame= 3}, {Delay= 0.25, Frame= 4}},
		OnCommand=cmd(x,320;y,60;effectclock,"beat")
	};
		Def.Sprite{
		Texture = "1 5x1.png", 
		Frames = {{Delay= 0.25, Frame= 0}, {Delay= 0.25, Frame= 1}, {Delay= 0.25, Frame= 2}, {Delay= 0.25, Frame= 3}, {Delay= 0.25, Frame= 4}},
		OnCommand=cmd(x,448;y,60;effectclock,"beat")
	};
		Def.Sprite{
		Texture = "1 5x1.png", 
		Frames = {{Delay= 0.25, Frame= 0}, {Delay= 0.25, Frame= 1}, {Delay= 0.25, Frame= 2}, {Delay= 0.25, Frame= 3}, {Delay= 0.25, Frame= 4}},
		OnCommand=cmd(x,576;y,60;effectclock,"beat")
	};
		Def.Sprite{
		Texture = "1 5x1.png", 
		Frames = {{Delay= 0.25, Frame= 0}, {Delay= 0.25, Frame= 1}, {Delay= 0.25, Frame= 2}, {Delay= 0.25, Frame= 3}, {Delay= 0.25, Frame= 4}},
		OnCommand=cmd(x,704;y,60;effectclock,"beat")
	};
		Def.Sprite{
		Texture = "1 5x1.png", 
		Frames = {{Delay= 0.25, Frame= 0}, {Delay= 0.25, Frame= 1}, {Delay= 0.25, Frame= 2}, {Delay= 0.25, Frame= 3}, {Delay= 0.25, Frame= 4}},
		OnCommand=cmd(x,832;y,60;effectclock,"beat")
	};
		Def.Sprite{
		Texture = "1 5x1.png", 
		Frames = {{Delay= 0.25, Frame= 0}, {Delay= 0.25, Frame= 1}, {Delay= 0.25, Frame= 2}, {Delay= 0.25, Frame= 3}, {Delay= 0.25, Frame= 4}},
		OnCommand=cmd(x,64;y,180;effectclock,"beat")
	};
		Def.Sprite{
		Texture = "1 5x1.png", 
		Frames = {{Delay= 0.25, Frame= 0}, {Delay= 0.25, Frame= 1}, {Delay= 0.25, Frame= 2}, {Delay= 0.25, Frame= 3}, {Delay= 0.25, Frame= 4}},
		OnCommand=cmd(x,192;y,180;effectclock,"beat")
	};
		Def.Sprite{
		Texture = "1 5x1.png", 
		Frames = {{Delay= 0.25, Frame= 0}, {Delay= 0.25, Frame= 1}, {Delay= 0.25, Frame= 2}, {Delay= 0.25, Frame= 3}, {Delay= 0.25, Frame= 4}},
		OnCommand=cmd(x,320;y,180;effectclock,"beat")
	};
		Def.Sprite{
		Texture = "1 5x1.png", 
		Frames = {{Delay= 0.25, Frame= 0}, {Delay= 0.25, Frame= 1}, {Delay= 0.25, Frame= 2}, {Delay= 0.25, Frame= 3}, {Delay= 0.25, Frame= 4}},
		OnCommand=cmd(x,448;y,180;effectclock,"beat")
	};
		Def.Sprite{
		Texture = "1 5x1.png", 
		Frames = {{Delay= 0.25, Frame= 0}, {Delay= 0.25, Frame= 1}, {Delay= 0.25, Frame= 2}, {Delay= 0.25, Frame= 3}, {Delay= 0.25, Frame= 4}},
		OnCommand=cmd(x,576;y,180;effectclock,"beat")
	};
		Def.Sprite{
		Texture = "1 5x1.png", 
		Frames = {{Delay= 0.25, Frame= 0}, {Delay= 0.25, Frame= 1}, {Delay= 0.25, Frame= 2}, {Delay= 0.25, Frame= 3}, {Delay= 0.25, Frame= 4}},
		OnCommand=cmd(x,704;y,180;effectclock,"beat")
	};
		Def.Sprite{
		Texture = "1 5x1.png", 
		Frames = {{Delay= 0.25, Frame= 0}, {Delay= 0.25, Frame= 1}, {Delay= 0.25, Frame= 2}, {Delay= 0.25, Frame= 3}, {Delay= 0.25, Frame= 4}},
		OnCommand=cmd(x,832;y,180;effectclock,"beat")
	};
		Def.Sprite{
		Texture = "1 5x1.png", 
		Frames = {{Delay= 0.25, Frame= 0}, {Delay= 0.25, Frame= 1}, {Delay= 0.25, Frame= 2}, {Delay= 0.25, Frame= 3}, {Delay= 0.25, Frame= 4}},
		OnCommand=cmd(x,64;y,300;effectclock,"beat")
	};
		Def.Sprite{
		Texture = "1 5x1.png", 
		Frames = {{Delay= 0.25, Frame= 0}, {Delay= 0.25, Frame= 1}, {Delay= 0.25, Frame= 2}, {Delay= 0.25, Frame= 3}, {Delay= 0.25, Frame= 4}},
		OnCommand=cmd(x,192;y,300;effectclock,"beat")
	};
		Def.Sprite{
		Texture = "1 5x1.png", 
		Frames = {{Delay= 0.25, Frame= 0}, {Delay= 0.25, Frame= 1}, {Delay= 0.25, Frame= 2}, {Delay= 0.25, Frame= 3}, {Delay= 0.25, Frame= 4}},
		OnCommand=cmd(x,320;y,300;effectclock,"beat")
	};
		Def.Sprite{
		Texture = "1 5x1.png", 
		Frames = {{Delay= 0.25, Frame= 0}, {Delay= 0.25, Frame= 1}, {Delay= 0.25, Frame= 2}, {Delay= 0.25, Frame= 3}, {Delay= 0.25, Frame= 4}},
		OnCommand=cmd(x,448;y,300;effectclock,"beat")
	};
		Def.Sprite{
		Texture = "1 5x1.png", 
		Frames = {{Delay= 0.25, Frame= 0}, {Delay= 0.25, Frame= 1}, {Delay= 0.25, Frame= 2}, {Delay= 0.25, Frame= 3}, {Delay= 0.25, Frame= 4}},
		OnCommand=cmd(x,576;y,300;effectclock,"beat")
	};
		Def.Sprite{
		Texture = "1 5x1.png", 
		Frames = {{Delay= 0.25, Frame= 0}, {Delay= 0.25, Frame= 1}, {Delay= 0.25, Frame= 2}, {Delay= 0.25, Frame= 3}, {Delay= 0.25, Frame= 4}},
		OnCommand=cmd(x,704;y,300;effectclock,"beat")
	};
		Def.Sprite{
		Texture = "1 5x1.png", 
		Frames = {{Delay= 0.25, Frame= 0}, {Delay= 0.25, Frame= 1}, {Delay= 0.25, Frame= 2}, {Delay= 0.25, Frame= 3}, {Delay= 0.25, Frame= 4}},
		OnCommand=cmd(x,832;y,300;effectclock,"beat")
	};
		Def.Sprite{
		Texture = "1 5x1.png", 
		Frames = {{Delay= 0.25, Frame= 0}, {Delay= 0.25, Frame= 1}, {Delay= 0.25, Frame= 2}, {Delay= 0.25, Frame= 3}, {Delay= 0.25, Frame= 4}},
		OnCommand=cmd(x,64;y,420;effectclock,"beat")
	};
		Def.Sprite{
		Texture = "1 5x1.png", 
		Frames = {{Delay= 0.25, Frame= 0}, {Delay= 0.25, Frame= 1}, {Delay= 0.25, Frame= 2}, {Delay= 0.25, Frame= 3}, {Delay= 0.25, Frame= 4}},
		OnCommand=cmd(x,192;y,420;effectclock,"beat")
	};
		Def.Sprite{
		Texture = "1 5x1.png", 
		Frames = {{Delay= 0.25, Frame= 0}, {Delay= 0.25, Frame= 1}, {Delay= 0.25, Frame= 2}, {Delay= 0.25, Frame= 3}, {Delay= 0.25, Frame= 4}},
		OnCommand=cmd(x,320;y,420;effectclock,"beat")
	};
		Def.Sprite{
		Texture = "1 5x1.png", 
		Frames = {{Delay= 0.25, Frame= 0}, {Delay= 0.25, Frame= 1}, {Delay= 0.25, Frame= 2}, {Delay= 0.25, Frame= 3}, {Delay= 0.25, Frame= 4}},
		OnCommand=cmd(x,448;y,420;effectclock,"beat")
	};
		Def.Sprite{
		Texture = "1 5x1.png", 
		Frames = {{Delay= 0.25, Frame= 0}, {Delay= 0.25, Frame= 1}, {Delay= 0.25, Frame= 2}, {Delay= 0.25, Frame= 3}, {Delay= 0.25, Frame= 4}},
		OnCommand=cmd(x,576;y,420;effectclock,"beat")
	};
		Def.Sprite{
		Texture = "1 5x1.png", 
		Frames = {{Delay= 0.25, Frame= 0}, {Delay= 0.25, Frame= 1}, {Delay= 0.25, Frame= 2}, {Delay= 0.25, Frame= 3}, {Delay= 0.25, Frame= 4}},
		OnCommand=cmd(x,704;y,420;effectclock,"beat")
	};
		Def.Sprite{
		Texture = "1 5x1.png", 
		Frames = {{Delay= 0.25, Frame= 0}, {Delay= 0.25, Frame= 1}, {Delay= 0.25, Frame= 2}, {Delay= 0.25, Frame= 3}, {Delay= 0.25, Frame= 4}},
		OnCommand=cmd(x,832;y,420;effectclock,"beat")
	};
}
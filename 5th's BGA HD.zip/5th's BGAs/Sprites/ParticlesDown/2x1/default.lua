-- create a variable to be loaded in each Actor
-- the ... syntax is an argument that has been passed
-- in from another file
-- if no argument is passed in, load "(Something).png" as a fallback

local v = {1,3}
local n = math.random(#v)

local dt = math.random(2.5,3)
local dt2 = math.random(1,6)

local dx = n*math.random(10,15*1.25)
local dx2 = n*math.random(0.3000,1.000)

local file = 

...

return Def.ActorFrame{
	OnCommand=function(self) self:playcommand("Repeat") end,

		Def.Sprite{
		Texture = file, 
		Frames = {{Delay= 0.5, Frame= 0}, {Delay= 0.5, Frame= 1}},
		RepeatCommand=function(self)
		if n == 1 then 
			self:zoom(0.8) local dx = n*math.random(16,19*1.5) 
			self:x(-_screen.w+math.random(_screen.w,(_screen.w*2)))
			:setstate(math.random(0,1))
			:y(-_screen.h-64*dt2*n)
			:linear(dx/5+dx2/5)
			:set_tween_uses_effect_delta(true):effectclock("beat")
			:y(_screen.h+64*dt2/1.5)
		else self:zoom(1) 
			self:x(-_screen.w+math.random(_screen.w,(_screen.w*2)))
			:setstate(math.random(0,1))
			:y(-_screen.h-64*dt2*n)
			:linear(dx/5+dx2/5)
			:set_tween_uses_effect_delta(true):effectclock("beat")
			:y(_screen.h+64*dt2/1.5)
			end;
			self:queuecommand("Repeat")
			end;
	},

}
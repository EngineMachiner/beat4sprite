-- create a variable to be loaded in each Actor
-- the ... syntax is an argument that has been passed
-- in from another file
-- if no argument is passed in, load "(Something).png" as a fallback

local d = math.random(SCREEN_LEFT+64,SCREEN_RIGHT-64)
local file = 

...


return Def.ActorFrame{
	OnCommand=function(self) self:playcommand("Repeat") end,

	LoadActor( file )..{
		RepeatCommand=function(self)
			self:zoom(0)
			:diffusealpha(1)
			:x(d)
			:y(_screen.h-64)
			:bounce():effectmagnitude(0,math.random(-240,-80),0):effectoffset(0.1000,1.000)
			:linear(math.random(0.7000,3.000)*2)
			:addx(math.random(-150,150))
			:y(_screen.h-(64/2))
			:zoom(0.8)
			:sleep(math.random(0.3000,1.000)*2)
			:linear(math.random(0.7000,3.000)*2)
			:y(_screen.h+(64*2))
			:diffusealpha(0)
			:queuecommand("Repeat"):effectclock("beat")
			end;
	},

}
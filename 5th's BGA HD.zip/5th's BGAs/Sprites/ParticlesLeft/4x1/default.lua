-- create a variable to be loaded in each Actor
-- the ... syntax is an argument that has been passed
-- in from another file
-- if no argument is passed in, load "(Something).png" as a fallback

local v = {1,3}
local n = math.random(#v)

local dt = math.random(2.5,3)
local dt2 = math.random(1,6)

local dx = n*math.random(10,15*1.25)
local dx2 = n*math.random(0.3000,1.000)

local file = 

... or 
"2 4x1 Engine.png" or
"2 4x2 Mines.png" or
"2 4x1 SquareLights.png" or
"2 16x1 Pig.png" or
"2 2x1 Piranha.png"


return Def.ActorFrame{
	OnCommand=function(self) self:playcommand("Repeat") end,

		Def.Sprite{
		Texture = file, 
		Frames = {{Delay= 0.25/2, Frame= 0}, {Delay= 0.25/2, Frame= 1}, {Delay= 0.25/2, Frame= 2}, {Delay= 0.25/2, Frame= 3}},
		RepeatCommand=function(self)
		if n == 1 then 
			self:zoom(0.8) local dx = n*math.random(16,19*1.5) 
			self:x(_screen.w+64*dt2/1.5)
			:setstate(math.random(0,5))
			:y(-_screen.h+math.random(_screen.h,(_screen.h*2)))
			:linear(dx/4+dx2/4)
			:effectclock('beat')
			:set_tween_uses_effect_delta(true)
			:x(-_screen.w-64*dt2*n)
		else self:zoom(1) 
			self:x(_screen.w+64*dt2/1.5)
			:setstate(math.random(0,5))
			:y(-_screen.h+math.random(_screen.h,(_screen.h*2)))
			:linear(dx/4+dx2/4)
			:set_tween_uses_effect_delta(true)
			:effectclock('beat')
			:x(-_screen.w-64*dt2*n)
			end;
			self:queuecommand("Repeat")
			end;
	},

}
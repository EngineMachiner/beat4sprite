-- create a variable to be loaded in each Actor
-- the ... syntax is an argument that has been passed
-- in from another file
-- if no argument is passed in, load "(Something).png" as a fallback
local v = {1,3}
local n = math.random(#v)

local dt = math.random(2.5,3)
local dt2 = math.random(1,6)

local dx = n*math.random(10,15*1.25)
local dx2 = n*math.random(0.3000,1.000)

local file = 

...


return Def.ActorFrame{
	OnCommand=function(self) self:playcommand("Repeat") end,

	LoadActor( file )..{
		RepeatCommand=function(self)
		if n == 1 then 
			self:zoom(0.8) local dx = n*math.random(16,19*1.5) 
			self:x(_screen.w+64*dt2/1.5)
			:blend('BlendMode_Add')
			:y(-_screen.h+math.random(_screen.h,(_screen.h*2)))
			:linear(dx/4+dx2/4)
			:effectclock('beat'):set_tween_uses_effect_delta(true)
			:x(-_screen.w-64*dt2*n)
			:diffuse(color("#5a5a5a"))
		else self:zoom(1) 
			self:x(_screen.w+64*dt2/1.5)
			:blend('BlendMode_Add')
			:y(-_screen.h+math.random(_screen.h,(_screen.h*2)))
			:linear(dx/4+dx2/4)
			:effectclock('beat'):set_tween_uses_effect_delta(true)
			:x(-_screen.w-64*dt2*n)
			end;
			self:queuecommand("Repeat")
			end;
	},

}
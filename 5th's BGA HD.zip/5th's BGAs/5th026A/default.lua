return Def.ActorFrame{

	LoseFocusCommand=function(self)
		self:RunCommandsOnChildren(function(child) child:visible(false):finishtweening() end, {})
	end,
	LoadActor("sprite1.lua")..{
		OnCommand=cmd(y,-320;linear,1.5;y,0;queuecommand,"On";set_tween_uses_effect_delta,true)
	};
	LoadActor("sprite1.lua")..{
		OnCommand=cmd(y,0;linear,1.5;y,320;queuecommand,"On";set_tween_uses_effect_delta,true)
	};
	LoadActor("A.lua")..{
		OnCommand=cmd()
	};
}
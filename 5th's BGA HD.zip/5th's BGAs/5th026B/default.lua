return Def.ActorFrame{

	LoseFocusCommand=function(self)
		self:RunCommandsOnChildren(function(child) child:visible(false):finishtweening() end, {})
	end,
	LoadActor("sprite1.lua")..{
		OnCommand=cmd(y,-320;linear,1.5;y,0;queuecommand,"On";set_tween_uses_effect_delta,true)
	};
	LoadActor("sprite1.lua")..{
		OnCommand=cmd(y,0;linear,1.5;y,320;queuecommand,"On";set_tween_uses_effect_delta,true)
	};
	LoadActor("_particleLoader1.lua")..{
		OnCommand=cmd()
	};
	LoadActor("_particleLoader1 - copia.lua")..{
		OnCommand=cmd(rotationy,180;x,640;y,0)
	};
	LoadActor("_particleLoader2.lua")..{
		OnCommand=cmd(rotationx,180;x,0;y,480)
	};
	LoadActor("_particleLoader2 - copia.lua")..{
		OnCommand=cmd(rotationy,-180;rotationx,180;x,640;y,480)
	};
	
	LoadActor("_particleLoader1 - copia (2).lua")..{
		OnCommand=cmd()
	};
	LoadActor("_particleLoader1 - copia - copia.lua")..{
		OnCommand=cmd(rotationy,180;x,640;y,0)
	};
	LoadActor("_particleLoader2 - copia (2).lua")..{
		OnCommand=cmd(rotationx,180;x,0;y,480)
	};
	LoadActor("_particleLoader2 - copia - copia.lua")..{
		OnCommand=cmd(rotationy,-180;rotationx,180;x,640;y,480)
	};
}
local t = Def.ActorFrame{
	LoadActor(GAMESTATE:GetCurrentSong():GetBackgroundPath())..{
		OnCommand=function(self)
		self:Center()
			:addx(640)
			:zoomx(-1)
			:SetSize(640,480)
			:faderight(0.025)
		end
	};
	
	LoadActor(GAMESTATE:GetCurrentSong():GetBackgroundPath())..{
		OnCommand=function(self)
		self:Center()
			:addx(-640)
			:zoomx(-1)
			:SetSize(640,480)
			:fadeleft(0.025)
		end
	};

	LoadActor("B.lua")..{
		OnCommand=function(self)
		self:diffusealpha(1/(19/(19/2.5)))
		end
	};
	
};

return t;
return Def.ActorFrame{

	LoseFocusCommand=function(self)
		self:RunCommandsOnChildren(function(child) child:visible(false):finishtweening() end, {})
	end,
	LoadActor("1 (stretch)")..{
		OnCommand=cmd(Center;zoom,2;texcoordvelocity,0,0.45/2;customtexturerect,0,0,2,2;rainbow;effectperiod,8;set_use_effect_clock_for_texcoords,true;effectclock,'beat')
	};
	LoadActor("Particle2x1")..{
		OnCommand=cmd()
	};
	LoadActor("Particle2x1")..{
		OnCommand=cmd(hibernate,5)
	};
	LoadActor("Particle2x1")..{
		OnCommand=cmd(hibernate,10)
	};
	LoadActor("Particle2x1")..{
		OnCommand=cmd(hibernate,15)
	};
}
local WDX2 if SCREEN_WIDTH > 640 then WDX2 = -80/1.5 else WDX2 = 0 end;
local t = Def.ActorFrame{
	LoadActor("1.png")..{
		OnCommand=cmd(x,80;y,60;addx,WDX2)
	};
	LoadActor("1.png")..{
		OnCommand=cmd(x,240;y,60;addx,WDX2)
	};
	LoadActor("1.png")..{
		OnCommand=cmd(x,400;y,60;addx,WDX2)
	};
	LoadActor("1.png")..{
		OnCommand=cmd(x,560;y,60;addx,WDX2)
	};
	LoadActor("1.png")..{
		OnCommand=cmd(x,720;y,60;addx,WDX2)
	};
	LoadActor("1.png")..{
		OnCommand=cmd(x,880;y,60;addx,WDX2)
	};
	LoadActor("1.png")..{
		OnCommand=cmd(x,80;y,180;addx,WDX2)
	};
	LoadActor("1.png")..{
		OnCommand=cmd(x,240;y,180;addx,WDX2)
	};
	LoadActor("1.png")..{
		OnCommand=cmd(x,400;y,180;addx,WDX2)
	};
	LoadActor("1.png")..{
		OnCommand=cmd(x,560;y,180;addx,WDX2)
	};
	LoadActor("1.png")..{
		OnCommand=cmd(x,720;y,180;addx,WDX2)
	};
	LoadActor("1.png")..{
		OnCommand=cmd(x,880;y,180;addx,WDX2)
	};
	LoadActor("1.png")..{
		OnCommand=cmd(x,80;y,300;addx,WDX2)
	};
	LoadActor("1.png")..{
		OnCommand=cmd(x,240;y,300;addx,WDX2)
	};
	LoadActor("1.png")..{
		OnCommand=cmd(x,400;y,300;addx,WDX2)
	};
	LoadActor("1.png")..{
		OnCommand=cmd(x,560;y,300;addx,WDX2)
	};
	LoadActor("1.png")..{
		OnCommand=cmd(x,720;y,300;addx,WDX2)
	};
	LoadActor("1.png")..{
		OnCommand=cmd(x,880;y,300;addx,WDX2)
	};
	LoadActor("1.png")..{
		OnCommand=cmd(x,80;y,420;addx,WDX2)
	};
	LoadActor("1.png")..{
		OnCommand=cmd(x,240;y,420;addx,WDX2)
	};
	LoadActor("1.png")..{
		OnCommand=cmd(x,400;y,420;addx,WDX2)
	};
	LoadActor("1.png")..{
		OnCommand=cmd(x,560;y,420;addx,WDX2)
	};
	LoadActor("1.png")..{
		OnCommand=cmd(x,720;y,420;addx,WDX2)
	};
	LoadActor("1.png")..{
		OnCommand=cmd(x,880;y,420;addx,WDX2)
	};
		Def.Sprite{
		Texture = "2 4x1.png", 
		Frames = {{Delay= 0.5/math.random(2,3), Frame= 3}, {Delay= 0.5/math.random(2,3), Frame= 2}, {Delay= 0.5/math.random(2,3), Frame= 1}, {Delay= 0.5/math.random(2,3), Frame= 0}},
		OnCommand=cmd(x,80;y,60;addx,WDX2;setstate,0;effectclock,'beat')
	};
		Def.Sprite{
		Texture = "2 4x1.png", 
		Frames = {{Delay= 0.5/math.random(2,3), Frame= 0}, {Delay= 0.5/math.random(2,3), Frame= 1}, {Delay= 0.5/math.random(2,3), Frame= 2}, {Delay= 0.5/math.random(2,3), Frame= 3}},
		OnCommand=cmd(x,240;y,60;addx,WDX2;setstate,1;effectclock,'beat')
	};
		Def.Sprite{
		Texture = "2 4x1.png", 
		Frames = {{Delay= 0.5/math.random(2,3), Frame= 3}, {Delay= 0.5/math.random(2,3), Frame= 2}, {Delay= 0.5/math.random(2,3), Frame= 1}, {Delay= 0.5/math.random(2,3), Frame= 0}},
		OnCommand=cmd(x,400;y,60;addx,WDX2;setstate,2;effectclock,'beat')
	};
		Def.Sprite{
		Texture = "2 4x1.png", 
		Frames = {{Delay= 0.5/math.random(2,3), Frame= 0}, {Delay= 0.5/math.random(2,3), Frame= 1}, {Delay= 0.5/math.random(2,3), Frame= 2}, {Delay= 0.5/math.random(2,3), Frame= 3}},
		OnCommand=cmd(x,560;y,60;addx,WDX2;setstate,3;effectclock,'beat')
	};
		Def.Sprite{
		Texture = "2 4x1.png", 
		Frames = {{Delay= 0.5/math.random(2,3), Frame= 3}, {Delay= 0.5/math.random(2,3), Frame= 2}, {Delay= 0.5/math.random(2,3), Frame= 1}, {Delay= 0.5/math.random(2,3), Frame= 0}},
		OnCommand=cmd(x,720;y,60;addx,WDX2;setstate,0;effectclock,'beat')
	};
		Def.Sprite{
		Texture = "2 4x1.png", 
		Frames = {{Delay= 0.5/math.random(2,3), Frame= 0}, {Delay= 0.5/math.random(2,3), Frame= 1}, {Delay= 0.5/math.random(2,3), Frame= 2}, {Delay= 0.5/math.random(2,3), Frame= 3}},
		OnCommand=cmd(x,880;y,60;addx,WDX2;setstate,1;effectclock,'beat')
	};
		Def.Sprite{
		Texture = "2 4x1.png", 
		Frames = {{Delay= 0.5/math.random(2,3), Frame= 3}, {Delay= 0.5/math.random(2,3), Frame= 2}, {Delay= 0.5/math.random(2,3), Frame= 1}, {Delay= 0.5/math.random(2,3), Frame= 0}},
		OnCommand=cmd(x,80;y,180;addx,WDX2;setstate,1;effectclock,'beat')
	};
		Def.Sprite{
		Texture = "2 4x1.png", 
		Frames = {{Delay= 0.5/math.random(2,3), Frame= 0}, {Delay= 0.5/math.random(2,3), Frame= 1}, {Delay= 0.5/math.random(2,3), Frame= 2}, {Delay= 0.5/math.random(2,3), Frame= 3}},
		OnCommand=cmd(x,240;y,180;addx,WDX2;setstate,1;effectclock,'beat')
	};
		Def.Sprite{
		Texture = "2 4x1.png", 
		Frames = {{Delay= 0.5/math.random(2,3), Frame= 3}, {Delay= 0.5/math.random(2,3), Frame= 2}, {Delay= 0.5/math.random(2,3), Frame= 1}, {Delay= 0.5/math.random(2,3), Frame= 0}},
		OnCommand=cmd(x,400;y,180;addx,WDX2;setstate,2;effectclock,'beat')
	};
		Def.Sprite{
		Texture = "2 4x1.png", 
		Frames = {{Delay= 0.5/math.random(2,3), Frame= 0}, {Delay= 0.5/math.random(2,3), Frame= 1}, {Delay= 0.5/math.random(2,3), Frame= 2}, {Delay= 0.5/math.random(2,3), Frame= 3}},
		OnCommand=cmd(x,560;y,180;addx,WDX2;setstate,3;effectclock,'beat')
	};
		Def.Sprite{
		Texture = "2 4x1.png", 
		Frames = {{Delay= 0.5/math.random(2,3), Frame= 3}, {Delay= 0.5/math.random(2,3), Frame= 2}, {Delay= 0.5/math.random(2,3), Frame= 1}, {Delay= 0.5/math.random(2,3), Frame= 0}},
		OnCommand=cmd(x,720;y,180;addx,WDX2;setstate,0;effectclock,'beat')
	};
		Def.Sprite{
		Texture = "2 4x1.png", 
		Frames = {{Delay= 0.5/math.random(2,3), Frame= 0}, {Delay= 0.5/math.random(2,3), Frame= 1}, {Delay= 0.5/math.random(2,3), Frame= 2}, {Delay= 0.5/math.random(2,3), Frame= 3}},
		OnCommand=cmd(x,880;y,180;addx,WDX2;setstate,1;effectclock,'beat')
	};
		Def.Sprite{
		Texture = "2 4x1.png", 
		Frames = {{Delay= 0.5/math.random(2,3), Frame= 3}, {Delay= 0.5/math.random(2,3), Frame= 2}, {Delay= 0.5/math.random(2,3), Frame= 1}, {Delay= 0.5/math.random(2,3), Frame= 0}},
		OnCommand=cmd(x,80;y,300;addx,WDX2;setstate,2;effectclock,'beat')
	};
		Def.Sprite{
		Texture = "2 4x1.png", 
		Frames = {{Delay= 0.5/math.random(2,3), Frame= 0}, {Delay= 0.5/math.random(2,3), Frame= 1}, {Delay= 0.5/math.random(2,3), Frame= 2}, {Delay= 0.5/math.random(2,3), Frame= 3}},
		OnCommand=cmd(x,240;y,300;setstate,3;addx,WDX2;effectclock,'beat')
	};
		Def.Sprite{
		Texture = "2 4x1.png", 
		Frames = {{Delay= 0.5/math.random(2,3), Frame= 3}, {Delay= 0.5/math.random(2,3), Frame= 2}, {Delay= 0.5/math.random(2,3), Frame= 1}, {Delay= 0.5/math.random(2,3), Frame= 0}},
		OnCommand=cmd(x,400;y,300;setstate,0;addx,WDX2;effectclock,'beat')
	};
		Def.Sprite{
		Texture = "2 4x1.png", 
		Frames = {{Delay= 0.5/math.random(2,3), Frame= 0}, {Delay= 0.5/math.random(2,3), Frame= 1}, {Delay= 0.5/math.random(2,3), Frame= 2}, {Delay= 0.5/math.random(2,3), Frame= 3}},
		OnCommand=cmd(x,560;y,300;setstate,1;addx,WDX2;effectclock,'beat')
	};
		Def.Sprite{
		Texture = "2 4x1.png", 
		Frames = {{Delay= 0.5/math.random(2,3), Frame= 3}, {Delay= 0.5/math.random(2,3), Frame= 2}, {Delay= 0.5/math.random(2,3), Frame= 1}, {Delay= 0.5/math.random(2,3), Frame= 0}},
		OnCommand=cmd(x,720;y,300;setstate,2;addx,WDX2;effectclock,'beat')
	};
		Def.Sprite{
		Texture = "2 4x1.png", 
		Frames = {{Delay= 0.5/math.random(2,3), Frame= 0}, {Delay= 0.5/math.random(2,3), Frame= 1}, {Delay= 0.5/math.random(2,3), Frame= 2}, {Delay= 0.5/math.random(2,3), Frame= 3}},
		OnCommand=cmd(x,880;y,300;setstate,3;addx,WDX2;effectclock,'beat')
	};
		Def.Sprite{
		Texture = "2 4x1.png", 
		Frames = {{Delay= 0.5/math.random(2,3), Frame= 3}, {Delay= 0.5/math.random(2,3), Frame= 2}, {Delay= 0.5/math.random(2,3), Frame= 1}, {Delay= 0.5/math.random(2,3), Frame= 0}},
		OnCommand=cmd(x,80;y,420;setstate,0;addx,WDX2;effectclock,'beat')
	};
		Def.Sprite{
		Texture = "2 4x1.png", 
		Frames = {{Delay= 0.5/math.random(2,3), Frame= 0}, {Delay= 0.5/math.random(2,3), Frame= 1}, {Delay= 0.5/math.random(2,3), Frame= 2}, {Delay= 0.5/math.random(2,3), Frame= 3}},
		OnCommand=cmd(x,240;y,420;setstate,1;addx,WDX2;effectclock,'beat')
	};
		Def.Sprite{
		Texture = "2 4x1.png", 
		Frames = {{Delay= 0.5/math.random(2,3), Frame= 3}, {Delay= 0.5/math.random(2,3), Frame= 2}, {Delay= 0.5/math.random(2,3), Frame= 1}, {Delay= 0.5/math.random(2,3), Frame= 0}},
		OnCommand=cmd(x,400;y,420;setstate,2;addx,WDX2;effectclock,'beat')
	};
		Def.Sprite{
		Texture = "2 4x1.png", 
		Frames = {{Delay= 0.5/math.random(2,3), Frame= 0}, {Delay= 0.5/math.random(2,3), Frame= 1}, {Delay= 0.5/math.random(2,3), Frame= 2}, {Delay= 0.5/math.random(2,3), Frame= 3}},
		OnCommand=cmd(x,560;y,420;setstate,3;addx,WDX2;effectclock,'beat')
	};
		Def.Sprite{
		Texture = "2 4x1.png", 
		Frames = {{Delay= 0.5/math.random(2,3), Frame= 3}, {Delay= 0.5/math.random(2,3), Frame= 2}, {Delay= 0.5/math.random(2,3), Frame= 1}, {Delay= 0.5/math.random(2,3), Frame= 0}},
		OnCommand=cmd(x,720;y,420;setstate,0;addx,WDX2;effectclock,'beat')
	};
		Def.Sprite{
		Texture = "2 4x1.png", 
		Frames = {{Delay= 0.5/math.random(2,3), Frame= 0}, {Delay= 0.5/math.random(2,3), Frame= 1}, {Delay= 0.5/math.random(2,3), Frame= 2}, {Delay= 0.5/math.random(2,3), Frame= 3}},
		OnCommand=cmd(x,880;y,420;setstate,1;addx,WDX2;effectclock,'beat')
	};
};

return t;
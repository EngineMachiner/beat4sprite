local WDX2 if SCREEN_WIDTH > 640 then WDX2 = -80/4 else WDX2 = 0 end;
local t = Def.ActorFrame{
	LoadActor("1")..{
		OnCommand=cmd(x,160;y,120)
	};
	LoadActor("1")..{
		OnCommand=cmd(x,480;y,120)
	};
	LoadActor("1")..{
		OnCommand=cmd(x,800;y,120)
	};
	LoadActor("1")..{
		OnCommand=cmd(x,1120;y,120)
	};
	LoadActor("1")..{
		OnCommand=cmd(x,160;y,360)
	};
	LoadActor("1")..{
		OnCommand=cmd(x,480;y,360)
	};
	LoadActor("1")..{
		OnCommand=cmd(x,800;y,360)
	};
	LoadActor("1")..{
		OnCommand=cmd(x,1120;y,360)
	};
	LoadActor("1")..{
		OnCommand=cmd(x,160;y,600)
	};
	LoadActor("1")..{
		OnCommand=cmd(x,480;y,600)
	};
	LoadActor("1")..{
		OnCommand=cmd(x,800;y,600)
	};
	LoadActor("1")..{
		OnCommand=cmd(x,1120;y,600)
	};
		LoadActor("../Sprites/InnerEffect/Reverse/Globe", "Globe 6x1.png")..{
		OnCommand=function(self)
			self:effectclock('beat')
		end
	},
};

return t;
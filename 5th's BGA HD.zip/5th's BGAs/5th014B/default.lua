return Def.ActorFrame{

	LoseFocusCommand=function(self)
		self:RunCommandsOnChildren(function(child) child:visible(false):finishtweening() end, {})
	end,
		LoadActor("B.lua")..{
		OnCommand=cmd(x,0;y,0;sleep,0.5;addx,-40;addy,-40;sleep,0.5;addx,-40;addy,-40;sleep,0.5;addx,-40;addy,-40;sleep,0.5;addx,-40;addy,-40;effectclock,"beat";queuecommand,"On")
	};
		LoadActor("C.lua")..{
		OnCommand=cmd(x,0;y,0;sleep,0.5;addx,-40;addy,-40;sleep,0.5;addx,-40;addy,-40;sleep,0.5;addx,-40;addy,-40;sleep,0.5;addx,-40;addy,-40;effectclock,"beat";queuecommand,"On")
	};
	
		LoadActor("../Sprites/InnerEffect/Circle/Orange", "2 Orange 2x1.png")..{
		OnCommand=function(self)
			self:hibernate(0)
		end
	},
	
		LoadActor("../Sprites/InnerEffect/Circle/Orange", "2 Orange 2x1.png")..{
		OnCommand=function(self)
			self:hibernate(1)
		end
	},
	
		LoadActor("../Sprites/InnerEffect/Circle/Orange", "2 Orange 2x1.png")..{
		OnCommand=function(self)
			self:hibernate(2)
		end
	},
	
		LoadActor("../Sprites/InnerEffect/Circle/Orange", "2 Orange 2x1.png")..{
		OnCommand=function(self)
			self:hibernate(3)
		end
	},
	
		LoadActor("../Sprites/InnerEffect/Circle/Orange", "2 Orange 2x1.png")..{
		OnCommand=function(self)
			self:hibernate(4)
		end
	},
	
		LoadActor("../Sprites/InnerEffect/Circle/Orange", "2 Orange 2x1.png")..{
		OnCommand=function(self)
			self:hibernate(5)
		end
	},
	
		LoadActor("../Sprites/InnerEffect/Circle/Orange", "2 Orange 2x1.png")..{
		OnCommand=function(self)
			self:hibernate(6)
		end
	},
	
		LoadActor("../Sprites/InnerEffect/Circle/Orange", "2 Orange 2x1.png")..{
		OnCommand=function(self)
			self:hibernate(7)
		end
	},
	
		LoadActor("../Sprites/InnerEffect/Circle/Orange", "2 Orange 2x1.png")..{
		OnCommand=function(self)
			self:hibernate(8)
		end
	},
}
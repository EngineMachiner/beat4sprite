return Def.ActorFrame{

	LoseFocusCommand=function(self)
		self:RunCommandsOnChildren(function(child) child:visible(false):finishtweening() end, {})
	end,
		LoadActor("A.lua")..{
		OnCommand=cmd(Center;addx,40*8;addy,40*8)
	};
		LoadActor("A.lua")..{
		OnCommand=cmd(Center;addx,640;addx,40*8;addy,40*8)
	};
		LoadActor("A.lua")..{
		OnCommand=cmd(Center;addx,-640;addx,40*8;addy,40*8)
	};
	
		LoadActor("A.lua")..{
		OnCommand=cmd(Center;addx,-40*8;addy,-40*8)
	};
		LoadActor("A.lua")..{
		OnCommand=cmd(Center;addx,640;addx,-40*8;addy,-40*8)
	};
		LoadActor("A.lua")..{
		OnCommand=cmd(Center;addx,-640;addx,-40*8;addy,-40*8)
	};
}
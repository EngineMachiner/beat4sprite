local WDX2 if SCREEN_WIDTH > 640 then WDX2 = -80/1.5 else WDX2 = 0 end;
return Def.ActorFrame{
	LoseFocusCommand=function(self)
		self:RunCommandsOnChildren(function(child) child:visible(false):finishtweening() end, {})
	end,
	LoadActor("1")..{
		OnCommand=cmd(x,80;y,60;addx,WDX2;effectclock,"beat")
	};
	LoadActor("1")..{
		OnCommand=cmd(x,240;y,60;addx,WDX2;effectclock,"beat")
	};
	LoadActor("1")..{
		OnCommand=cmd(x,400;y,60;addx,WDX2;effectclock,"beat")
	};
	LoadActor("1")..{
		OnCommand=cmd(x,560;y,60;addx,WDX2;effectclock,"beat")
	};
	LoadActor("1")..{
		OnCommand=cmd(x,720;y,60;addx,WDX2;effectclock,"beat")
	};
	LoadActor("1")..{
		OnCommand=cmd(x,880;y,60;addx,WDX2;effectclock,"beat")
	};
	LoadActor("1")..{
		OnCommand=cmd(x,80;y,180;addx,WDX2;effectclock,"beat")
	};
	LoadActor("1")..{
		OnCommand=cmd(x,240;y,180;addx,WDX2;effectclock,"beat")
	};
	LoadActor("1")..{
		OnCommand=cmd(x,400;y,180;addx,WDX2;effectclock,"beat")
	};
	LoadActor("1")..{
		OnCommand=cmd(x,560;y,180;addx,WDX2;effectclock,"beat")
	};
	LoadActor("1")..{
		OnCommand=cmd(x,720;y,180;addx,WDX2;effectclock,"beat")
	};
	LoadActor("1")..{
		OnCommand=cmd(x,880;y,180;addx,WDX2;effectclock,"beat")
	};
	LoadActor("1")..{
		OnCommand=cmd(x,80;y,300;addx,WDX2;effectclock,"beat")
	};
	LoadActor("1")..{
		OnCommand=cmd(x,240;y,300;addx,WDX2;effectclock,"beat")
	};
	LoadActor("1")..{
		OnCommand=cmd(x,400;y,300;addx,WDX2;effectclock,"beat")
	};
	LoadActor("1")..{
		OnCommand=cmd(x,560;y,300;addx,WDX2;effectclock,"beat")
	};
	LoadActor("1")..{
		OnCommand=cmd(x,720;y,300;addx,WDX2;effectclock,"beat")
	};
	LoadActor("1")..{
		OnCommand=cmd(x,880;y,300;addx,WDX2;effectclock,"beat")
	};
	LoadActor("1")..{
		OnCommand=cmd(x,80;y,420;addx,WDX2;effectclock,"beat")
	};
	LoadActor("1")..{
		OnCommand=cmd(x,240;y,420;addx,WDX2;effectclock,"beat")
	};
	LoadActor("1")..{
		OnCommand=cmd(x,400;y,420;addx,WDX2;effectclock,"beat")
	};
	LoadActor("1")..{
		OnCommand=cmd(x,560;y,420;addx,WDX2;effectclock,"beat")
	};
	LoadActor("1")..{
		OnCommand=cmd(x,720;y,420;addx,WDX2;effectclock,"beat")
	};
	LoadActor("1")..{
		OnCommand=cmd(x,880;y,420;addx,WDX2;effectclock,"beat")
	};
		Def.Sprite{
		Texture = "2.png", 

		OnCommand=function(self)
		self:x(80)
			:y(60)
			:addx(WDX2)
			:rotationx(0):linear(2):rotationx(90):linear(2):rotationx(0):queuecommand( "On" ):effectclock('beat'):set_tween_uses_effect_delta(true)
			end
	};
		Def.Sprite{
		Texture = "2.png", 

		OnCommand=function(self)
		self:x(240)
			:y(60)
			:addx(WDX2)
			:rotationx(0):linear(2):rotationx(90):linear(2):rotationx(0):queuecommand( "On" ):effectclock('beat'):set_tween_uses_effect_delta(true)
			end	};
		Def.Sprite{
		Texture = "2.png", 

		OnCommand=function(self)
		self:x(400)
			:y(60)
			:addx(WDX2)
			:rotationx(0):linear(2):rotationx(90):linear(2):rotationx(0):queuecommand( "On" ):effectclock('beat'):set_tween_uses_effect_delta(true)
			end	};
		Def.Sprite{
		Texture = "2.png", 

		OnCommand=function(self)
		self:x(560)
			:y(60)
			:addx(WDX2)
			:rotationx(0):linear(2):rotationx(90):linear(2):rotationx(0):queuecommand( "On" ):effectclock('beat'):set_tween_uses_effect_delta(true)
			end	};
		Def.Sprite{
		Texture = "2.png", 

		OnCommand=function(self)
		self:x(720)
			:y(60)
			:addx(WDX2)
			:rotationx(0):linear(2):rotationx(90):linear(2):rotationx(0):queuecommand( "On" ):effectclock('beat'):set_tween_uses_effect_delta(true)
			end	};
		Def.Sprite{
		Texture = "2.png", 

		OnCommand=function(self)
		self:x(880)
			:y(60)
			:addx(WDX2)
			:rotationx(0):linear(2):rotationx(90):linear(2):rotationx(0):queuecommand( "On" ):effectclock('beat'):set_tween_uses_effect_delta(true)
			end	};

		Def.Sprite{
		Texture = "2.png", 

		OnCommand=function(self)
		self:x(80)
			:y(180)
			:addx(WDX2)
			:rotationx(0):linear(2):rotationx(90):linear(2):rotationx(0):queuecommand( "On" ):effectclock('beat'):set_tween_uses_effect_delta(true)
			end	};
		Def.Sprite{
		Texture = "2.png", 

		OnCommand=function(self)
		self:x(240)
			:y(180)
			:addx(WDX2)
			:rotationx(0):linear(2):rotationx(90):linear(2):rotationx(0):queuecommand( "On" ):effectclock('beat'):set_tween_uses_effect_delta(true)
			end	};
		Def.Sprite{
		Texture = "2.png", 

		OnCommand=function(self)
		self:x(400)
			:y(180)
			:addx(WDX2)
			:rotationx(0):linear(2):rotationx(90):linear(2):rotationx(0):queuecommand( "On" ):effectclock('beat'):set_tween_uses_effect_delta(true)
			end	};
		Def.Sprite{
		Texture = "2.png", 

		OnCommand=function(self)
		self:x(560)
			:y(180)
			:addx(WDX2)
			:rotationx(0):linear(2):rotationx(90):linear(2):rotationx(0):queuecommand( "On" ):effectclock('beat'):set_tween_uses_effect_delta(true)
			end	};
		Def.Sprite{
		Texture = "2.png", 

		OnCommand=function(self)
		self:x(720)
			:y(180)
			:addx(WDX2)
			:rotationx(0):linear(2):rotationx(90):linear(2):rotationx(0):queuecommand( "On" ):effectclock('beat'):set_tween_uses_effect_delta(true)
			end	};
		Def.Sprite{
		Texture = "2.png", 

		OnCommand=function(self)
		self:x(880)
			:y(180)
			:addx(WDX2)
			:rotationx(0):linear(2):rotationx(90):linear(2):rotationx(0):queuecommand( "On" ):effectclock('beat'):set_tween_uses_effect_delta(true)
			end	};
		Def.Sprite{
		Texture = "2.png", 

		OnCommand=function(self)
		self:x(80)
			:y(300)
			:addx(WDX2)
			:rotationx(0):linear(2):rotationx(90):linear(2):rotationx(0):queuecommand( "On" ):effectclock('beat'):set_tween_uses_effect_delta(true)
			end	};
		Def.Sprite{
		Texture = "2.png", 

		OnCommand=function(self)
		self:x(240)
			:y(300)
			:addx(WDX2)
			:rotationx(0):linear(2):rotationx(90):linear(2):rotationx(0):queuecommand( "On" ):effectclock('beat'):set_tween_uses_effect_delta(true)
			end	};
		Def.Sprite{
		Texture = "2.png", 

		OnCommand=function(self)
		self:x(400)
			:y(300)
			:addx(WDX2)
			:rotationx(0):linear(2):rotationx(90):linear(2):rotationx(0):queuecommand( "On" ):effectclock('beat'):set_tween_uses_effect_delta(true)
			end	};
		Def.Sprite{
		Texture = "2.png", 

		OnCommand=function(self)
		self:x(560)
			:y(300)
			:addx(WDX2)
			:rotationx(0):linear(2):rotationx(90):linear(2):rotationx(0):queuecommand( "On" ):effectclock('beat'):set_tween_uses_effect_delta(true)
			end	};
		Def.Sprite{
		Texture = "2.png", 

		OnCommand=function(self)
		self:x(720)
			:y(300)
			:addx(WDX2)
			:rotationx(0):linear(2):rotationx(90):linear(2):rotationx(0):queuecommand( "On" ):effectclock('beat'):set_tween_uses_effect_delta(true)
			end	};
		Def.Sprite{
		Texture = "2.png", 

		OnCommand=function(self)
		self:x(880)
			:y(300)
			:addx(WDX2)
			:rotationx(0):linear(2):rotationx(90):linear(2):rotationx(0):queuecommand( "On" ):effectclock('beat'):set_tween_uses_effect_delta(true)
			end	};
		Def.Sprite{
		Texture = "2.png", 

		OnCommand=function(self)
		self:x(80)
			:y(420)
			:addx(WDX2)
			:rotationx(0):linear(2):rotationx(90):linear(2):rotationx(0):queuecommand( "On" ):effectclock('beat'):set_tween_uses_effect_delta(true)
			end	};
		Def.Sprite{
		Texture = "2.png", 

		OnCommand=function(self)
		self:x(240)
			:y(420)
			:addx(WDX2)
			:rotationx(0):linear(2):rotationx(90):linear(2):rotationx(0):queuecommand( "On" ):effectclock('beat'):set_tween_uses_effect_delta(true)
			end	};
		Def.Sprite{
		Texture = "2.png", 

		OnCommand=function(self)
		self:x(400)
			:y(420)
			:addx(WDX2)
			:rotationx(0):linear(2):rotationx(90):linear(2):rotationx(0):queuecommand( "On" ):effectclock('beat'):set_tween_uses_effect_delta(true)
			end	};
		Def.Sprite{
		Texture = "2.png", 

		OnCommand=function(self)
		self:x(560)
			:y(420)
			:addx(WDX2)
			:rotationx(0):linear(2):rotationx(90):linear(2):rotationx(0):queuecommand( "On" ):effectclock('beat'):set_tween_uses_effect_delta(true)
			end	};
		Def.Sprite{
		Texture = "2.png", 

		OnCommand=function(self)
		self:x(720)
			:y(420)
			:addx(WDX2)
			:rotationx(0):linear(2):rotationx(90):linear(2):rotationx(0):queuecommand( "On" ):effectclock('beat'):set_tween_uses_effect_delta(true)
			end	};
		Def.Sprite{
		Texture = "2.png", 

		OnCommand=function(self)
		self:x(880)
			:y(420)
			:addx(WDX2)
			:rotationx(0):linear(2):rotationx(90):linear(2):rotationx(0):queuecommand( "On" ):effectclock('beat'):set_tween_uses_effect_delta(true)
			end	};
}
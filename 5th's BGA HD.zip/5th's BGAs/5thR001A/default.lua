return Def.ActorFrame{
	LoseFocusCommand=function(self)
		self:RunCommandsOnChildren(function(child) child:visible(false):finishtweening() end, {})
	end,
	
	LoadActor("B.lua")..{
		OnCommand=function(self)
		self:diffusealpha(1)
		:zoom(2)
		:addx(-425)
		:addy(-240)
		end
	};
}
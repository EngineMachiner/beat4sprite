local WDX2 if SCREEN_WIDTH > 640 then WDX2 = -80/1.45 else WDX2 = 0 end;
local t = Def.ActorFrame{
		Def.Sprite{
		Texture = "1 4x1.png", 
		Frames = {{Delay= 0.25, Frame= math.random(0,3)}, {Delay= 0.25, Frame= math.random(1,3)}, {Delay= 0.25, Frame= math.random(1,3)}, {Delay= 0.25, Frame= math.random(0,3)}},
		OnCommand=cmd(x,80;y,80;addx,WDX2;effectclock,"beat")
	};
		Def.Sprite{
		Texture = "1 4x1.png", 
		Frames = {{Delay= 0.25, Frame= math.random(0,3)}, {Delay= 0.25, Frame= math.random(1,3)}, {Delay= 0.25, Frame= math.random(1,3)}, {Delay= 0.25, Frame= math.random(0,3)}},
		OnCommand=cmd(x,240;y,80;addx,WDX2;effectclock,"beat")
	};
		Def.Sprite{
		Texture = "1 4x1.png", 
		Frames = {{Delay= 0.25, Frame= math.random(0,3)}, {Delay= 0.25, Frame= math.random(1,3)}, {Delay= 0.25, Frame= math.random(1,3)}, {Delay= 0.25, Frame= math.random(0,3)}},
		OnCommand=cmd(x,400;y,80;addx,WDX2;effectclock,"beat")
	};
		Def.Sprite{
		Texture = "1 4x1.png", 
		Frames = {{Delay= 0.25, Frame= math.random(0,3)}, {Delay= 0.25, Frame= math.random(1,3)}, {Delay= 0.25, Frame= math.random(1,3)}, {Delay= 0.25, Frame= math.random(0,3)}},
		OnCommand=cmd(x,560;y,80;addx,WDX2;effectclock,"beat")
	};
		Def.Sprite{
		Texture = "1 4x1.png", 
		Frames = {{Delay= 0.25, Frame= math.random(0,3)}, {Delay= 0.25, Frame= math.random(1,3)}, {Delay= 0.25, Frame= math.random(1,3)}, {Delay= 0.25, Frame= math.random(0,3)}},
		OnCommand=cmd(x,720;y,80;addx,WDX2;effectclock,"beat")
	};
		Def.Sprite{
		Texture = "1 4x1.png", 
		Frames = {{Delay= 0.25, Frame= math.random(0,3)}, {Delay= 0.25, Frame= math.random(1,3)}, {Delay= 0.25, Frame= math.random(1,3)}, {Delay= 0.25, Frame= math.random(0,3)}},
		OnCommand=cmd(x,880;y,80;addx,WDX2;effectclock,"beat")
	};
		Def.Sprite{
		Texture = "1 4x1.png", 
		Frames = {{Delay= 0.25, Frame= math.random(0,3)}, {Delay= 0.25, Frame= math.random(1,3)}, {Delay= 0.25, Frame= math.random(1,3)}, {Delay= 0.25, Frame= math.random(0,3)}},
		OnCommand=cmd(x,80;y,240;addx,WDX2;effectclock,"beat")
	};
		Def.Sprite{
		Texture = "1 4x1.png", 
		Frames = {{Delay= 0.25, Frame= math.random(0,3)}, {Delay= 0.25, Frame= math.random(1,3)}, {Delay= 0.25, Frame= math.random(1,3)}, {Delay= 0.25, Frame= math.random(0,3)}},
		OnCommand=cmd(x,240;y,240;addx,WDX2;effectclock,"beat")
	};
		Def.Sprite{
		Texture = "1 4x1.png", 
		Frames = {{Delay= 0.25, Frame= math.random(0,3)}, {Delay= 0.25, Frame= math.random(1,3)}, {Delay= 0.25, Frame= math.random(1,3)}, {Delay= 0.25, Frame= math.random(0,3)}},
		OnCommand=cmd(x,400;y,240;addx,WDX2;effectclock,"beat")
	};
		Def.Sprite{
		Texture = "1 4x1.png", 
		Frames = {{Delay= 0.25, Frame= math.random(0,3)}, {Delay= 0.25, Frame= math.random(1,3)}, {Delay= 0.25, Frame= math.random(1,3)}, {Delay= 0.25, Frame= math.random(0,3)}},
		OnCommand=cmd(x,560;y,240;addx,WDX2;effectclock,"beat")
	};
		Def.Sprite{
		Texture = "1 4x1.png", 
		Frames = {{Delay= 0.25, Frame= math.random(0,3)}, {Delay= 0.25, Frame= math.random(1,3)}, {Delay= 0.25, Frame= math.random(1,3)}, {Delay= 0.25, Frame= math.random(0,3)}},
		OnCommand=cmd(x,720;y,240;addx,WDX2;effectclock,"beat")
	};
		Def.Sprite{
		Texture = "1 4x1.png", 
		Frames = {{Delay= 0.25, Frame= math.random(0,3)}, {Delay= 0.25, Frame= math.random(1,3)}, {Delay= 0.25, Frame= math.random(1,3)}, {Delay= 0.25, Frame= math.random(0,3)}},
		OnCommand=cmd(x,880;y,240;addx,WDX2;effectclock,"beat")
	};
		Def.Sprite{
		Texture = "1 4x1.png", 
		Frames = {{Delay= 0.25, Frame= math.random(0,3)}, {Delay= 0.25, Frame= math.random(1,3)}, {Delay= 0.25, Frame= math.random(1,3)}, {Delay= 0.25, Frame= math.random(0,3)}},
		OnCommand=cmd(x,80;y,400;addx,WDX2;effectclock,"beat")
	};
		Def.Sprite{
		Texture = "1 4x1.png", 
		Frames = {{Delay= 0.25, Frame= math.random(0,3)}, {Delay= 0.25, Frame= math.random(1,3)}, {Delay= 0.25, Frame= math.random(1,3)}, {Delay= 0.25, Frame= math.random(0,3)}},
		OnCommand=cmd(x,240;y,400;addx,WDX2;effectclock,"beat")
	};
		Def.Sprite{
		Texture = "1 4x1.png", 
		Frames = {{Delay= 0.25, Frame= math.random(0,3)}, {Delay= 0.25, Frame= math.random(1,3)}, {Delay= 0.25, Frame= math.random(1,3)}, {Delay= 0.25, Frame= math.random(0,3)}},
		OnCommand=cmd(x,400;y,400;addx,WDX2;effectclock,"beat")
	};
		Def.Sprite{
		Texture = "1 4x1.png", 
		Frames = {{Delay= 0.25, Frame= math.random(0,3)}, {Delay= 0.25, Frame= math.random(1,3)}, {Delay= 0.25, Frame= math.random(1,3)}, {Delay= 0.25, Frame= math.random(0,3)}},
		OnCommand=cmd(x,560;y,400;addx,WDX2;effectclock,"beat")
	};
		Def.Sprite{
		Texture = "1 4x1.png", 
		Frames = {{Delay= 0.25, Frame= math.random(0,3)}, {Delay= 0.25, Frame= math.random(1,3)}, {Delay= 0.25, Frame= math.random(1,3)}, {Delay= 0.25, Frame= math.random(0,3)}},
		OnCommand=cmd(x,720;y,400;addx,WDX2;effectclock,"beat")
	};
		Def.Sprite{
		Texture = "1 4x1.png", 
		Frames = {{Delay= 0.25, Frame= math.random(0,3)}, {Delay= 0.25, Frame= math.random(1,3)}, {Delay= 0.25, Frame= math.random(1,3)}, {Delay= 0.25, Frame= math.random(0,3)}},
		OnCommand=cmd(x,880;y,400;addx,WDX2;effectclock,"beat")
	};
		Def.Sprite{
		Texture = "1 4x1.png", 
		Frames = {{Delay= 0.25, Frame= math.random(0,3)}, {Delay= 0.25, Frame= math.random(1,3)}, {Delay= 0.25, Frame= math.random(1,3)}, {Delay= 0.25, Frame= math.random(0,3)}},
		OnCommand=cmd(x,80;y,560;addx,WDX2;effectclock,"beat")
	};
		Def.Sprite{
		Texture = "1 4x1.png", 
		Frames = {{Delay= 0.25, Frame= math.random(0,3)}, {Delay= 0.25, Frame= math.random(1,3)}, {Delay= 0.25, Frame= math.random(1,3)}, {Delay= 0.25, Frame= math.random(0,3)}},
		OnCommand=cmd(x,240;y,560;addx,WDX2;effectclock,"beat")
	};
		Def.Sprite{
		Texture = "1 4x1.png", 
		Frames = {{Delay= 0.25, Frame= math.random(0,3)}, {Delay= 0.25, Frame= math.random(1,3)}, {Delay= 0.25, Frame= math.random(1,3)}, {Delay= 0.25, Frame= math.random(0,3)}},
		OnCommand=cmd(x,400;y,560;addx,WDX2;effectclock,"beat")
	};
		Def.Sprite{
		Texture = "1 4x1.png", 
		Frames = {{Delay= 0.25, Frame= math.random(0,3)}, {Delay= 0.25, Frame= math.random(1,3)}, {Delay= 0.25, Frame= math.random(1,3)}, {Delay= 0.25, Frame= math.random(0,3)}},
		OnCommand=cmd(x,560;y,560;addx,WDX2;effectclock,"beat")
	};
		Def.Sprite{
		Texture = "1 4x1.png", 
		Frames = {{Delay= 0.25, Frame= math.random(0,3)}, {Delay= 0.25, Frame= math.random(1,3)}, {Delay= 0.25, Frame= math.random(1,3)}, {Delay= 0.25, Frame= math.random(0,3)}},
		OnCommand=cmd(x,720;y,560;addx,WDX2;effectclock,"beat")
	};
		Def.Sprite{
		Texture = "1 4x1.png", 
		Frames = {{Delay= 0.25, Frame= math.random(0,3)}, {Delay= 0.25, Frame= math.random(1,3)}, {Delay= 0.25, Frame= math.random(1,3)}, {Delay= 0.25, Frame= math.random(0,3)}},
		OnCommand=cmd(x,880;y,560;addx,WDX2;effectclock,"beat")
	};
	LoadActor("2 (stretch)")..{
		OnCommand=function(self)
			self:Center():FullScreen()
			:zoom(3)
			:customtexturerect(0,0,3,3)
			:set_use_effect_clock_for_texcoords(true)
			:texcoordvelocity(0.15/4,0):effectclock('beat')
		end
	},
};

return t;
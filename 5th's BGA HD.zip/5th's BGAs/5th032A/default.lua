local WDX2 if SCREEN_WIDTH > 640 then WDX2 = -80/1.5 else WDX2 = 0 end;
local t = Def.ActorFrame{
		Def.Sprite{
		Texture = "1 1x2.png", 
		Frames = {{Delay= 0.5, Frame= 0}, {Delay= 0.5, Frame= 1}},
		OnCommand=cmd(x,160;y,160;addx,WDX2;effectclock,"beat")
	};
		Def.Sprite{
		Texture = "1 1x2.png", 
		Frames = {{Delay= 0.5, Frame= 0}, {Delay= 0.5, Frame= 1}},
		OnCommand=cmd(x,480;y,160;addx,WDX2;effectclock,"beat")
	};
		Def.Sprite{
		Texture = "1 1x2.png", 
		Frames = {{Delay= 0.5, Frame= 0}, {Delay= 0.5, Frame= 1}},
		OnCommand=cmd(x,800;y,160;addx,WDX2;effectclock,"beat")
	};
		Def.Sprite{
		Texture = "1 1x2.png", 
		Frames = {{Delay= 0.5, Frame= 0}, {Delay= 0.5, Frame= 1}},
		OnCommand=cmd(x,160;y,480;addx,WDX2;effectclock,"beat")
	};
		Def.Sprite{
		Texture = "1 1x2.png", 
		Frames = {{Delay= 0.5, Frame= 0}, {Delay= 0.5, Frame= 1}},
		OnCommand=cmd(x,480;y,480;addx,WDX2;effectclock,"beat")
	};
		Def.Sprite{
		Texture = "1 1x2.png", 
		Frames = {{Delay= 0.5, Frame= 0}, {Delay= 0.5, Frame= 1}},
		OnCommand=cmd(x,800;y,480;addx,WDX2;effectclock,"beat")
	};
};

return t;
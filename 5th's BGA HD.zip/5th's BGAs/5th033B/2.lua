local t = Def.ActorFrame{
	LoadActor("Sprite.lua")..{
		OnCommand=cmd(x,0;y,0;linear,1.75*4;set_tween_uses_effect_delta,true;effectclock,"beat";x,-248;y,-232;queuecommand,"On")
	};
};

return t;
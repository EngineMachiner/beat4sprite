return Def.ActorFrame{

	LoseFocusCommand=function(self)
		self:RunCommandsOnChildren(function(child) child:visible(false):finishtweening() end, {})
	end,
	LoadActor("Sprite.lua")..{
		OnCommand=cmd(x,0;y,0;linear,1.75*4;set_tween_uses_effect_delta,true;effectclock,"beat";x,-248;y,-232;rainbow;effectperiod,8;queuecommand,"On")
	};
	LoadActor("2")..{
		OnCommand=cmd(x,248;rainbow;effectperiod,8;effectclock,"beat";set_tween_uses_effect_delta,true)
	};
}
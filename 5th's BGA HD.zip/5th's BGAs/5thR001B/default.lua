return Def.ActorFrame{
	LoseFocusCommand=function(self)
		self:RunCommandsOnChildren(function(child) child:visible(false):finishtweening() end, {})
	end,
	
	LoadActor("B.lua")..{
		OnCommand=function(self)
		self:diffusealpha(1)
		:zoom(2)
		:addx(-425)
		:addy(-240)
		end
	};
	
		LoadActor("../Sprites/InnerEffect/Circle/Star", "2 Star 12x1.png")..{
		OnCommand=function(self)
			self:effectclock('beat')
		end
	},
	
		LoadActor("../Sprites/InnerEffect/Circle/Star", "2 Star 12x1.png")..{
		OnCommand=function(self)
			self:hibernate(1):effectclock('beat')
		end
	},
	
		LoadActor("../Sprites/InnerEffect/Circle/Star", "2 Star 12x1.png")..{
		OnCommand=function(self)
			self:hibernate(2):effectclock('beat')
		end
	},
	
		LoadActor("../Sprites/InnerEffect/Circle/Star", "2 Star 12x1.png")..{
		OnCommand=function(self)
			self:hibernate(3):effectclock('beat')
		end
	},
	
		LoadActor("../Sprites/InnerEffect/Circle/Star", "2 Star 12x1.png")..{
		OnCommand=function(self)
			self:hibernate(4):effectclock('beat')
		end
	},
	
		LoadActor("../Sprites/InnerEffect/Circle/Star", "2 Star 12x1.png")..{
		OnCommand=function(self)
			self:hibernate(5):effectclock('beat')
		end
	},
	
		LoadActor("../Sprites/InnerEffect/Circle/Star", "2 Star 12x1.png")..{
		OnCommand=function(self)
			self:hibernate(6):effectclock('beat')
		end
	},
	
		LoadActor("../Sprites/InnerEffect/Circle/Star", "2 Star 12x1.png")..{
		OnCommand=function(self)
			self:hibernate(7):effectclock('beat')
		end
	},
	
		LoadActor("../Sprites/InnerEffect/Circle/Star", "2 Star 12x1.png")..{
		OnCommand=function(self)
			self:hibernate(8):effectclock('beat')
		end
	},
}
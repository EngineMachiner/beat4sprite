local SongBeat = 1

return Def.ActorFrame{
	LoseFocusCommand=function(self)
		self:RunCommandsOnChildren(function(child) child:visible(false):finishtweening() end, {})
	end,
	
	
	LoadActor("Circle4")..{
		OnCommand=function(self)
		self:x(SCREEN_CENTER_X)
		:y(SCREEN_CENTER_Y)
		:rainbow():effectperiod(8/2):effectoffset(0.7)
		:zoom(2)
		:linear(SongBeat)
		:zoom(1.75)
		:linear(SongBeat)
		:zoom(1.5)
		:effectclock("beat"):set_tween_uses_effect_delta(true)
		:queuecommand("On")
		end
	};
	
	LoadActor("Circle3")..{
		OnCommand=function(self)
		self:x(SCREEN_CENTER_X)
		:y(SCREEN_CENTER_Y)
		:rainbow():effectperiod(8/2):effectoffset(0.8)
		:zoom(1.75)
		:linear(SongBeat)
		:zoom(1.5)
		:linear(SongBeat)
		:zoom(1.25)
		:effectclock("beat"):set_tween_uses_effect_delta(true)
		:queuecommand("On")
		end
	};
	
	LoadActor("Circle4")..{
		OnCommand=function(self)
		self:x(SCREEN_CENTER_X)
		:y(SCREEN_CENTER_Y)
		:rainbow():effectperiod(8/2):effectoffset(0.9)
		:zoom(1.5)
		:linear(SongBeat)
		:zoom(1.25)
		:linear(SongBeat)
		:zoom(1)
		:effectclock("beat"):set_tween_uses_effect_delta(true)
		:queuecommand("On")
		end
	};
	
	LoadActor("Circle3")..{
		OnCommand=function(self)
		self:x(SCREEN_CENTER_X)
		:y(SCREEN_CENTER_Y)
		:rainbow():effectperiod(8/2):effectoffset(1)
		:zoom(1.25)
		:linear(SongBeat)
		:zoom(1)
		:linear(SongBeat)
		:zoom(0.75)
		:effectclock("beat"):set_tween_uses_effect_delta(true)
		:queuecommand("On")
		end
	};
	
	LoadActor("Circle4")..{
		OnCommand=function(self)
		self:x(SCREEN_CENTER_X)
		:y(SCREEN_CENTER_Y)
		:rainbow():effectperiod(8/2):effectoffset(1.1)
		:zoom(1)
		:linear(SongBeat)
		:zoom(0.75)
		:linear(SongBeat)
		:zoom(0.5)
		:effectclock("beat"):set_tween_uses_effect_delta(true)
		:queuecommand("On")
		end
	};
	
	LoadActor("Circle3")..{
		OnCommand=function(self)
		self:x(SCREEN_CENTER_X)
		:y(SCREEN_CENTER_Y)
		:rainbow():effectperiod(8/2):effectoffset(1.2)
		:zoom(0.75)
		:linear(SongBeat)
		:zoom(0.5)
		:linear(SongBeat)
		:zoom(0.25)
		:effectclock("beat"):set_tween_uses_effect_delta(true)
		:queuecommand("On")
		end
	};	
	
	LoadActor("Circle4")..{
		OnCommand=function(self)
		self:x(SCREEN_CENTER_X)
		:y(SCREEN_CENTER_Y)
		:rainbow():effectperiod(8/2):effectoffset(1.3)
		:zoom(0.5)
		:linear(SongBeat)
		:zoom(0.25)
		:linear(SongBeat)
		:zoom(0)
		:effectclock("beat"):set_tween_uses_effect_delta(true)
		:queuecommand("On")
		end
	};
	
	LoadActor("Circle3")..{
		OnCommand=function(self)
		self:x(SCREEN_CENTER_X)
		:y(SCREEN_CENTER_Y)
		:rainbow():effectperiod(8/2):effectoffset(1.4)
		:zoom(0.25)
		:linear(SongBeat)
		:zoom(0)
		:linear(SongBeat)
		:zoom(0)
		:effectclock("beat"):set_tween_uses_effect_delta(true)
		:queuecommand("On")
		end
	};
	
}
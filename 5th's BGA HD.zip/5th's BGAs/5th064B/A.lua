return Def.ActorFrame{
	LoseFocusCommand=function(self)
		self:RunCommandsOnChildren(function(child) child:visible(false):finishtweening() end, {})
	end,

		LoadActor("../Sprites/ParticlesDown/Static", "Symbol.png")..{
		OnCommand=function(self)
			self:effectclock('beat')
			
		end
	},
	
		LoadActor("../Sprites/ParticlesDown/Static", "Symbol.png")..{
		OnCommand=function(self)
			self:effectclock('beat')
			
		end
	},
	
		LoadActor("../Sprites/ParticlesDown/Static", "Symbol.png")..{
		OnCommand=function(self)
			self:effectclock('beat')
			
		end
	},
	
		LoadActor("../Sprites/ParticlesDown/Static", "Symbol.png")..{
		OnCommand=function(self)
			self:effectclock('beat')
			
		end
	},
	
		LoadActor("../Sprites/ParticlesDown/Static", "Symbol.png")..{
		OnCommand=function(self)
			self:effectclock('beat')
			
		end
	},
	
		LoadActor("../Sprites/ParticlesDown/Static", "Symbol.png")..{
		OnCommand=function(self)
			self:effectclock('beat')
			
		end
	},

		LoadActor("../Sprites/ParticlesDown/Static", "Symbol.png")..{
		OnCommand=function(self)
			self:effectclock('beat')
			
		end
	},

		LoadActor("../Sprites/ParticlesDown/Static", "Symbol.png")..{
		OnCommand=function(self)
			self:effectclock('beat')
			
		end
	},
	
		LoadActor("../Sprites/ParticlesDown/Static", "Symbol.png")..{
		OnCommand=function(self)
			self:effectclock('beat')
			
		end
	},
	
		LoadActor("../Sprites/ParticlesDown/Static", "Symbol.png")..{
		OnCommand=function(self)
			self:effectclock('beat')
			
		end
	},
	
		LoadActor("../Sprites/ParticlesDown/Static", "Symbol.png")..{
		OnCommand=function(self)
			self:effectclock('beat')
			
		end
	},
	
		LoadActor("../Sprites/ParticlesDown/Static", "Symbol.png")..{
		OnCommand=function(self)
			self:effectclock('beat')
			
		end
	},
	
		LoadActor("../Sprites/ParticlesDown/Static", "Symbol.png")..{
		OnCommand=function(self)
			self:effectclock('beat')
			
		end
	},
	
		LoadActor("../Sprites/ParticlesDown/Static", "Symbol.png")..{
		OnCommand=function(self)
			self:effectclock('beat')
			
		end
	},
	
		LoadActor("../Sprites/ParticlesDown/Static", "Symbol.png")..{
		OnCommand=function(self)
			self:effectclock('beat')
			
		end
	},
}
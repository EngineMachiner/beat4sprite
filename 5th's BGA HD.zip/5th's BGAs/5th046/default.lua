return Def.ActorFrame{
	LoseFocusCommand=function(self)
		self:RunCommandsOnChildren(function(child) child:visible(false):finishtweening() end, {})
	end,
	LoadActor("1 (stretch).png")..{
		OnCommand=cmd(Center;zoom,2;customtexturerect,0,0,2,2)
	};
		Def.Sprite{
		Texture = "2 1x2.png", 
		Frames = {{Delay= 0.5, Frame= 0}, {Delay= 0.5, Frame= 1}},
		OnCommand=cmd(x,320;y,60;hibernate,2;sleep,2;hibernate,2;effectclock,"beat";set_tween_uses_effect_delta,true)
	};
		Def.Sprite{
		Texture = "2 1x2.png", 
		Frames = {{Delay= 0.5, Frame= 0}, {Delay= 0.5, Frame= 1}},
		OnCommand=cmd(x,960;y,60;hibernate,2;sleep,2;hibernate,2;effectclock,"beat";set_tween_uses_effect_delta,true)
	};
		Def.Sprite{
		Texture = "2 1x2.png", 
		Frames = {{Delay= 0.5, Frame= 0}, {Delay= 0.5, Frame= 1}},
		OnCommand=cmd(x,320;y,180;hibernate,2;sleep,2;hibernate,2;effectclock,"beat";set_tween_uses_effect_delta,true)
	};
		Def.Sprite{
		Texture = "2 1x2.png", 
		Frames = {{Delay= 0.5, Frame= 0}, {Delay= 0.5, Frame= 1}},
		OnCommand=cmd(x,960;y,180;hibernate,2;sleep,2;hibernate,2;effectclock,"beat";set_tween_uses_effect_delta,true)
	};
		Def.Sprite{
		Texture = "2 1x2.png", 
		Frames = {{Delay= 0.5, Frame= 0}, {Delay= 0.5, Frame= 1}},
		OnCommand=cmd(x,320;y,300;hibernate,2;sleep,2;hibernate,2;effectclock,"beat";set_tween_uses_effect_delta,true)
	};
		Def.Sprite{
		Texture = "2 1x2.png", 
		Frames = {{Delay= 0.5, Frame= 0}, {Delay= 0.5, Frame= 1}},
		OnCommand=cmd(x,960;y,300;hibernate,2;sleep,2;hibernate,2;effectclock,"beat";set_tween_uses_effect_delta,true)
	};
		Def.Sprite{
		Texture = "2 1x2.png", 
		Frames = {{Delay= 0.5, Frame= 0}, {Delay= 0.5, Frame= 1}},
		OnCommand=cmd(x,320;y,420;hibernate,2;sleep,2;hibernate,2;effectclock,"beat";set_tween_uses_effect_delta,true)
	};
		Def.Sprite{
		Texture = "2 1x2.png", 
		Frames = {{Delay= 0.5, Frame= 0}, {Delay= 0.5, Frame= 1}},
		OnCommand=cmd(x,960;y,420;hibernate,2;sleep,2;hibernate,2;effectclock,"beat";set_tween_uses_effect_delta,true)
	};
		Def.Sprite{
		Texture = "2 1x2.png", 
		Frames = {{Delay= 0.5, Frame= 0}, {Delay= 0.5, Frame= 1}},
		OnCommand=cmd(x,320;y,540;hibernate,2;sleep,2;hibernate,2;effectclock,"beat";set_tween_uses_effect_delta,true)
	};
		Def.Sprite{
		Texture = "2 1x2.png", 
		Frames = {{Delay= 0.5, Frame= 0}, {Delay= 0.5, Frame= 1}},
		OnCommand=cmd(x,960;y,540;hibernate,2;sleep,2;hibernate,2;effectclock,"beat";set_tween_uses_effect_delta,true)
	};
	LoadActor("3 (stretch)")..{
		OnCommand=cmd(Center;zoom,5;texcoordvelocity,0,-0.1;customtexturerect,0,0,5,5;sleep,4;hibernate,4;set_use_effect_clock_for_texcoords,true;effectclock,'beat')
	};
		Def.Sprite{
		Texture = "1 5x1.png", 
		Frames = {{Delay= 0.25, Frame= 0}, {Delay= 0.25, Frame= 1}, {Delay= 0.25, Frame= 2}, {Delay= 0.25, Frame= 3}, {Delay= 0.25, Frame= 4}},
		OnCommand=function(self)
		self:x(64)
		:y(SCREEN_CENTER_Y)
		:effectoffset(0.2)
		:rotationy(0):linear(1):rotationy(90):linear(1):rotationy(0):queuecommand( "On" ):effectclock('beat')
		end
	};
		Def.Sprite{
		Texture = "2 5x1.png", 
		Frames = {{Delay= 0.25, Frame= 0}, {Delay= 0.25, Frame= 1}, {Delay= 0.25, Frame= 2}, {Delay= 0.25, Frame= 3}, {Delay= 0.25, Frame= 4}},
		OnCommand=function(self)
		self:x(64+128)
		:y(SCREEN_CENTER_Y)
		:effectoffset(0.4)
		:rotationy(0):linear(1):rotationy(90):linear(1):rotationy(0):queuecommand( "On" ):effectclock('beat')
		end
	};
		Def.Sprite{
		Texture = "3 5x1.png", 
		Frames = {{Delay= 0.25, Frame= 0}, {Delay= 0.25, Frame= 1}, {Delay= 0.25, Frame= 2}, {Delay= 0.25, Frame= 3}, {Delay= 0.25, Frame= 4}},
		OnCommand=function(self)
		self:x(64+256)
		:y(SCREEN_CENTER_Y)
		:effectoffset(0.6)
		:rotationy(0):linear(1):rotationy(90):linear(1):rotationy(0):queuecommand( "On" ):effectclock('beat')
		end
	};
		Def.Sprite{
		Texture = "4 5x1.png", 
		Frames = {{Delay= 0.25, Frame= 0}, {Delay= 0.25, Frame= 1}, {Delay= 0.25, Frame= 2}, {Delay= 0.25, Frame= 3}, {Delay= 0.25, Frame= 4}},
		OnCommand=function(self)
		self:x(64+384)
		:y(SCREEN_CENTER_Y)
		:effectoffset(0.8)
		:rotationy(0):linear(1):rotationy(90):linear(1):rotationy(0):queuecommand( "On" ):effectclock('beat')
		end
	};
		Def.Sprite{
		Texture = "5 5x1.png", 
		Frames = {{Delay= 0.25, Frame= 0}, {Delay= 0.25, Frame= 1}, {Delay= 0.25, Frame= 2}, {Delay= 0.25, Frame= 3}, {Delay= 0.25, Frame= 4}},
		OnCommand=function(self)
		self:x(64+512)
		:y(SCREEN_CENTER_Y)
		:rotationy(0):linear(1):rotationy(90):linear(1):rotationy(0):queuecommand( "On" ):effectclock('beat')
		end
	};
		Def.Sprite{
		Texture = "1 5x1.png", 
		Frames = {{Delay= 0.25, Frame= 0}, {Delay= 0.25, Frame= 1}, {Delay= 0.25, Frame= 2}, {Delay= 0.25, Frame= 3}, {Delay= 0.25, Frame= 4}},
		OnCommand=function(self)
		self:x(64+640)
		:y(SCREEN_CENTER_Y)
		:effectoffset(0.2)
		:rotationy(0):linear(1):rotationy(90):linear(1):rotationy(0):queuecommand( "On" ):effectclock('beat')
		end
	};
		Def.Sprite{
		Texture = "2 5x1.png", 
		Frames = {{Delay= 0.25, Frame= 0}, {Delay= 0.25, Frame= 1}, {Delay= 0.25, Frame= 2}, {Delay= 0.25, Frame= 3}, {Delay= 0.25, Frame= 4}},
		OnCommand=function(self)
		self:x(64+768)
		:y(SCREEN_CENTER_Y)
		:effectoffset(0.4)
		:rotationy(0):linear(1):rotationy(90):linear(1):rotationy(0):queuecommand( "On" ):effectclock('beat')
		end
	};
		Def.Sprite{
		Texture = "3 5x1.png", 
		Frames = {{Delay= 0.25, Frame= 0}, {Delay= 0.25, Frame= 1}, {Delay= 0.25, Frame= 2}, {Delay= 0.25, Frame= 3}, {Delay= 0.25, Frame= 4}},
		OnCommand=function(self)
		self:x(64+896)
		:y(SCREEN_CENTER_Y)
		:effectoffset(0.6)
		:rotationy(0):linear(1):rotationy(90):linear(1):rotationy(0):queuecommand( "On" ):effectclock('beat')
		end
	};
}
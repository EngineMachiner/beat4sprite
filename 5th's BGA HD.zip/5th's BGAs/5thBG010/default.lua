return Def.ActorFrame{
	LoseFocusCommand=function(self)
		self:RunCommandsOnChildren(function(child) child:visible(false):finishtweening() end, {})
	end,
	LoadActor(GAMESTATE:GetCurrentSong():GetBackgroundPath())..{
		OnCommand=cmd(Center;SetSize,640,480;diffusealpha,0.5)
	};
	LoadActor(GAMESTATE:GetCurrentSong():GetBackgroundPath())..{
		OnCommand=cmd(Center;SetSize,640,480;diffuseramp,effectcolor1,2,2,2,2,effectcolor2,1,1,1,1;effectclock,'beat';blend,"BlendMode_Add")
	};
	
	LoadActor(GAMESTATE:GetCurrentSong():GetBackgroundPath())..{
		OnCommand=cmd(Center;SetSize,640,480;addx,640;zoomx,-1;diffusealpha,0.5)
	};
	LoadActor(GAMESTATE:GetCurrentSong():GetBackgroundPath())..{
		OnCommand=cmd(Center;SetSize,640,480;addx,640;zoomx,-1;diffuseramp,effectcolor1,2,2,2,2,effectcolor2,1,1,1,1;effectclock,'beat';blend,"BlendMode_Add")
	};
	
	LoadActor(GAMESTATE:GetCurrentSong():GetBackgroundPath())..{
		OnCommand=cmd(Center;SetSize,640,480;addx,-640;zoomx,-1;diffusealpha,0.5)
	};
	LoadActor(GAMESTATE:GetCurrentSong():GetBackgroundPath())..{
		OnCommand=cmd(Center;SetSize,640,480;addx,-640;zoomx,-1;diffuseramp,effectcolor1,2,2,2,2,effectcolor2,1,1,1,1;effectclock,'beat';blend,"BlendMode_Add")
	};
	LoadActor("A.lua")..{
		OnCommand=cmd()
	};
}
local t = Def.ActorFrame{
	LoadActor("A.lua")..{
		OnCommand=cmd(x,0;y,0;effectclock,"beat")
	};
	LoadActor("A.lua")..{
		OnCommand=cmd(x,159.25*2;y,0;effectclock,"beat")
	};
	LoadActor("A.lua")..{
		OnCommand=cmd(x,159*4;y,0;effectclock,"beat")
	};
	LoadActor("_particleLoader1.lua")..{
		OnCommand=cmd()
	};
	LoadActor("_particleLoader1 - copia.lua")..{
		OnCommand=cmd(rotationy,180;x,640;y,0)
	};
	LoadActor("_particleLoader2.lua")..{
		OnCommand=cmd(rotationx,180;x,0;y,480)
	};
	LoadActor("_particleLoader2 - copia.lua")..{
		OnCommand=cmd(rotationy,-180;rotationx,180;x,640;y,480)
	};
	
	LoadActor("_particleLoader1 - copia (2).lua")..{
		OnCommand=cmd()
	};
	LoadActor("_particleLoader1 - copia - copia.lua")..{
		OnCommand=cmd(rotationy,180;x,640;y,0)
	};
	LoadActor("_particleLoader2 - copia (2).lua")..{
		OnCommand=cmd(rotationx,180;x,0;y,480)
	};
	LoadActor("_particleLoader2 - copia - copia.lua")..{
		OnCommand=cmd(rotationy,-180;rotationx,180;x,640;y,480)
	};
};

return t;
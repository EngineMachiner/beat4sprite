local t = Def.ActorFrame{
		Def.Sprite{
		Texture = "1 2x1.png", 
		Frames = {{Delay= 0.5, Frame= 0}, {Delay= 0.5, Frame= 1}},
		OnCommand=cmd(x,77;y,60;effectclock,"beat")
	};
		Def.Sprite{
		Texture = "1 2x1.png", 
		Frames = {{Delay= 0.5, Frame= 0}, {Delay= 0.5, Frame= 1}},
		OnCommand=cmd(x,236;y,60;effectclock,"beat")
	};
		Def.Sprite{
		Texture = "1 2x1.png", 
		Frames = {{Delay= 0.5, Frame= 0}, {Delay= 0.5, Frame= 1}},
		OnCommand=cmd(x,77;y,180;effectclock,"beat")
	};
		Def.Sprite{
		Texture = "1 2x1.png", 
		Frames = {{Delay= 0.5, Frame= 0}, {Delay= 0.5, Frame= 1}},
		OnCommand=cmd(x,236;y,180;effectclock,"beat")
	};
		Def.Sprite{
		Texture = "1 2x1.png", 
		Frames = {{Delay= 0.5, Frame= 0}, {Delay= 0.5, Frame= 1}},
		OnCommand=cmd(x,77;y,300;effectclock,"beat")
	};
		Def.Sprite{
		Texture = "1 2x1.png", 
		Frames = {{Delay= 0.5, Frame= 0}, {Delay= 0.5, Frame= 1}},
		OnCommand=cmd(x,236;y,300;effectclock,"beat")
	};
		Def.Sprite{
		Texture = "1 2x1.png", 
		Frames = {{Delay= 0.5, Frame= 0}, {Delay= 0.5, Frame= 1}},
		OnCommand=cmd(x,77;y,420;effectclock,"beat")
	};
		Def.Sprite{
		Texture = "1 2x1.png", 
		Frames = {{Delay= 0.5, Frame= 0}, {Delay= 0.5, Frame= 1}},
		OnCommand=cmd(x,236;y,420;effectclock,"beat")
	};
};

return t;
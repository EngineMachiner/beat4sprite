local WDX2 if SCREEN_WIDTH > 640 then WDX2 = -160/1.75 else WDX2 = 0 end;
local t = Def.ActorFrame{
		Def.Sprite{
		Texture = "2 2x1.png", 
		Frames = {{Delay= 1, Frame= 0}, {Delay= 1, Frame= 1}},
		OnCommand=cmd(x,160;y,60;addx,WDX2;effectclock,"beat")
	};
		Def.Sprite{
		Texture = "2 2x1.png", 
		Frames = {{Delay= 1, Frame= 0}, {Delay= 1, Frame= 1}},
		OnCommand=cmd(x,480;y,60;addx,WDX2;effectclock,"beat")
	};
		Def.Sprite{
		Texture = "2 2x1.png", 
		Frames = {{Delay= 1, Frame= 0}, {Delay= 1, Frame= 1}},
		OnCommand=cmd(x,800;y,60;addx,WDX2;effectclock,"beat")
	};
		Def.Sprite{
		Texture = "2 2x1.png", 
		Frames = {{Delay= 1, Frame= 0}, {Delay= 1, Frame= 1}},
		OnCommand=cmd(x,160;y,180;addx,WDX2;effectclock,"beat")
	};
		Def.Sprite{
		Texture = "2 2x1.png", 
		Frames = {{Delay= 1, Frame= 0}, {Delay= 1, Frame= 1}},
		OnCommand=cmd(x,480;y,180;addx,WDX2;effectclock,"beat")
	};
		Def.Sprite{
		Texture = "2 2x1.png", 
		Frames = {{Delay= 1, Frame= 0}, {Delay= 1, Frame= 1}},
		OnCommand=cmd(x,800;y,180;addx,WDX2;effectclock,"beat")
	};
		Def.Sprite{
		Texture = "2 2x1.png", 
		Frames = {{Delay= 1, Frame= 0}, {Delay= 1, Frame= 1}},
		OnCommand=cmd(x,160;y,300;addx,WDX2;effectclock,"beat")
	};
		Def.Sprite{
		Texture = "2 2x1.png", 
		Frames = {{Delay= 1, Frame= 0}, {Delay= 1, Frame= 1}},
		OnCommand=cmd(x,480;y,300;addx,WDX2;effectclock,"beat")
	};
		Def.Sprite{
		Texture = "2 2x1.png", 
		Frames = {{Delay= 1, Frame= 0}, {Delay= 1, Frame= 1}},
		OnCommand=cmd(x,800;y,300;addx,WDX2;effectclock,"beat")
	};
		Def.Sprite{
		Texture = "2 2x1.png", 
		Frames = {{Delay= 1, Frame= 0}, {Delay= 1, Frame= 1}},
		OnCommand=cmd(x,160;y,420;addx,WDX2;effectclock,"beat")
	};
		Def.Sprite{
		Texture = "2 2x1.png", 
		Frames = {{Delay= 1, Frame= 0}, {Delay= 1, Frame= 1}},
		OnCommand=cmd(x,480;y,420;addx,WDX2;effectclock,"beat")
	};
		Def.Sprite{
		Texture = "2 2x1.png", 
		Frames = {{Delay= 1, Frame= 0}, {Delay= 1, Frame= 1}},
		OnCommand=cmd(x,800;y,420;addx,WDX2;effectclock,"beat")
	};
		Def.Sprite{
		Texture = "2 2x1.png", 
		Frames = {{Delay= 1, Frame= 0}, {Delay= 1, Frame= 1}},
		OnCommand=cmd(x,160;y,540;addx,WDX2;effectclock,"beat")
	};
		Def.Sprite{
		Texture = "2 2x1.png", 
		Frames = {{Delay= 1, Frame= 0}, {Delay= 1, Frame= 1}},
		OnCommand=cmd(x,480;y,540;addx,WDX2;effectclock,"beat")
	};
		Def.Sprite{
		Texture = "2 2x1.png", 
		Frames = {{Delay= 1, Frame= 0}, {Delay= 1, Frame= 1}},
		OnCommand=cmd(x,800;y,540;addx,WDX2;effectclock,"beat")
	};
};

return t;
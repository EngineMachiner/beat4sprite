local WDX2 if SCREEN_WIDTH > 640 then WDX2 = -80/1.5 else WDX2 = 0 end;
return Def.ActorFrame{
	LoseFocusCommand=function(self)
		self:RunCommandsOnChildren(function(child) child:visible(false):finishtweening() end, {})
	end,
	LoadActor("1 (stretch)")..{
		OnCommand=cmd(Center;addx,75;zoom,11;customtexturerect,0,0,11,11)
	};
	LoadActor("2")..{
		OnCommand=function(self)
		self:x(80)
			:y(60)
			:addx(WDX2)
			:rotationy(0):linear(1):rotationy(90):linear(1):rotationy(0):queuecommand( "On" ):effectclock('beat')
			end
	};
	LoadActor("2")..{
		OnCommand=function(self)
		self:x(240)
			:y(60)
			:addx(WDX2)
			:rotationy(0):linear(1):rotationy(90):linear(1):rotationy(0):queuecommand( "On" ):effectclock('beat')
			end	};
	LoadActor("2")..{
		OnCommand=function(self)
		self:x(400)
			:y(60)
			:addx(WDX2)
			:rotationy(0):linear(1):rotationy(90):linear(1):rotationy(0):queuecommand( "On" ):effectclock('beat')
			end	};
	LoadActor("2")..{
		OnCommand=function(self)
		self:x(560)
			:y(60)
			:addx(WDX2)
			:rotationy(0):linear(1):rotationy(90):linear(1):rotationy(0):queuecommand( "On" ):effectclock('beat')
			end	};
	LoadActor("2")..{
		OnCommand=function(self)
		self:x(720)
			:y(60)
			:addx(WDX2)
			:rotationy(0):linear(1):rotationy(90):linear(1):rotationy(0):queuecommand( "On" ):effectclock('beat')
			end	};
	LoadActor("2")..{
		OnCommand=function(self)
		self:x(880)
			:y(60)
			:addx(WDX2)
			:rotationy(0):linear(1):rotationy(90):linear(1):rotationy(0):queuecommand( "On" ):effectclock('beat')
			end	};

	LoadActor("2")..{
		OnCommand=function(self)
		self:x(80)
			:y(180)
			:addx(WDX2)
			:rotationy(0):linear(1):rotationy(90):linear(1):rotationy(0):queuecommand( "On" ):effectclock('beat')
			end	};
	LoadActor("2")..{
		OnCommand=function(self)
		self:x(240)
			:y(180)
			:addx(WDX2)
			:rotationy(0):linear(1):rotationy(90):linear(1):rotationy(0):queuecommand( "On" ):effectclock('beat')
			end	};
	LoadActor("2")..{
		OnCommand=function(self)
		self:x(400)
			:y(180)
			:addx(WDX2)
			:rotationy(0):linear(1):rotationy(90):linear(1):rotationy(0):queuecommand( "On" ):effectclock('beat')
			end	};
	LoadActor("2")..{
		OnCommand=function(self)
		self:x(560)
			:y(180)
			:addx(WDX2)
			:rotationy(0):linear(1):rotationy(90):linear(1):rotationy(0):queuecommand( "On" ):effectclock('beat')
			end	};
	LoadActor("2")..{
		OnCommand=function(self)
		self:x(720)
			:y(180)
			:addx(WDX2)
			:rotationy(0):linear(1):rotationy(90):linear(1):rotationy(0):queuecommand( "On" ):effectclock('beat')
			end	};
	LoadActor("2")..{
		OnCommand=function(self)
		self:x(880)
			:y(180)
			:addx(WDX2)
			:rotationy(0):linear(1):rotationy(90):linear(1):rotationy(0):queuecommand( "On" ):effectclock('beat')
			end	};
	LoadActor("2")..{
		OnCommand=function(self)
		self:x(80)
			:y(300)
			:addx(WDX2)
			:rotationy(0):linear(1):rotationy(90):linear(1):rotationy(0):queuecommand( "On" ):effectclock('beat')
			end	};
	LoadActor("2")..{
		OnCommand=function(self)
		self:x(240)
			:y(300)
			:addx(WDX2)
			:rotationy(0):linear(1):rotationy(90):linear(1):rotationy(0):queuecommand( "On" ):effectclock('beat')
			end	};
	LoadActor("2")..{
		OnCommand=function(self)
		self:x(400)
			:y(300)
			:addx(WDX2)
			:rotationy(0):linear(1):rotationy(90):linear(1):rotationy(0):queuecommand( "On" ):effectclock('beat')
			end	};
	LoadActor("2")..{
		OnCommand=function(self)
		self:x(560)
			:y(300)
			:addx(WDX2)
			:rotationy(0):linear(1):rotationy(90):linear(1):rotationy(0):queuecommand( "On" ):effectclock('beat')
			end	};
	LoadActor("2")..{
		OnCommand=function(self)
		self:x(720)
			:y(300)
			:addx(WDX2)
			:rotationy(0):linear(1):rotationy(90):linear(1):rotationy(0):queuecommand( "On" ):effectclock('beat')
			end	};
	LoadActor("2")..{
		OnCommand=function(self)
		self:x(880)
			:y(300)
			:addx(WDX2)
			:rotationy(0):linear(1):rotationy(90):linear(1):rotationy(0):queuecommand( "On" ):effectclock('beat')
			end	};
	LoadActor("2")..{
		OnCommand=function(self)
		self:x(80)
			:y(420)
			:addx(WDX2)
			:rotationy(0):linear(1):rotationy(90):linear(1):rotationy(0):queuecommand( "On" ):effectclock('beat')
			end	};
	LoadActor("2")..{
		OnCommand=function(self)
		self:x(240)
			:y(420)
			:addx(WDX2)
			:rotationy(0):linear(1):rotationy(90):linear(1):rotationy(0):queuecommand( "On" ):effectclock('beat')
			end	};
	LoadActor("2")..{
		OnCommand=function(self)
		self:x(400)
			:y(420)
			:addx(WDX2)
			:rotationy(0):linear(1):rotationy(90):linear(1):rotationy(0):queuecommand( "On" ):effectclock('beat')
			end	};
	LoadActor("2")..{
		OnCommand=function(self)
		self:x(560)
			:y(420)
			:addx(WDX2)
			:rotationy(0):linear(1):rotationy(90):linear(1):rotationy(0):queuecommand( "On" ):effectclock('beat')
			end	};
	LoadActor("2")..{
		OnCommand=function(self)
		self:x(720)
			:y(420)
			:addx(WDX2)
			:rotationy(0):linear(1):rotationy(90):linear(1):rotationy(0):queuecommand( "On" ):effectclock('beat')
			end	};
	LoadActor("2")..{
		OnCommand=function(self)
		self:x(880)
			:y(420)
			:addx(WDX2)
			:rotationy(0):linear(1):rotationy(90):linear(1):rotationy(0):queuecommand( "On" ):effectclock('beat')
			end	};
}
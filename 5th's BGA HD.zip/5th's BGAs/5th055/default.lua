local WDX3 if SCREEN_WIDTH > 640 then WDX3 = SCREEN_WIDTH/8.5 else WDX3 = 9 end;
local WDX2 if SCREEN_WIDTH > 640 then WDX2 = -70/1.5 else WDX2 = 0 end;
return Def.ActorFrame{
	LoseFocusCommand=function(self)
		self:RunCommandsOnChildren(function(child) child:visible(false):finishtweening() end, {})
	end,
		Def.Sprite{
		Texture = "1 2x1.png", 
		Frames = {{Delay= 0.5, Frame= 0}, {Delay= 0.5, Frame= 1}},
		OnCommand=cmd(x,80;y,60;addx,WDX2;effectclock,'beat')
	};
		Def.Sprite{
		Texture = "1 2x1.png", 
		Frames = {{Delay= 0.5, Frame= 0}, {Delay= 0.5, Frame= 1}},
		OnCommand=cmd(x,240;y,60;addx,WDX2;effectclock,'beat')
	};
		Def.Sprite{
		Texture = "1 2x1.png", 
		Frames = {{Delay= 0.5, Frame= 0}, {Delay= 0.5, Frame= 1}},
		OnCommand=cmd(x,400;y,60;addx,WDX2;effectclock,'beat')
	};
		Def.Sprite{
		Texture = "1 2x1.png", 
		Frames = {{Delay= 0.5, Frame= 0}, {Delay= 0.5, Frame= 1}},
		OnCommand=cmd(x,560;y,60;addx,WDX2;effectclock,'beat')
	};
		Def.Sprite{
		Texture = "1 2x1.png", 
		Frames = {{Delay= 0.5, Frame= 0}, {Delay= 0.5, Frame= 1}},
		OnCommand=cmd(x,720;y,60;addx,WDX2;effectclock,'beat')
	};
		Def.Sprite{
		Texture = "1 2x1.png", 
		Frames = {{Delay= 0.5, Frame= 0}, {Delay= 0.5, Frame= 1}},
		OnCommand=cmd(x,880;y,60;addx,WDX2;effectclock,'beat')
	};
		Def.Sprite{
		Texture = "1 2x1.png", 
		Frames = {{Delay= 0.5, Frame= 0}, {Delay= 0.5, Frame= 1}},
		OnCommand=cmd(x,80;y,180;addx,WDX2;effectclock,'beat')
	};
		Def.Sprite{
		Texture = "1 2x1.png", 
		Frames = {{Delay= 0.5, Frame= 0}, {Delay= 0.5, Frame= 1}},
		OnCommand=cmd(x,240;y,180;addx,WDX2;effectclock,'beat')
	};
		Def.Sprite{
		Texture = "1 2x1.png", 
		Frames = {{Delay= 0.5, Frame= 0}, {Delay= 0.5, Frame= 1}},
		OnCommand=cmd(x,400;y,180;addx,WDX2;effectclock,'beat')
	};
		Def.Sprite{
		Texture = "1 2x1.png", 
		Frames = {{Delay= 0.5, Frame= 0}, {Delay= 0.5, Frame= 1}},
		OnCommand=cmd(x,560;y,180;addx,WDX2;effectclock,'beat')
	};
		Def.Sprite{
		Texture = "1 2x1.png", 
		Frames = {{Delay= 0.5, Frame= 0}, {Delay= 0.5, Frame= 1}},
		OnCommand=cmd(x,720;y,180;addx,WDX2;effectclock,'beat')
	};
		Def.Sprite{
		Texture = "1 2x1.png", 
		Frames = {{Delay= 0.5, Frame= 0}, {Delay= 0.5, Frame= 1}},
		OnCommand=cmd(x,880;y,180;addx,WDX2;effectclock,'beat')
	};
		Def.Sprite{
		Texture = "1 2x1.png", 
		Frames = {{Delay= 0.5, Frame= 0}, {Delay= 0.5, Frame= 1}},
		OnCommand=cmd(x,80;y,300;addx,WDX2;effectclock,'beat')
	};
		Def.Sprite{
		Texture = "1 2x1.png", 
		Frames = {{Delay= 0.5, Frame= 0}, {Delay= 0.5, Frame= 1}},
		OnCommand=cmd(x,240;y,300;addx,WDX2;effectclock,'beat')
	};
		Def.Sprite{
		Texture = "1 2x1.png", 
		Frames = {{Delay= 0.5, Frame= 0}, {Delay= 0.5, Frame= 1}},
		OnCommand=cmd(x,400;y,300;addx,WDX2;effectclock,'beat')
	};
		Def.Sprite{
		Texture = "1 2x1.png", 
		Frames = {{Delay= 0.5, Frame= 0}, {Delay= 0.5, Frame= 1}},
		OnCommand=cmd(x,560;y,300;addx,WDX2;effectclock,'beat')
	};
		Def.Sprite{
		Texture = "1 2x1.png", 
		Frames = {{Delay= 0.5, Frame= 0}, {Delay= 0.5, Frame= 1}},
		OnCommand=cmd(x,720;y,300;addx,WDX2;effectclock,'beat')
	};
		Def.Sprite{
		Texture = "1 2x1.png", 
		Frames = {{Delay= 0.5, Frame= 0}, {Delay= 0.5, Frame= 1}},
		OnCommand=cmd(x,880;y,300;addx,WDX2;effectclock,'beat')
	};
		Def.Sprite{
		Texture = "1 2x1.png", 
		Frames = {{Delay= 0.5, Frame= 0}, {Delay= 0.5, Frame= 1}},
		OnCommand=cmd(x,80;y,420;addx,WDX2;effectclock,'beat')
	};
		Def.Sprite{
		Texture = "1 2x1.png", 
		Frames = {{Delay= 0.5, Frame= 0}, {Delay= 0.5, Frame= 1}},
		OnCommand=cmd(x,240;y,420;addx,WDX2;effectclock,'beat')
	};
		Def.Sprite{
		Texture = "1 2x1.png", 
		Frames = {{Delay= 0.5, Frame= 0}, {Delay= 0.5, Frame= 1}},
		OnCommand=cmd(x,400;y,420;addx,WDX2;effectclock,'beat')
	};
		Def.Sprite{
		Texture = "1 2x1.png", 
		Frames = {{Delay= 0.5, Frame= 0}, {Delay= 0.5, Frame= 1}},
		OnCommand=cmd(x,560;y,420;addx,WDX2;effectclock,'beat')
	};
		Def.Sprite{
		Texture = "1 2x1.png", 
		Frames = {{Delay= 0.5, Frame= 0}, {Delay= 0.5, Frame= 1}},
		OnCommand=cmd(x,720;y,420;addx,WDX2;effectclock,'beat')
	};
		Def.Sprite{
		Texture = "1 2x1.png", 
		Frames = {{Delay= 0.5, Frame= 0}, {Delay= 0.5, Frame= 1}},
		OnCommand=cmd(x,880;y,420;addx,WDX2;effectclock,'beat')
	};
		LoadActor("../Sprites/SpiralSpriteZoomIn", "Leave.png")..{
		OnCommand=function(self)
			self:effectclock('beat')
			:addx(WDX3)
		end
	},z
}
local t = Def.ActorFrame{
	LoadActor("1 (stretch).png")..{
		OnCommand=cmd(Center;zoom,10;set_use_effect_clock_for_texcoords,true;texcoordvelocity,0.095,0.095;customtexturerect,0,0,10,10;rainbow;effectperiod,8;effectclock,'beat')
	};
	
		LoadActor("A.lua")..{
		OnCommand=function(self) 
			self:effectclock('beat')
		end

	},
};

return t;
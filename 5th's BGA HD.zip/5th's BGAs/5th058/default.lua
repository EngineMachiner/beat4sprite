
return Def.ActorFrame{
	LoseFocusCommand=function(self)
		self:RunCommandsOnChildren(function(child) child:visible(false):finishtweening() end, {})
	end,
	LoadActor("1")..{
		OnCommand=cmd(x,160;y,120)
	};
	LoadActor("1")..{
		OnCommand=cmd(x,480;y,120)
	};
	LoadActor("1")..{
		OnCommand=cmd(x,800;y,120)
	};
	LoadActor("1")..{
		OnCommand=cmd(x,1120;y,120)
	};
	LoadActor("1")..{
		OnCommand=cmd(x,160;y,360)
	};
	LoadActor("1")..{
		OnCommand=cmd(x,480;y,360)
	};
	LoadActor("1")..{
		OnCommand=cmd(x,800;y,360)
	};
	LoadActor("1")..{
		OnCommand=cmd(x,1120;y,360)
	};
	LoadActor("1")..{
		OnCommand=cmd(x,160;y,600)
	};
	LoadActor("1")..{
		OnCommand=cmd(x,480;y,600)
	};
	LoadActor("1")..{
		OnCommand=cmd(x,800;y,600)
	};
	LoadActor("1")..{
		OnCommand=cmd(x,1120;y,600)
	};
		LoadActor("../Sprites/Line/006", "Leave.png")..{
		OnCommand=function(self)
			self:effectclock('beat')
		end
	},
}
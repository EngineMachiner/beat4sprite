return Def.ActorFrame{
    LoseFocusCommand=function(self)
        self:RunCommandsOnChildren(function(child) child:visible(false):finishtweening() end, {})
    end,
 
    LoadActor("Mask.png")..{
        OnCommand=function(self)
        self:Center()
            :SetSize(640,480)
            :zwrite(true)
            :blend('BlendMode_NoEffect')
        end
    };
 
    LoadActor(GAMESTATE:GetCurrentSong():GetBackgroundPath())..{
        OnCommand=function(self)
        self:Center()
            :SetSize(640,480)
			:rotationz(90)
			:texcoordvelocity(0.0625/2,0):effectclock('beat'):set_use_effect_clock_for_texcoords(true)
			:cropleft(0.5)
            :ztest(true)
        end
    };
	
     LoadActor(GAMESTATE:GetCurrentSong():GetBackgroundPath())..{
        OnCommand=function(self)
        self:Center()
			:SetSize(640,480)
			:rotationz(90)
			:rotationx(180)
			:texcoordvelocity(0.0625/2,0):effectclock('beat'):set_use_effect_clock_for_texcoords(true)
			:cropleft(0.5)
            :ztest(true)
        end
    };
}
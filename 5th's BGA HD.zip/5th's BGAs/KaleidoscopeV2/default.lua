return Def.ActorFrame{
    LoseFocusCommand=function(self)
        self:RunCommandsOnChildren(function(child) child:visible(false):finishtweening() end, {})
    end,
	    LoadActor(GAMESTATE:GetCurrentSong():GetBackgroundPath())..{
        OnCommand=function(self)
        self:Center()
            :SetSize(640,480)
        end
    };

    LoadActor("3.lua")..{
        OnCommand=function(self)
        self:x()
        end
    };
	    LoadActor(GAMESTATE:GetCurrentSong():GetBackgroundPath())..{
        OnCommand=function(self)
        self:Center()
            :SetSize(640,480)
			:zoomx(-1)
			:addx(640)
        end
    };
	    LoadActor(GAMESTATE:GetCurrentSong():GetBackgroundPath())..{
        OnCommand=function(self)
        self:Center()
            :SetSize(640,480)
			:zoomx(-1)
			:addx(-640)
        end
    };
}
local t = Def.ActorFrame{
	LoadActor(GAMESTATE:GetCurrentSong():GetBackgroundPath())..{
		OnCommand=cmd(Center;SetSize,640,480;rainbow;effectperiod,8;effectclock,'beat';effectoffset,0.5;diffusealpha,0.25)
	};
		LoadActor(GAMESTATE:GetCurrentSong():GetBackgroundPath())..{
		OnCommand=cmd(Center;SetSize,640,480;rainbow;effectperiod,8;effectclock,'beat';effectoffset,0.5;blend,"BlendMode_Add";diffusealpha,0.25)
	};

	LoadActor(GAMESTATE:GetCurrentSong():GetBackgroundPath())..{
		OnCommand=cmd(Center;SetSize,640,480;rainbow;effectperiod,8;effectclock,'beat';effectoffset,0.5;diffusealpha,0.5;addx,630;zoomx,-1)
	};
	LoadActor(GAMESTATE:GetCurrentSong():GetBackgroundPath())..{
		OnCommand=cmd(Center;SetSize,640,480;rainbow;effectperiod,8;effectclock,'beat';effectoffset,0.5;diffusealpha,0.5;addx,-630;zoomx,-1)
	};
};

return t;
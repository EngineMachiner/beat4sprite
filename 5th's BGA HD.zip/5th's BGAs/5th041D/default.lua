local t = Def.ActorFrame{
	LoadActor("1 (stretch)")..{
		OnCommand=function(self)
			self:Center()
			:customtexturerect(0,0,1,1)
			:set_use_effect_clock_for_texcoords(true)
			:texcoordvelocity(-0.075/1.5,0):effectclock('beat')
		end
	},
};

return t;
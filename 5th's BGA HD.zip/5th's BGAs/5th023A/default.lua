return Def.ActorFrame{

	LoseFocusCommand=function(self)
		self:RunCommandsOnChildren(function(child) child:visible(false):finishtweening() end, {})
	end,
	LoadActor("1 (stretch)")..{
		OnCommand=cmd(x,80;y,60;texcoordvelocity,0,0.5;customtexturerect,0,0,1,1;diffuseramp,effectcolor1,1,1,1,1,effectcolor2,0,0,0,0;effectclock,'beat')
	};
	LoadActor("1 (stretch)")..{
		OnCommand=cmd(x,240;y,60;texcoordvelocity,0,0.5;customtexturerect,0,0,1,1;diffuseramp,effectcolor1,1,1,1,1,effectcolor2,0,0,0,0;effectclock,'beat')
	};
	LoadActor("1 (stretch)")..{
		OnCommand=cmd(x,400;y,60;texcoordvelocity,0,0.5;customtexturerect,0,0,1,1;diffuseramp,effectcolor1,1,1,1,1,effectcolor2,0,0,0,0;effectclock,'beat')
	};
	LoadActor("1 (stretch)")..{
		OnCommand=cmd(x,560;y,60;texcoordvelocity,0,0.5;customtexturerect,0,0,1,1;diffuseramp,effectcolor1,1,1,1,1,effectcolor2,0,0,0,0;effectclock,'beat')
	};
	LoadActor("1 (stretch)")..{
		OnCommand=cmd(x,80;y,180;texcoordvelocity,0,0.5;customtexturerect,0,0,1,1;diffuseramp,effectcolor1,1,1,1,1,effectcolor2,0,0,0,0;effectclock,'beat')
	};
	LoadActor("1 (stretch)")..{
		OnCommand=cmd(x,240;y,180;texcoordvelocity,0,0.5;customtexturerect,0,0,1,1;diffuseramp,effectcolor1,1,1,1,1,effectcolor2,0,0,0,0;effectclock,'beat')
	};
	LoadActor("1 (stretch)")..{
		OnCommand=cmd(x,400;y,180;texcoordvelocity,0,0.5;customtexturerect,0,0,1,1;diffuseramp,effectcolor1,1,1,1,1,effectcolor2,0,0,0,0;effectclock,'beat')
	};
	LoadActor("1 (stretch)")..{
		OnCommand=cmd(x,560;y,180;texcoordvelocity,0,0.5;customtexturerect,0,0,1,1;diffuseramp,effectcolor1,1,1,1,1,effectcolor2,0,0,0,0;effectclock,'beat')
	};
	LoadActor("1 (stretch)")..{
		OnCommand=cmd(x,80;y,300;texcoordvelocity,0,0.5;customtexturerect,0,0,1,1;diffuseramp,effectcolor1,1,1,1,1,effectcolor2,0,0,0,0;effectclock,'beat')
	};
	LoadActor("1 (stretch)")..{
		OnCommand=cmd(x,240;y,300;texcoordvelocity,0,0.5;customtexturerect,0,0,1,1;diffuseramp,effectcolor1,1,1,1,1,effectcolor2,0,0,0,0;effectclock,'beat')
	};
	LoadActor("1 (stretch)")..{
		OnCommand=cmd(x,400;y,300;texcoordvelocity,0,0.5;customtexturerect,0,0,1,1;diffuseramp,effectcolor1,1,1,1,1,effectcolor2,0,0,0,0;effectclock,'beat')
	};
	LoadActor("1 (stretch)")..{
		OnCommand=cmd(x,560;y,300;texcoordvelocity,0,0.5;customtexturerect,0,0,1,1;diffuseramp,effectcolor1,1,1,1,1,effectcolor2,0,0,0,0;effectclock,'beat')
	};
	LoadActor("1 (stretch)")..{
		OnCommand=cmd(x,80;y,420;texcoordvelocity,0,0.5;customtexturerect,0,0,1,1;diffuseramp,effectcolor1,1,1,1,1,effectcolor2,0,0,0,0;effectclock,'beat')
	};
	LoadActor("1 (stretch)")..{
		OnCommand=cmd(x,240;y,420;texcoordvelocity,0,0.5;customtexturerect,0,0,1,1;diffuseramp,effectcolor1,1,1,1,1,effectcolor2,0,0,0,0;effectclock,'beat')
	};
	LoadActor("1 (stretch)")..{
		OnCommand=cmd(x,400;y,420;texcoordvelocity,0,0.5;customtexturerect,0,0,1,1;diffuseramp,effectcolor1,1,1,1,1,effectcolor2,0,0,0,0;effectclock,'beat')
	};
	LoadActor("1 (stretch)")..{
		OnCommand=cmd(x,560;y,420;texcoordvelocity,0,0.5;customtexturerect,0,0,1,1;diffuseramp,effectcolor1,1,1,1,1,effectcolor2,0,0,0,0;effectclock,'beat')
	};
	LoadActor("1 (stretch)")..{
		OnCommand=cmd(x,720;y,60;texcoordvelocity,0,0.5;customtexturerect,0,0,1,1;diffuseramp,effectcolor1,1,1,1,1,effectcolor2,0,0,0,0;effectclock,'beat')
	};
	LoadActor("1 (stretch)")..{
		OnCommand=cmd(x,880;y,60;texcoordvelocity,0,0.5;customtexturerect,0,0,1,1;diffuseramp,effectcolor1,1,1,1,1,effectcolor2,0,0,0,0;effectclock,'beat')
	};
	LoadActor("1 (stretch)")..{
		OnCommand=cmd(x,720;y,180;texcoordvelocity,0,0.5;customtexturerect,0,0,1,1;diffuseramp,effectcolor1,1,1,1,1,effectcolor2,0,0,0,0;effectclock,'beat')
	};
	LoadActor("1 (stretch)")..{
		OnCommand=cmd(x,880;y,180;texcoordvelocity,0,0.5;customtexturerect,0,0,1,1;diffuseramp,effectcolor1,1,1,1,1,effectcolor2,0,0,0,0;effectclock,'beat')
	};
	LoadActor("1 (stretch)")..{
		OnCommand=cmd(x,720;y,300;texcoordvelocity,0,0.5;customtexturerect,0,0,1,1;diffuseramp,effectcolor1,1,1,1,1,effectcolor2,0,0,0,0;effectclock,'beat')
	};
	LoadActor("1 (stretch)")..{
		OnCommand=cmd(x,880;y,300;texcoordvelocity,0,0.5;customtexturerect,0,0,1,1;diffuseramp,effectcolor1,1,1,1,1,effectcolor2,0,0,0,0;effectclock,'beat')
	};
	LoadActor("1 (stretch)")..{
		OnCommand=cmd(x,720;y,420;texcoordvelocity,0,0.5;customtexturerect,0,0,1,1;diffuseramp,effectcolor1,1,1,1,1,effectcolor2,0,0,0,0;effectclock,'beat')
	};
	LoadActor("1 (stretch)")..{
		OnCommand=cmd(x,880;y,420;texcoordvelocity,0,0.5;customtexturerect,0,0,1,1;diffuseramp,effectcolor1,1,1,1,1,effectcolor2,0,0,0,0;effectclock,'beat')
	};
	LoadActor("A.lua")..{
		OnCommand=cmd()
	};
}
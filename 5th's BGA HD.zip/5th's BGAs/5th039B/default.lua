return Def.ActorFrame{
	LoseFocusCommand=function(self)
		self:RunCommandsOnChildren(function(child) child:visible(false):finishtweening() end, {})
	end,
	
	LoadActor("1 (stretch).png")..{
		OnCommand=cmd(x,80;y,80;texcoordvelocity,0,0.25+(0.25/2);set_use_effect_clock_for_texcoords,true;effectclock,'beat')
	};
	LoadActor("1 (stretch).png")..{
		OnCommand=cmd(x,240;y,80;texcoordvelocity,0,0.25+(0.25/2);set_use_effect_clock_for_texcoords,true;effectclock,'beat')
	};
	LoadActor("1 (stretch).png")..{
		OnCommand=cmd(x,400;y,80;texcoordvelocity,0,0.25+(0.25/2);set_use_effect_clock_for_texcoords,true;effectclock,'beat')
	};
	LoadActor("1 (stretch).png")..{
		OnCommand=cmd(x,560;y,80;texcoordvelocity,0,0.25+(0.25/2);set_use_effect_clock_for_texcoords,true;effectclock,'beat')
	};
	LoadActor("1 (stretch).png")..{
		OnCommand=cmd(x,720;y,80;texcoordvelocity,0,0.25+(0.25/2);set_use_effect_clock_for_texcoords,true;effectclock,'beat')
	};
	LoadActor("1 (stretch).png")..{
		OnCommand=cmd(x,880;y,80;texcoordvelocity,0,0.25+(0.25/2);set_use_effect_clock_for_texcoords,true;effectclock,'beat')
	};
	LoadActor("1 (stretch).png")..{
		OnCommand=cmd(x,80;y,240;texcoordvelocity,0,0.25+(0.25/2);set_use_effect_clock_for_texcoords,true;effectclock,'beat')
	};
	LoadActor("1 (stretch).png")..{
		OnCommand=cmd(x,240;y,240;texcoordvelocity,0,0.25+(0.25/2);set_use_effect_clock_for_texcoords,true;effectclock,'beat')
	};
	LoadActor("1 (stretch).png")..{
		OnCommand=cmd(x,400;y,240;texcoordvelocity,0,0.25+(0.25/2);set_use_effect_clock_for_texcoords,true;effectclock,'beat')
	};
	LoadActor("1 (stretch).png")..{
		OnCommand=cmd(x,560;y,240;texcoordvelocity,0,0.25+(0.25/2);set_use_effect_clock_for_texcoords,true;effectclock,'beat')
	};
	LoadActor("1 (stretch).png")..{
		OnCommand=cmd(x,720;y,240;texcoordvelocity,0,0.25+(0.25/2);set_use_effect_clock_for_texcoords,true;effectclock,'beat')
	};
	LoadActor("1 (stretch).png")..{
		OnCommand=cmd(x,880;y,240;texcoordvelocity,0,0.25+(0.25/2);set_use_effect_clock_for_texcoords,true;effectclock,'beat')
	};
	LoadActor("1 (stretch).png")..{
		OnCommand=cmd(x,80;y,400;texcoordvelocity,0,0.25+(0.25/2);set_use_effect_clock_for_texcoords,true;effectclock,'beat')
	};
	LoadActor("1 (stretch).png")..{
		OnCommand=cmd(x,240;y,400;texcoordvelocity,0,0.25+(0.25/2);set_use_effect_clock_for_texcoords,true;effectclock,'beat')
	};
	LoadActor("1 (stretch).png")..{
		OnCommand=cmd(x,400;y,400;texcoordvelocity,0,0.25+(0.25/2);set_use_effect_clock_for_texcoords,true;effectclock,'beat')
	};
	LoadActor("1 (stretch).png")..{
		OnCommand=cmd(x,560;y,400;texcoordvelocity,0,0.25+(0.25/2);set_use_effect_clock_for_texcoords,true;effectclock,'beat')
	};
	LoadActor("1 (stretch).png")..{
		OnCommand=cmd(x,720;y,400;texcoordvelocity,0,0.25+(0.25/2);set_use_effect_clock_for_texcoords,true;effectclock,'beat')
	};
	LoadActor("1 (stretch).png")..{
		OnCommand=cmd(x,880;y,400;texcoordvelocity,0,0.25+(0.25/2);set_use_effect_clock_for_texcoords,true;effectclock,'beat')
	};
	LoadActor("1 (stretch).png")..{
		OnCommand=cmd(x,80;y,560;texcoordvelocity,0,0.25+(0.25/2);set_use_effect_clock_for_texcoords,true;effectclock,'beat')
	};
	LoadActor("1 (stretch).png")..{
		OnCommand=cmd(x,240;y,560;texcoordvelocity,0,0.25+(0.25/2);set_use_effect_clock_for_texcoords,true;effectclock,'beat')
	};
	LoadActor("1 (stretch).png")..{
		OnCommand=cmd(x,400;y,560;texcoordvelocity,0,0.25+(0.25/2);set_use_effect_clock_for_texcoords,true;effectclock,'beat')
	};
	LoadActor("1 (stretch).png")..{
		OnCommand=cmd(x,560;y,560;texcoordvelocity,0,0.25+(0.25/2);set_use_effect_clock_for_texcoords,true;effectclock,'beat')
	};
	LoadActor("1 (stretch).png")..{
		OnCommand=cmd(x,720;y,560;texcoordvelocity,0,0.25+(0.25/2);set_use_effect_clock_for_texcoords,true;effectclock,'beat')
	};
	LoadActor("1 (stretch).png")..{
		OnCommand=cmd(x,880;y,560;texcoordvelocity,0,0.25+(0.25/2);set_use_effect_clock_for_texcoords,true;effectclock,'beat')
	};
		LoadActor("../Sprites/Line", "2 Scissors 2x1.png")..{
		OnCommand=function(self)
			self:effectclock('beat')
		end
	},
}
local t = Def.ActorFrame{
	LoadActor("1")..{
		OnCommand=cmd(x,320;y,240)
	};
	LoadActor("1")..{
		OnCommand=cmd(x,320;addx,640;y,240)
	};
	LoadActor("A.lua")..{
		OnCommand=cmd()
	};
};

return t;
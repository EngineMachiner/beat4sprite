
return Def.ActorFrame{
	LoseFocusCommand=function(self)
		self:RunCommandsOnChildren(function(child) child:visible(false):finishtweening() end, {})
	end,

		LoadActor("../Sprites/ParticlesUp", "Globe 6x1.png")..{
		OnCommand=function(self)
			self:effectclock('beat')
			
		end
	},
	
		LoadActor("../Sprites/ParticlesUp", "Globe 6x1.png")..{
		OnCommand=function(self)
			self:effectclock('beat')
			
		end
	},
	
		LoadActor("../Sprites/ParticlesUp", "Globe 6x1.png")..{
		OnCommand=function(self)
			self:effectclock('beat')
			
		end
	},
	
		LoadActor("../Sprites/ParticlesUp", "Globe 6x1.png")..{
		OnCommand=function(self)
			self:effectclock('beat')
			
		end
	},
	
		LoadActor("../Sprites/ParticlesUp", "Globe 6x1.png")..{
		OnCommand=function(self)
			self:effectclock('beat')
			
		end
	},
	
		LoadActor("../Sprites/ParticlesUp", "Globe 6x1.png")..{
		OnCommand=function(self)
			self:effectclock('beat')
			
		end
	},

		LoadActor("../Sprites/ParticlesUp", "Globe 6x1.png")..{
		OnCommand=function(self)
			self:effectclock('beat')
			
		end
	},

		LoadActor("../Sprites/ParticlesUp", "Globe 6x1.png")..{
		OnCommand=function(self)
			self:effectclock('beat')
			
		end
	},
	
		LoadActor("../Sprites/ParticlesUp", "Globe 6x1.png")..{
		OnCommand=function(self)
			self:effectclock('beat')
			
		end
	},
	
		LoadActor("../Sprites/ParticlesUp", "Globe 6x1.png")..{
		OnCommand=function(self)
			self:effectclock('beat')
			
		end
	},
	
		LoadActor("../Sprites/ParticlesUp", "Globe 6x1.png")..{
		OnCommand=function(self)
			self:effectclock('beat')
			
		end
	},
	
		LoadActor("../Sprites/ParticlesUp", "Globe 6x1.png")..{
		OnCommand=function(self)
			self:effectclock('beat')
			
		end
	},
	
		LoadActor("../Sprites/ParticlesUp", "Globe 6x1.png")..{
		OnCommand=function(self)
			self:effectclock('beat')
			
		end
	},
	
		LoadActor("../Sprites/ParticlesUp", "Globe 6x1.png")..{
		OnCommand=function(self)
			self:effectclock('beat')
			
		end
	},
	
		LoadActor("../Sprites/ParticlesUp", "Globe 6x1.png")..{
		OnCommand=function(self)
			self:effectclock('beat')
			
		end
	},
}
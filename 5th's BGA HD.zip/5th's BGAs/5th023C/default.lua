local t = Def.ActorFrame{
	LoadActor("1")..{
		OnCommand=cmd(x,80;y,60)
	};
	LoadActor("1")..{
		OnCommand=cmd(x,240;y,60)
	};
	LoadActor("1")..{
		OnCommand=cmd(x,400;y,60)
	};
	LoadActor("1")..{
		OnCommand=cmd(x,560;y,60)
	};
	LoadActor("1")..{
		OnCommand=cmd(x,720;y,60)
	};
	LoadActor("1")..{
		OnCommand=cmd(x,880;y,60)
	};
	LoadActor("1")..{
		OnCommand=cmd(x,80;y,180)
	};
	LoadActor("1")..{
		OnCommand=cmd(x,240;y,180)
	};
	LoadActor("1")..{
		OnCommand=cmd(x,400;y,180)
	};
	LoadActor("1")..{
		OnCommand=cmd(x,560;y,180)
	};
	LoadActor("1")..{
		OnCommand=cmd(x,720;y,180)
	};
	LoadActor("1")..{
		OnCommand=cmd(x,880;y,180)
	};
	LoadActor("1")..{
		OnCommand=cmd(x,80;y,300)
	};
	LoadActor("1")..{
		OnCommand=cmd(x,240;y,300)
	};
	LoadActor("1")..{
		OnCommand=cmd(x,400;y,300)
	};
	LoadActor("1")..{
		OnCommand=cmd(x,560;y,300)
	};
	LoadActor("1")..{
		OnCommand=cmd(x,720;y,300)
	};
	LoadActor("1")..{
		OnCommand=cmd(x,880;y,300)
	};
	LoadActor("1")..{
		OnCommand=cmd(x,80;y,420)
	};
	LoadActor("1")..{
		OnCommand=cmd(x,240;y,420)
	};
	LoadActor("1")..{
		OnCommand=cmd(x,400;y,420)
	};
	LoadActor("1")..{
		OnCommand=cmd(x,560;y,420)
	};
	LoadActor("1")..{
		OnCommand=cmd(x,720;y,420)
	};
	LoadActor("1")..{
		OnCommand=cmd(x,880;y,420)
	};
	LoadActor("_particleLoader1.lua")..{
		OnCommand=cmd()
	};
	LoadActor("_particleLoader1 - copia.lua")..{
		OnCommand=cmd(rotationy,180;x,640;y,0)
	};
	LoadActor("_particleLoader2.lua")..{
		OnCommand=cmd(rotationx,180;x,0;y,480)
	};
	LoadActor("_particleLoader2 - copia.lua")..{
		OnCommand=cmd(rotationy,-180;rotationx,180;x,640;y,480)
	};
	
	LoadActor("_particleLoader1 - copia (2).lua")..{
		OnCommand=cmd()
	};
	LoadActor("_particleLoader1 - copia - copia.lua")..{
		OnCommand=cmd(rotationy,180;x,640;y,0)
	};
	LoadActor("_particleLoader2 - copia (2).lua")..{
		OnCommand=cmd(rotationx,180;x,0;y,480)
	};
	LoadActor("_particleLoader2 - copia - copia.lua")..{
		OnCommand=cmd(rotationy,-180;rotationx,180;x,640;y,480)
	};
};

return t;
local t = Def.ActorFrame{
	LoadActor("1")..{
		OnCommand=cmd(Center;SetSize,640,480)
	};
	LoadActor("1")..{
		OnCommand=cmd(Center;SetSize,640,480;addx,640;zoomx,-1)
	};
	LoadActor("1")..{
		OnCommand=cmd(Center;SetSize,640,480;addx,-640;zoomx,-1)
	};
	LoadActor("A.lua")..{
		OnCommand=cmd(diffusealpha,1/(18/4.5))
	};
};

return t;
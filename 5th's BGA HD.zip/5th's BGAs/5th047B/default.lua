return Def.ActorFrame{

	LoseFocusCommand=function(self)
		self:RunCommandsOnChildren(function(child) child:visible(false):finishtweening() end, {})
	end,

	LoadActor("B.lua")..{
		OnCommand=cmd(y,-480;linear,1.75*3.5;set_tween_uses_effect_delta,true;effectclock,"beat";addy,-480;queuecommand,"On")
	};
	LoadActor("B.lua")..{
		OnCommand=cmd(y,0;linear,1.75*3.5;set_tween_uses_effect_delta,true;effectclock,"beat";addy,-480;queuecommand,"On")
	};
	LoadActor("B.lua")..{
		OnCommand=cmd(y,480;linear,1.75*3.5;set_tween_uses_effect_delta,true;effectclock,"beat";addy,-480;queuecommand,"On")
	};

	LoadActor("A2.lua")..{
		OnCommand=cmd()
	};
}
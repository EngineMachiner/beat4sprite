local t = Def.ActorFrame{
		LoadActor("A.lua")..{
		OnCommand=cmd(Center)
	};
		LoadActor("A.lua")..{
		OnCommand=cmd(Center;addx,640)
	};
		LoadActor("A.lua")..{
		OnCommand=cmd(Center;addx,-640)
	};
};

return t;
local t = Def.ActorFrame{
		Def.Sprite{
		Texture = "1 2x1.png", 
		Frames = {{Delay= 0.5, Frame= 0}, {Delay= 0.5, Frame= 1}},
		OnCommand=cmd(x,77;y,80;effectclock,"beat")
	};
		Def.Sprite{
		Texture = "1 2x1.png", 
		Frames = {{Delay= 0.5, Frame= 0}, {Delay= 0.5, Frame= 1}},
		OnCommand=cmd(x,236;y,80;effectclock,"beat")
	};
		Def.Sprite{
		Texture = "1 2x1.png", 
		Frames = {{Delay= 0.5, Frame= 0}, {Delay= 0.5, Frame= 1}},
		OnCommand=cmd(x,77;y,240;effectclock,"beat")
	};
		Def.Sprite{
		Texture = "1 2x1.png", 
		Frames = {{Delay= 0.5, Frame= 0}, {Delay= 0.5, Frame= 1}},
		OnCommand=cmd(x,236;y,240;effectclock,"beat")
	};
		Def.Sprite{
		Texture = "1 2x1.png", 
		Frames = {{Delay= 0.5, Frame= 0}, {Delay= 0.5, Frame= 1}},
		OnCommand=cmd(x,77;y,400;effectclock,"beat")
	};
		Def.Sprite{
		Texture = "1 2x1.png", 
		Frames = {{Delay= 0.5, Frame= 0}, {Delay= 0.5, Frame= 1}},
		OnCommand=cmd(x,236;y,400;effectclock,"beat")
	};
		Def.Sprite{
		Texture = "1 2x1.png", 
		Frames = {{Delay= 0.5, Frame= 0}, {Delay= 0.5, Frame= 1}},
		OnCommand=cmd(x,77;y,560;effectclock,"beat")
	};
		Def.Sprite{
		Texture = "1 2x1.png", 
		Frames = {{Delay= 0.5, Frame= 0}, {Delay= 0.5, Frame= 1}},
		OnCommand=cmd(x,236;y,560;effectclock,"beat")
	};
};

return t;
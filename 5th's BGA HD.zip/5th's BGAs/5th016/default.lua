local t = Def.ActorFrame{
		LoadActor("A.lua")..{
		OnCommand=cmd(addy,80)
	};
		LoadActor("A.lua")..{
		OnCommand=cmd(addx,640;addy,80)
	};
		LoadActor("A.lua")..{
		OnCommand=cmd(addx,-640;addy,80)
	};
};

return t;
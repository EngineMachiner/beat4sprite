local t = Def.ActorFrame{
	LoadActor(GAMESTATE:GetCurrentSong():GetBackgroundPath())..{
		OnCommand=cmd(Center;SetSize,640,480;pulse;effectmagnitude,1.0625,1,0;effectperiod,1)
	};
	LoadActor(GAMESTATE:GetCurrentSong():GetBackgroundPath())..{
		OnCommand=cmd(Center;SetSize,640,480;cropbottom,0.5;cropright,0.5;pulse;effectmagnitude,1.0325,1,0;effectperiod,1;effectclock,'beat';diffusealpha,0.5;faderight,0.0625;fadebottom,0.0625)
	};
	LoadActor(GAMESTATE:GetCurrentSong():GetBackgroundPath())..{
		OnCommand=cmd(Center;SetSize,640,480;croptop,0.5;cropleft,0.5;pulse;effectmagnitude,1.0325,1,0;effectperiod,1;effectclock,'beat';diffusealpha,0.5;fadetop,0.0625;fadeleft,0.0625)
	};
	LoadActor(GAMESTATE:GetCurrentSong():GetBackgroundPath())..{
		OnCommand=cmd(Center;SetSize,640,480;cropbottom,0.5;cropleft,0.5;pulse;effectmagnitude,1.0325,1,0;effectperiod,1;effectclock,'beat';effectoffset,0.5;diffusealpha,0.5;fadeleft,0.0625;fadebottom,0.0625)
	};
	LoadActor(GAMESTATE:GetCurrentSong():GetBackgroundPath())..{
		OnCommand=cmd(Center;SetSize,640,480;croptop,0.5;cropright,0.5;pulse;effectmagnitude,1.0325,1,0;effectperiod,1;effectclock,'beat';effectoffset,0.5;diffusealpha,0.5;faderight,0.0625;fadetop,0.0625)
	};
	LoadActor(GAMESTATE:GetCurrentSong():GetBackgroundPath())..{
		OnCommand=cmd(Center;SetSize,640,480;cropbottom,0.5;cropright,0.5;pulse;effectmagnitude,1.0325,1,0;effectperiod,1;effectclock,'beat';diffusealpha,0.5;faderight,0.0625;fadebottom,0.0625)
	};
	LoadActor(GAMESTATE:GetCurrentSong():GetBackgroundPath())..{
		OnCommand=cmd(Center;SetSize,640,480;croptop,0.5;cropleft,0.5;pulse;effectmagnitude,1.0625,1,0;effectperiod,1;effectclock,'beat';diffusealpha,0.5;fadetop,0.0625;fadeleft,0.0625)
	};
	LoadActor(GAMESTATE:GetCurrentSong():GetBackgroundPath())..{
		OnCommand=cmd(Center;SetSize,640,480;cropbottom,0.5;cropleft,0.5;pulse;effectmagnitude,1.0625,1,0;effectperiod,1;effectclock,'beat';effectoffset,0.5;diffusealpha,0.25;fadeleft,0.0625;fadebottom,0.0625)
	};
	LoadActor(GAMESTATE:GetCurrentSong():GetBackgroundPath())..{
		OnCommand=cmd(Center;SetSize,640,480;croptop,0.5;cropright,0.5;pulse;effectmagnitude,1.0625,1,0;effectperiod,1;effectclock,'beat';effectoffset,0.5;diffusealpha,0.25;faderight,0.0625;fadetop,0.0625)
	};
};

return t;
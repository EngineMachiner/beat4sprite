local t = Def.ActorFrame{
		Def.Sprite{
		Texture = "1 2x1.png", 
		Frames = {{Delay= 1, Frame= 0}, {Delay= 1, Frame= 1}},
		OnCommand=cmd(Center;SetSize,640,480;effectclock,"beat")
	};
		Def.Sprite{
		Texture = "1 2x1.png", 
		Frames = {{Delay= 1, Frame= 0}, {Delay= 1, Frame= 1}},
		OnCommand=cmd(Center;SetSize,640,480;effectclock,"beat";addx,640;zoomx,-1)
	};
		Def.Sprite{
		Texture = "1 2x1.png", 
		Frames = {{Delay= 1, Frame= 0}, {Delay= 1, Frame= 1}},
		OnCommand=cmd(Center;SetSize,640,480;effectclock,"beat";addx,-640;zoomx,-1)
	};
};

return t;
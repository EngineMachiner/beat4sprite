return Def.ActorFrame{
    LoseFocusCommand=function(self)
        self:RunCommandsOnChildren(function(child) child:visible(false):finishtweening() end, {})
    end,
	    LoadActor("Mask2.png")..{
        OnCommand=function(self)
        self:Center()
            :SetSize(640,480)
            :zwrite(true)
            :blend('BlendMode_NoEffect')
        end
    };
 
    LoadActor(GAMESTATE:GetCurrentSong():GetBackgroundPath())..{
        OnCommand=function(self)
        self:Center()
            :SetSize(640,480)
			:rotationz(45):linear(8):rotationz(-360+45):queuecommand("On"):effectclock('beat'):set_tween_uses_effect_delta(true)
            :ztest(true)
        end
    };
    LoadActor("1.lua")..{
        OnCommand=function(self)
        self:x()
        end
    };

}
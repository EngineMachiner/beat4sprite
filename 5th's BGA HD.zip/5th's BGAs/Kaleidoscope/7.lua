return Def.ActorFrame{
    LoseFocusCommand=function(self)
        self:RunCommandsOnChildren(function(child) child:visible(false):finishtweening() end, {})
    end,
	    LoadActor("Mask7.png")..{
        OnCommand=function(self)
        self:Center()
            :SetSize(640,480)
            :zwrite(true)
            :blend('BlendMode_NoEffect')
        end
    };
 
    LoadActor(GAMESTATE:GetCurrentSong():GetBackgroundPath())..{
        OnCommand=function(self)
        self:Center()
            :SetSize(640,480)
			:rotationz(180+90):linear(8):rotationz(-360+180+90):queuecommand("On"):effectclock('beat'):set_tween_uses_effect_delta(true)
            :ztest(true)
        end
    };
    LoadActor("6.lua")..{
        OnCommand=function(self)
        self:x()
        end
    };

}
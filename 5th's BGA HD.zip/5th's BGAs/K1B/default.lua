return Def.ActorFrame{
    LoseFocusCommand=function(self)
        self:RunCommandsOnChildren(function(child) child:visible(false):finishtweening() end, {})
    end,
		LoadActor("../Sprites/Kaleidoscope", "BG4 (stretch).png")..{
		OnCommand=function(self)
			self:effectclock('beat')
		end
	},

}
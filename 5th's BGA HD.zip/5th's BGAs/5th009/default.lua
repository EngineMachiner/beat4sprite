return Def.ActorFrame{

	LoseFocusCommand=function(self)
		self:RunCommandsOnChildren(function(child) child:visible(false):finishtweening() end, {})
	end,

	LoadActor("1 (stretch)")..{
		OnCommand=cmd(Center;zoom,2;texcoordvelocity,0.075*1.25,0.075*1.25;set_use_effect_clock_for_texcoords,true;effectclock,'beat';customtexturerect,0,0,2,2)
	};
	LoadActor("2 (stretch)")..{
		OnCommand=cmd(Center;zoom,2;texcoordvelocity,0.075*1.25,0.075*1.25;set_use_effect_clock_for_texcoords,true;effectclock,'beat';customtexturerect,0,0,2,2)
	};
		LoadActor("../Sprites/Line/Sun", "2 Sun 2x1.png")..{
		OnCommand=function(self)
			self:effectclock('beat')
		end
	},
}
local t = Def.ActorFrame{
	LoadActor("1 (stretch).png")..{
		OnCommand=cmd(Center;zoom,15;customtexturerect,0,0,15,15;zwrite,true;blend,'BlendMode_NoEffect')
	};
	LoadActor("2 (stretch).png")..{
		OnCommand=cmd(Center;ztest,true;zoom,15;texcoordvelocity,0,-0.5;customtexturerect,0,0,15,15;effectclock,'beat';set_use_effect_clock_for_texcoords,true;effectclock,"beat")
	};

};

return t;
local Color1 = color("0,0,1,1")
return Def.ActorFrame{

	LoseFocusCommand=function(self)
		self:RunCommandsOnChildren(function(child) child:visible(false):finishtweening() end, {})
	end,
	LoadActor("3 (stretch)")..{
		OnCommand=cmd(Center;zoom,5;texcoordvelocity,0.25/2,0;customtexturerect,0,0,5,5;set_use_effect_clock_for_texcoords,true;effectclock,'beat')
	};
	LoadActor("B.lua")..{
		OnCommand=function(self)
		self:x(80)
		end
	};
}
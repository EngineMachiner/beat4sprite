return Def.ActorFrame{
	LoseFocusCommand=function(self)
		self:RunCommandsOnChildren(function(child) child:visible(false):finishtweening() end, {})
	end,

		LoadActor("../Sprites/ParticlesUp/4x3", "Spheres 4x3.png")..{
		OnCommand=function(self)
			self:effectclock('beat')
			
		end
	},
	
		LoadActor("../Sprites/ParticlesUp/4x3", "Spheres 4x3.png")..{
		OnCommand=function(self)
			self:effectclock('beat')
			
		end
	},
	
		LoadActor("../Sprites/ParticlesUp/4x3", "Spheres 4x3.png")..{
		OnCommand=function(self)
			self:effectclock('beat')
			
		end
	},
	
		LoadActor("../Sprites/ParticlesUp/4x3", "Spheres 4x3.png")..{
		OnCommand=function(self)
			self:effectclock('beat')
			
		end
	},
	
		LoadActor("../Sprites/ParticlesUp/4x3", "Spheres 4x3.png")..{
		OnCommand=function(self)
			self:effectclock('beat')
			
		end
	},
	
		LoadActor("../Sprites/ParticlesUp/4x3", "Spheres 4x3.png")..{
		OnCommand=function(self)
			self:effectclock('beat')
			
		end
	},

		LoadActor("../Sprites/ParticlesUp/4x3", "Spheres 4x3.png")..{
		OnCommand=function(self)
			self:effectclock('beat')
			
		end
	},

		LoadActor("../Sprites/ParticlesUp/4x3", "Spheres 4x3.png")..{
		OnCommand=function(self)
			self:effectclock('beat')
			
		end
	},
	
		LoadActor("../Sprites/ParticlesUp/4x3", "Spheres 4x3.png")..{
		OnCommand=function(self)
			self:effectclock('beat')
			
		end
	},
	
		LoadActor("../Sprites/ParticlesUp/4x3", "Spheres 4x3.png")..{
		OnCommand=function(self)
			self:effectclock('beat')
			
		end
	},
	
		LoadActor("../Sprites/ParticlesUp/4x3", "Spheres 4x3.png")..{
		OnCommand=function(self)
			self:effectclock('beat')
			
		end
	},
	
		LoadActor("../Sprites/ParticlesUp/4x3", "Spheres 4x3.png")..{
		OnCommand=function(self)
			self:effectclock('beat')
			
		end
	},
	
		LoadActor("../Sprites/ParticlesUp/4x3", "Spheres 4x3.png")..{
		OnCommand=function(self)
			self:effectclock('beat')
			
		end
	},
	
		LoadActor("../Sprites/ParticlesUp/4x3", "Spheres 4x3.png")..{
		OnCommand=function(self)
			self:effectclock('beat')
			
		end
	},
	
		LoadActor("../Sprites/ParticlesUp/4x3", "Spheres 4x3.png")..{
		OnCommand=function(self)
			self:effectclock('beat')
			
		end
	},
}
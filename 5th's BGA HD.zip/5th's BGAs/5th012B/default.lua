local t = Def.ActorFrame{
	LoadActor("A.lua")..{
		OnCommand=cmd(x,0;y,0;effectclock,"beat")
	};
	LoadActor("A.lua")..{
		OnCommand=cmd(x,159.25*2;y,0;effectclock,"beat")
	};
	LoadActor("A.lua")..{
		OnCommand=cmd(x,159*4;y,0;effectclock,"beat")
	};
};

return t;
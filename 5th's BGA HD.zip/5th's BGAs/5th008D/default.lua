local WDX2 if SCREEN_WIDTH > 640 then WDX2 = -80/1.75 else WDX2 = 0 end;
return Def.ActorFrame{

	LoseFocusCommand=function(self)
		self:RunCommandsOnChildren(function(child) child:visible(false):finishtweening() end, {})
	end,
		LoadActor("A.lua")..{
		OnCommand=function(self) 
			self:effectclock('beat')
		end

	},
	
		LoadActor("A.lua")..{
		OnCommand=function(self) 
			self:effectclock('beat')
			:addx(640)
		end

	},
	
		LoadActor("A.lua")..{
		OnCommand=function(self) 
			self:effectclock('beat')
			:addx(-640)
		end

	},

		LoadActor("../Sprites/Line/Sun", "Skulls 2x1.png")..{
		OnCommand=function(self)
			self:effectclock('beat')
		end
	},
}
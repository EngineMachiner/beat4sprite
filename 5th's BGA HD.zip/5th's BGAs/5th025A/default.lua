local t = Def.ActorFrame{
	LoadActor("1 (stretch).png")..{
		OnCommand=cmd(Center;zoom,2;texcoordvelocity,0,0.075*1.25;customtexturerect,0,0,2,2;set_use_effect_clock_for_texcoords,true;effectclock,'beat')
	};
	LoadActor("A.lua")..{
		OnCommand=cmd()
	};
};

return t;
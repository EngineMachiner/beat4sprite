local WDX2 if SCREEN_WIDTH > 640 then WDX2 = -80/1.5 else WDX2 = 0 end;
return Def.ActorFrame{

	LoseFocusCommand=function(self)
		self:RunCommandsOnChildren(function(child) child:visible(false):finishtweening() end, {})
	end,
	
		LoadActor("A.lua")..{
		OnCommand=cmd(addy,60)
	};
		LoadActor("A.lua")..{
		OnCommand=cmd(addx,640;addy,60)
	};
		LoadActor("A.lua")..{
		OnCommand=cmd(addx,-640;addy,60)
	};
	LoadActor("sprite1.lua")..{
		OnCommand=cmd(y,0;linear,2.5;y,-480;set_tween_uses_effect_delta,true;queuecommand,"On")
	};
	LoadActor("sprite1.lua")..{
		OnCommand=cmd(y,480;linear,2.5;y,0;set_tween_uses_effect_delta,true;queuecommand,"On")
	};
}
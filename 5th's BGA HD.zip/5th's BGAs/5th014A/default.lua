local t = Def.ActorFrame{
		LoadActor("A.lua")..{
		OnCommand=cmd(addy,60)
	};
		LoadActor("A.lua")..{
		OnCommand=cmd(addx,640;addy,60)
	};
		LoadActor("A.lua")..{
		OnCommand=cmd(addx,-640;addy,60)
	};
};

return t;
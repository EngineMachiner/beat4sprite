return Def.ActorFrame{
	LoseFocusCommand=function(self)
		self:RunCommandsOnChildren(function(child) child:visible(false):finishtweening() end, {})
	end,
	LoadActor(GAMESTATE:GetCurrentSong():GetBackgroundPath())..{
		OnCommand=function(self)
		self:Center()
			:addx(640)
			:zoomx(-1)
			:SetSize(640,480)
			:faderight(0.025)
			:rainbow():effectperiod(8):effectclock("beat")
		end
	};
	
	LoadActor(GAMESTATE:GetCurrentSong():GetBackgroundPath())..{
		OnCommand=function(self)
		self:Center()
			:addx(-640)
			:zoomx(-1)
			:SetSize(640,480)
			:fadeleft(0.025)
			:rainbow():effectperiod(8):effectclock("beat")
		end
	};
	
	LoadActor("B.lua")..{
		OnCommand=function(self)
		self:diffusealpha(1/(19/(19/2.5)))
		:rainbow():effectperiod(8):effectclock("beat")
		end
	};
	
}
return Def.ActorFrame{
	LoseFocusCommand=function(self)
		self:RunCommandsOnChildren(function(child) child:visible(false):finishtweening() end, {})
	end,
	LoadActor("1 (stretch).png")..{
		OnCommand=cmd(Center;zoom,2;customtexturerect,0,0,2,2)
	};
		LoadActor("../Sprites/Line/Static2", "2 Cake.png")..{
		OnCommand=function(self)
			self:effectclock('beat')
		end
	},
}
return Def.ActorFrame{

	LoseFocusCommand=function(self)
		self:RunCommandsOnChildren(function(child) child:visible(false):finishtweening() end, {})
	end,
	LoadActor("sprite1.lua")..{
		OnCommand=cmd(x,160;linear,2*2;set_tween_uses_effect_delta,true;effectclock,"beat";x,0;queuecommand,"On")
	};
	LoadActor("sprite1.lua")..{
		OnCommand=cmd(x,0;linear,2*2;set_tween_uses_effect_delta,true;effectclock,"beat";x,-160;queuecommand,"On")
	};
}
local t = Def.ActorFrame{
	LoadActor("1 (stretch)")..{
		OnCommand=cmd(Center;zoom,10;texcoordvelocity,0,-0.25-(0.25/2);set_use_effect_clock_for_texcoords,true;effectclock,'beat';customtexturerect,0,0,10,10)
	};
		LoadActor("../Sprites/Line/Static", "2 Cake.png")..{
		OnCommand=function(self)
			self:effectclock('beat')
		end
	},
};

return t;
local WDX2 if SCREEN_WIDTH > 640 then WDX2 = -80/1.5 else WDX2 = 0 end;
local t = Def.ActorFrame{
		Def.Sprite{
		Texture = "1 2x2.png", 
		Frames = {{Delay= 0.25, Frame= 0}, {Delay= 0.25, Frame= 1}, {Delay= 0.25, Frame= 2}, {Delay= 0.25, Frame= 3}},
		OnCommand=cmd(x,80;y,60;addx,WDX2;effectclock,"beat")
	};
		Def.Sprite{
		Texture = "1 2x2.png", 
		Frames = {{Delay= 0.25, Frame= 0}, {Delay= 0.25, Frame= 1}, {Delay= 0.25, Frame= 2}, {Delay= 0.25, Frame= 3}},
		OnCommand=cmd(x,240;y,60;addx,WDX2;effectclock,"beat")
	};
		Def.Sprite{
		Texture = "1 2x2.png", 
		Frames = {{Delay= 0.25, Frame= 0}, {Delay= 0.25, Frame= 1}, {Delay= 0.25, Frame= 2}, {Delay= 0.25, Frame= 3}},
		OnCommand=cmd(x,400;y,60;addx,WDX2;effectclock,"beat")
	};
		Def.Sprite{
		Texture = "1 2x2.png", 
		Frames = {{Delay= 0.25, Frame= 0}, {Delay= 0.25, Frame= 1}, {Delay= 0.25, Frame= 2}, {Delay= 0.25, Frame= 3}},
		OnCommand=cmd(x,560;y,60;addx,WDX2;effectclock,"beat")
	};
		Def.Sprite{
		Texture = "1 2x2.png", 
		Frames = {{Delay= 0.25, Frame= 0}, {Delay= 0.25, Frame= 1}, {Delay= 0.25, Frame= 2}, {Delay= 0.25, Frame= 3}},
		OnCommand=cmd(x,720;y,60;addx,WDX2;effectclock,"beat")
	};
		Def.Sprite{
		Texture = "1 2x2.png", 
		Frames = {{Delay= 0.25, Frame= 0}, {Delay= 0.25, Frame= 1}, {Delay= 0.25, Frame= 2}, {Delay= 0.25, Frame= 3}},
		OnCommand=cmd(x,880;y,60;addx,WDX2;effectclock,"beat")
	};
		Def.Sprite{
		Texture = "1 2x2.png", 
		Frames = {{Delay= 0.25, Frame= 0}, {Delay= 0.25, Frame= 1}, {Delay= 0.25, Frame= 2}, {Delay= 0.25, Frame= 3}},
		OnCommand=cmd(x,80;y,180;addx,WDX2;effectclock,"beat")
	};
		Def.Sprite{
		Texture = "1 2x2.png", 
		Frames = {{Delay= 0.25, Frame= 0}, {Delay= 0.25, Frame= 1}, {Delay= 0.25, Frame= 2}, {Delay= 0.25, Frame= 3}},
		OnCommand=cmd(x,240;y,180;addx,WDX2;effectclock,"beat")
	};
		Def.Sprite{
		Texture = "1 2x2.png", 
		Frames = {{Delay= 0.25, Frame= 0}, {Delay= 0.25, Frame= 1}, {Delay= 0.25, Frame= 2}, {Delay= 0.25, Frame= 3}},
		OnCommand=cmd(x,400;y,180;addx,WDX2;effectclock,"beat")
	};
		Def.Sprite{
		Texture = "1 2x2.png", 
		Frames = {{Delay= 0.25, Frame= 0}, {Delay= 0.25, Frame= 1}, {Delay= 0.25, Frame= 2}, {Delay= 0.25, Frame= 3}},
		OnCommand=cmd(x,560;y,180;addx,WDX2;effectclock,"beat")
	};
		Def.Sprite{
		Texture = "1 2x2.png", 
		Frames = {{Delay= 0.25, Frame= 0}, {Delay= 0.25, Frame= 1}, {Delay= 0.25, Frame= 2}, {Delay= 0.25, Frame= 3}},
		OnCommand=cmd(x,720;y,180;addx,WDX2;effectclock,"beat")
	};
		Def.Sprite{
		Texture = "1 2x2.png", 
		Frames = {{Delay= 0.25, Frame= 0}, {Delay= 0.25, Frame= 1}, {Delay= 0.25, Frame= 2}, {Delay= 0.25, Frame= 3}},
		OnCommand=cmd(x,880;y,180;addx,WDX2;effectclock,"beat")
	};
		Def.Sprite{
		Texture = "1 2x2.png", 
		Frames = {{Delay= 0.25, Frame= 0}, {Delay= 0.25, Frame= 1}, {Delay= 0.25, Frame= 2}, {Delay= 0.25, Frame= 3}},
		OnCommand=cmd(x,80;y,300;addx,WDX2;effectclock,"beat")
	};
		Def.Sprite{
		Texture = "1 2x2.png", 
		Frames = {{Delay= 0.25, Frame= 0}, {Delay= 0.25, Frame= 1}, {Delay= 0.25, Frame= 2}, {Delay= 0.25, Frame= 3}},
		OnCommand=cmd(x,240;y,300;addx,WDX2;effectclock,"beat")
	};
		Def.Sprite{
		Texture = "1 2x2.png", 
		Frames = {{Delay= 0.25, Frame= 0}, {Delay= 0.25, Frame= 1}, {Delay= 0.25, Frame= 2}, {Delay= 0.25, Frame= 3}},
		OnCommand=cmd(x,400;y,300;addx,WDX2;effectclock,"beat")
	};
		Def.Sprite{
		Texture = "1 2x2.png", 
		Frames = {{Delay= 0.25, Frame= 0}, {Delay= 0.25, Frame= 1}, {Delay= 0.25, Frame= 2}, {Delay= 0.25, Frame= 3}},
		OnCommand=cmd(x,560;y,300;addx,WDX2;effectclock,"beat")
	};
		Def.Sprite{
		Texture = "1 2x2.png", 
		Frames = {{Delay= 0.25, Frame= 0}, {Delay= 0.25, Frame= 1}, {Delay= 0.25, Frame= 2}, {Delay= 0.25, Frame= 3}},
		OnCommand=cmd(x,720;y,300;addx,WDX2;effectclock,"beat")
	};
		Def.Sprite{
		Texture = "1 2x2.png", 
		Frames = {{Delay= 0.25, Frame= 0}, {Delay= 0.25, Frame= 1}, {Delay= 0.25, Frame= 2}, {Delay= 0.25, Frame= 3}},
		OnCommand=cmd(x,880;y,300;addx,WDX2;effectclock,"beat")
	};
		Def.Sprite{
		Texture = "1 2x2.png", 
		Frames = {{Delay= 0.25, Frame= 0}, {Delay= 0.25, Frame= 1}, {Delay= 0.25, Frame= 2}, {Delay= 0.25, Frame= 3}},
		OnCommand=cmd(x,80;y,420;addx,WDX2;effectclock,"beat")
	};
		Def.Sprite{
		Texture = "1 2x2.png", 
		Frames = {{Delay= 0.25, Frame= 0}, {Delay= 0.25, Frame= 1}, {Delay= 0.25, Frame= 2}, {Delay= 0.25, Frame= 3}},
		OnCommand=cmd(x,240;y,420;addx,WDX2;effectclock,"beat")
	};
		Def.Sprite{
		Texture = "1 2x2.png", 
		Frames = {{Delay= 0.25, Frame= 0}, {Delay= 0.25, Frame= 1}, {Delay= 0.25, Frame= 2}, {Delay= 0.25, Frame= 3}},
		OnCommand=cmd(x,400;y,420;addx,WDX2;effectclock,"beat")
	};
		Def.Sprite{
		Texture = "1 2x2.png", 
		Frames = {{Delay= 0.25, Frame= 0}, {Delay= 0.25, Frame= 1}, {Delay= 0.25, Frame= 2}, {Delay= 0.25, Frame= 3}},
		OnCommand=cmd(x,560;y,420;addx,WDX2;effectclock,"beat")
	};
		Def.Sprite{
		Texture = "1 2x2.png", 
		Frames = {{Delay= 0.25, Frame= 0}, {Delay= 0.25, Frame= 1}, {Delay= 0.25, Frame= 2}, {Delay= 0.25, Frame= 3}},
		OnCommand=cmd(x,720;y,420;addx,WDX2;effectclock,"beat")
	};
		Def.Sprite{
		Texture = "1 2x2.png", 
		Frames = {{Delay= 0.25, Frame= 0}, {Delay= 0.25, Frame= 1}, {Delay= 0.25, Frame= 2}, {Delay= 0.25, Frame= 3}},
		OnCommand=cmd(x,880;y,420;addx,WDX2;effectclock,"beat")
	};
};

return t;
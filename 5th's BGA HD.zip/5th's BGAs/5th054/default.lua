local WDX2 if SCREEN_WIDTH > 640 then WDX2 = -80/1.5 else WDX2 = 0 end;
local t = Def.ActorFrame{
		Def.Sprite{
		Texture = "1 2x1", 
		Frames = {{Delay= 1, Frame= 0}, {Delay= 1, Frame= 1}},
		OnCommand=cmd(x,159.7;y,360;addx,WDX2;effectclock,"beat")
	};
		Def.Sprite{
		Texture = "1 2x1", 
		Frames = {{Delay= 1, Frame= 0}, {Delay= 1, Frame= 1}},
		OnCommand=cmd(x,479.3;y,360;addx,WDX2;effectclock,"beat")
	};
		Def.Sprite{
		Texture = "1 2x1", 
		Frames = {{Delay= 1, Frame= 0}, {Delay= 1, Frame= 1}},
		OnCommand=cmd(x,798.9;y,360;addx,WDX2;effectclock,"beat")
	};
		Def.Sprite{
		Texture = "1 2x1", 
		Frames = {{Delay= 1, Frame= 0}, {Delay= 1, Frame= 1}},
		OnCommand=cmd(x,159.7;y,120;addx,WDX2;effectclock,"beat")
	};
		Def.Sprite{
		Texture = "1 2x1", 
		Frames = {{Delay= 1, Frame= 0}, {Delay= 1, Frame= 1}},
		OnCommand=cmd(x,479.3;y,120;addx,WDX2;effectclock,"beat")
	};
		Def.Sprite{
		Texture = "1 2x1", 
		Frames = {{Delay= 1, Frame= 0}, {Delay= 1, Frame= 1}},
		OnCommand=cmd(x,798.9;y,120;addx,WDX2;effectclock,"beat")
	};
		Def.Sprite{
		Texture = "2 TileStill 2x1", 
		Frames = {{Delay= 1, Frame= 0}, {Delay= 1, Frame= 1}},
		OnCommand=cmd(x,80;y,60;addx,WDX2;effectclock,"beat")
	};
		Def.Sprite{
		Texture = "2 TileStill 2x1", 
		Frames = {{Delay= 1, Frame= 0}, {Delay= 1, Frame= 1}},
		OnCommand=cmd(x,240;y,60;addx,WDX2;effectclock,"beat")
	};
		Def.Sprite{
		Texture = "2 TileStill 2x1", 
		Frames = {{Delay= 1, Frame= 0}, {Delay= 1, Frame= 1}},
		OnCommand=cmd(x,400;y,60;addx,WDX2;effectclock,"beat")
	};
		Def.Sprite{
		Texture = "2 TileStill 2x1", 
		Frames = {{Delay= 1, Frame= 0}, {Delay= 1, Frame= 1}},
		OnCommand=cmd(x,560;y,60;addx,WDX2;effectclock,"beat")
	};
		Def.Sprite{
		Texture = "2 TileStill 2x1", 
		Frames = {{Delay= 1, Frame= 0}, {Delay= 1, Frame= 1}},
		OnCommand=cmd(x,720;y,60;addx,WDX2;effectclock,"beat")
	};
		Def.Sprite{
		Texture = "2 TileStill 2x1", 
		Frames = {{Delay= 1, Frame= 0}, {Delay= 1, Frame= 1}},
		OnCommand=cmd(x,880;y,60;addx,WDX2;effectclock,"beat")
	};
		Def.Sprite{
		Texture = "2 TileStill 2x1", 
		Frames = {{Delay= 1, Frame= 0}, {Delay= 1, Frame= 1}},
		OnCommand=cmd(x,80;y,180;addx,WDX2;effectclock,"beat")
	};
		Def.Sprite{
		Texture = "2 TileStill 2x1", 
		Frames = {{Delay= 1, Frame= 0}, {Delay= 1, Frame= 1}},
		OnCommand=cmd(x,240;y,180;addx,WDX2;effectclock,"beat")
	};
		Def.Sprite{
		Texture = "2 TileStill 2x1", 
		Frames = {{Delay= 1, Frame= 0}, {Delay= 1, Frame= 1}},
		OnCommand=cmd(x,400;y,180;addx,WDX2;effectclock,"beat")
	};
		Def.Sprite{
		Texture = "2 TileStill 2x1", 
		Frames = {{Delay= 1, Frame= 0}, {Delay= 1, Frame= 1}},
		OnCommand=cmd(x,560;y,180;addx,WDX2;effectclock,"beat")
	};
		Def.Sprite{
		Texture = "2 TileStill 2x1", 
		Frames = {{Delay= 1, Frame= 0}, {Delay= 1, Frame= 1}},
		OnCommand=cmd(x,720;y,180;addx,WDX2;effectclock,"beat")
	};
		Def.Sprite{
		Texture = "2 TileStill 2x1", 
		Frames = {{Delay= 1, Frame= 0}, {Delay= 1, Frame= 1}},
		OnCommand=cmd(x,880;y,180;addx,WDX2;effectclock,"beat")
	};
		Def.Sprite{
		Texture = "2 TileStill 2x1", 
		Frames = {{Delay= 1, Frame= 0}, {Delay= 1, Frame= 1}},
		OnCommand=cmd(x,80;y,300;addx,WDX2;effectclock,"beat")
	};
		Def.Sprite{
		Texture = "2 TileStill 2x1", 
		Frames = {{Delay= 1, Frame= 0}, {Delay= 1, Frame= 1}},
		OnCommand=cmd(x,240;y,300;addx,WDX2;effectclock,"beat")
	};
		Def.Sprite{
		Texture = "2 TileStill 2x1", 
		Frames = {{Delay= 1, Frame= 0}, {Delay= 1, Frame= 1}},
		OnCommand=cmd(x,400;y,300;addx,WDX2;effectclock,"beat")
	};
		Def.Sprite{
		Texture = "2 TileStill 2x1", 
		Frames = {{Delay= 1, Frame= 0}, {Delay= 1, Frame= 1}},
		OnCommand=cmd(x,560;y,300;addx,WDX2;effectclock,"beat")
	};
		Def.Sprite{
		Texture = "2 TileStill 2x1", 
		Frames = {{Delay= 1, Frame= 0}, {Delay= 1, Frame= 1}},
		OnCommand=cmd(x,720;y,300;addx,WDX2;effectclock,"beat")
	};
		Def.Sprite{
		Texture = "2 TileStill 2x1", 
		Frames = {{Delay= 1, Frame= 0}, {Delay= 1, Frame= 1}},
		OnCommand=cmd(x,880;y,300;addx,WDX2;effectclock,"beat")
	};
		Def.Sprite{
		Texture = "2 TileStill 2x1", 
		Frames = {{Delay= 1, Frame= 0}, {Delay= 1, Frame= 1}},
		OnCommand=cmd(x,80;y,420;addx,WDX2;effectclock,"beat")
	};
		Def.Sprite{
		Texture = "2 TileStill 2x1", 
		Frames = {{Delay= 1, Frame= 0}, {Delay= 1, Frame= 1}},
		OnCommand=cmd(x,240;y,420;addx,WDX2;effectclock,"beat")
	};
		Def.Sprite{
		Texture = "2 TileStill 2x1", 
		Frames = {{Delay= 1, Frame= 0}, {Delay= 1, Frame= 1}},
		OnCommand=cmd(x,400;y,420;addx,WDX2;effectclock,"beat")
	};
		Def.Sprite{
		Texture = "2 TileStill 2x1", 
		Frames = {{Delay= 1, Frame= 0}, {Delay= 1, Frame= 1}},
		OnCommand=cmd(x,560;y,420;addx,WDX2;effectclock,"beat")
	};
		Def.Sprite{
		Texture = "2 TileStill 2x1", 
		Frames = {{Delay= 1, Frame= 0}, {Delay= 1, Frame= 1}},
		OnCommand=cmd(x,720;y,420;addx,WDX2;effectclock,"beat")
	};
		Def.Sprite{
		Texture = "2 TileStill 2x1", 
		Frames = {{Delay= 1, Frame= 0}, {Delay= 1, Frame= 1}},
		OnCommand=cmd(x,880;y,420;addx,WDX2;effectclock,"beat")
	};
};

return t;
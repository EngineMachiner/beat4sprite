local t = Def.ActorFrame{
	LoadActor("1 (stretch)")..{
		OnCommand=cmd(Center;SetSize,640,480)
	};
	LoadActor("1 (stretch)")..{
		OnCommand=cmd(Center;SetSize,640,480;addx,640)
	};
	LoadActor("1 (stretch)")..{
		OnCommand=cmd(Center;SetSize,640,480;addx,-640)
	};
	LoadActor("2 TileScrollLeft (stretch)")..{
		OnCommand=function(self)
		self:Center():FullScreen()
			:zoom(3)
			:customtexturerect(0,0,3,3)
			:set_use_effect_clock_for_texcoords(true)
			:texcoordvelocity(-0.15/4,0):effectclock('beat')
			end
	};
};

return t;
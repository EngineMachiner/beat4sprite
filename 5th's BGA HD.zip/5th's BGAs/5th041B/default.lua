local t = Def.ActorFrame{
	LoadActor("1 (stretch)")..{
		OnCommand=cmd(Center;zoom,5;texcoordvelocity,0,-0.1;customtexturerect,0,0,5,5;set_use_effect_clock_for_texcoords,true;effectclock,'beat')
	};
};

return t;
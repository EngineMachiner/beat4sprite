return Def.ActorFrame{
	LoseFocusCommand=function(self)
		self:RunCommandsOnChildren(function(child) child:visible(false):finishtweening() end, {})
	end,
	
	LoadActor("1 (stretch)")..{
		OnCommand=cmd(Center;zoom,12;customtexturerect,0,0,12,12)
	};
		LoadActor("../Sprites/InnerEffect/SpinSprite/001", "2.png")..{
		OnCommand=function(self)
			self:effectclock('beat')
		end
	},
}
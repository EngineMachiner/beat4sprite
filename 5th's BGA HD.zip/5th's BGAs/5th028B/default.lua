local WDX3 if SCREEN_WIDTH > 640 then WDX3 = SCREEN_WIDTH/8.5 else WDX3 = 9 end;
return Def.ActorFrame{

	LoseFocusCommand=function(self)
		self:RunCommandsOnChildren(function(child) child:visible(false):finishtweening() end, {})
	end,
	LoadActor("1 (stretch)")..{
		OnCommand=cmd(Center;zoom,2;texcoordvelocity,0,0.45/2;customtexturerect,0,0,2,2;rainbow;effectperiod,8;set_use_effect_clock_for_texcoords,true;effectclock,'beat')
	};
		LoadActor("../Sprites/SpiralSpriteZoomIn/Jewels", "1.png")..{
		OnCommand=function(self)
			self:effectclock('beat')
			:addx(WDX3)
		end
	},
}
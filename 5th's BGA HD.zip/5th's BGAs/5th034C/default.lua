local t = Def.ActorFrame{
	LoadActor("A.lua")..{
		OnCommand=cmd(rainbow;diffusealpha,0.35;effectperiod,8;effectclock,'music')
	};
	LoadActor("A.lua")..{
		OnCommand=cmd(rainbow;diffusealpha,0.35;effectperiod,8;blend,"BlendMode_Add";effectclock,'music')
	};
};

return t
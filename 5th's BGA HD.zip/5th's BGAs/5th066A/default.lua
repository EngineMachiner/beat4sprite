local t = Def.ActorFrame{
	LoadActor("1 (stretch)")..{
		OnCommand=cmd(Center;zoom,16;customtexturerect,0,0,16,16)
	};
	LoadActor("2 (stretch)")..{
		OnCommand=cmd(Center;zoom,16;texcoordvelocity,0.5,0;customtexturerect,0,0,16,16;set_use_effect_clock_for_texcoords,true;effectclock,"beat")
	};
};

return t;
local t = Def.ActorFrame{
	LoadActor("A2.lua")..{
		OnCommand=cmd()
	};
	LoadActor("A2.lua")..{
		OnCommand=cmd(addy,120)
	};
	LoadActor("A2.lua")..{
		OnCommand=cmd(addy,120*2)
	};
	LoadActor("A2.lua")..{
		OnCommand=cmd(addy,120*3)
	};

};

return t;
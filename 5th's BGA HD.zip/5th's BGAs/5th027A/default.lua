local WDX2 if SCREEN_WIDTH > 640 then WDX2 = -80/1.5 else WDX2 = 0 end;
return Def.ActorFrame{
	LoseFocusCommand=function(self)
		self:RunCommandsOnChildren(function(child) child:visible(false):finishtweening() end, {})
	end,
	LoadActor("B.lua")..{
		OnCommand=cmd()
	};
		Def.Sprite{
		Texture = "2 4x1.png", 
		Frames = {{Delay= 0.25, Frame= 0}, {Delay= 0.25, Frame= 1}, {Delay= 0.25, Frame= 2}, {Delay= 0.25, Frame= 3}},
		OnCommand=cmd(x,80;y,60;spin;effectmagnitude,0,90,0;addx,WDX2;effectclock,"beat")
	};
		Def.Sprite{
		Texture = "2 4x1.png", 
		Frames = {{Delay= 0.25, Frame= 0}, {Delay= 0.25, Frame= 1}, {Delay= 0.25, Frame= 2}, {Delay= 0.25, Frame= 3}},
		OnCommand=cmd(x,240;y,60;spin;effectmagnitude,0,90,0;addx,WDX2;effectclock,"beat")
	};
		Def.Sprite{
		Texture = "2 4x1.png", 
		Frames = {{Delay= 0.25, Frame= 0}, {Delay= 0.25, Frame= 1}, {Delay= 0.25, Frame= 2}, {Delay= 0.25, Frame= 3}},
		OnCommand=cmd(x,400;y,60;spin;effectmagnitude,0,90,0;addx,WDX2;effectclock,"beat")
	};
		Def.Sprite{
		Texture = "2 4x1.png", 
		Frames = {{Delay= 0.25, Frame= 0}, {Delay= 0.25, Frame= 1}, {Delay= 0.25, Frame= 2}, {Delay= 0.25, Frame= 3}},
		OnCommand=cmd(x,560;y,60;spin;effectmagnitude,0,90,0;addx,WDX2;effectclock,"beat")
	};
		Def.Sprite{
		Texture = "2 4x1.png", 
		Frames = {{Delay= 0.25, Frame= 0}, {Delay= 0.25, Frame= 1}, {Delay= 0.25, Frame= 2}, {Delay= 0.25, Frame= 3}},
		OnCommand=cmd(x,720;y,60;spin;effectmagnitude,0,90,0;addx,WDX2;effectclock,"beat")
	};
		Def.Sprite{
		Texture = "2 4x1.png", 
		Frames = {{Delay= 0.25, Frame= 0}, {Delay= 0.25, Frame= 1}, {Delay= 0.25, Frame= 2}, {Delay= 0.25, Frame= 3}},
		OnCommand=cmd(x,880;y,60;spin;effectmagnitude,0,90,0;addx,WDX2;effectclock,"beat")
	};
		Def.Sprite{
		Texture = "2 4x1.png", 
		Frames = {{Delay= 0.25, Frame= 0}, {Delay= 0.25, Frame= 1}, {Delay= 0.25, Frame= 2}, {Delay= 0.25, Frame= 3}},
		OnCommand=cmd(x,80;y,180;spin;effectmagnitude,0,90,0;addx,WDX2;effectclock,"beat")
	};
		Def.Sprite{
		Texture = "2 4x1.png", 
		Frames = {{Delay= 0.25, Frame= 0}, {Delay= 0.25, Frame= 1}, {Delay= 0.25, Frame= 2}, {Delay= 0.25, Frame= 3}},
		OnCommand=cmd(x,240;y,180;spin;effectmagnitude,0,90,0;addx,WDX2;effectclock,"beat")
	};
		Def.Sprite{
		Texture = "2 4x1.png", 
		Frames = {{Delay= 0.25, Frame= 0}, {Delay= 0.25, Frame= 1}, {Delay= 0.25, Frame= 2}, {Delay= 0.25, Frame= 3}},
		OnCommand=cmd(x,400;y,180;spin;effectmagnitude,0,90,0;addx,WDX2;effectclock,"beat")
	};
		Def.Sprite{
		Texture = "2 4x1.png", 
		Frames = {{Delay= 0.25, Frame= 0}, {Delay= 0.25, Frame= 1}, {Delay= 0.25, Frame= 2}, {Delay= 0.25, Frame= 3}},
		OnCommand=cmd(x,560;y,180;spin;effectmagnitude,0,90,0;addx,WDX2;effectclock,"beat")
	};
		Def.Sprite{
		Texture = "2 4x1.png", 
		Frames = {{Delay= 0.25, Frame= 0}, {Delay= 0.25, Frame= 1}, {Delay= 0.25, Frame= 2}, {Delay= 0.25, Frame= 3}},
		OnCommand=cmd(x,720;y,180;spin;effectmagnitude,0,90,0;addx,WDX2;effectclock,"beat")
	};
		Def.Sprite{
		Texture = "2 4x1.png", 
		Frames = {{Delay= 0.25, Frame= 0}, {Delay= 0.25, Frame= 1}, {Delay= 0.25, Frame= 2}, {Delay= 0.25, Frame= 3}},
		OnCommand=cmd(x,880;y,180;spin;effectmagnitude,0,90,0;addx,WDX2;effectclock,"beat")
	};
		Def.Sprite{
		Texture = "2 4x1.png", 
		Frames = {{Delay= 0.25, Frame= 0}, {Delay= 0.25, Frame= 1}, {Delay= 0.25, Frame= 2}, {Delay= 0.25, Frame= 3}},
		OnCommand=cmd(x,80;y,300;spin;effectmagnitude,0,90,0;addx,WDX2;effectclock,"beat")
	};
		Def.Sprite{
		Texture = "2 4x1.png", 
		Frames = {{Delay= 0.25, Frame= 0}, {Delay= 0.25, Frame= 1}, {Delay= 0.25, Frame= 2}, {Delay= 0.25, Frame= 3}},
		OnCommand=cmd(x,240;y,300;spin;effectmagnitude,0,90,0;addx,WDX2;effectclock,"beat")
	};
		Def.Sprite{
		Texture = "2 4x1.png", 
		Frames = {{Delay= 0.25, Frame= 0}, {Delay= 0.25, Frame= 1}, {Delay= 0.25, Frame= 2}, {Delay= 0.25, Frame= 3}},
		OnCommand=cmd(x,400;y,300;spin;effectmagnitude,0,90,0;addx,WDX2;effectclock,"beat")
	};
		Def.Sprite{
		Texture = "2 4x1.png", 
		Frames = {{Delay= 0.25, Frame= 0}, {Delay= 0.25, Frame= 1}, {Delay= 0.25, Frame= 2}, {Delay= 0.25, Frame= 3}},
		OnCommand=cmd(x,560;y,300;spin;effectmagnitude,0,90,0;addx,WDX2;effectclock,"beat")
	};
		Def.Sprite{
		Texture = "2 4x1.png", 
		Frames = {{Delay= 0.25, Frame= 0}, {Delay= 0.25, Frame= 1}, {Delay= 0.25, Frame= 2}, {Delay= 0.25, Frame= 3}},
		OnCommand=cmd(x,720;y,300;spin;effectmagnitude,0,90,0;addx,WDX2;effectclock,"beat")
	};
		Def.Sprite{
		Texture = "2 4x1.png", 
		Frames = {{Delay= 0.25, Frame= 0}, {Delay= 0.25, Frame= 1}, {Delay= 0.25, Frame= 2}, {Delay= 0.25, Frame= 3}},
		OnCommand=cmd(x,880;y,300;spin;effectmagnitude,0,90,0;addx,WDX2;effectclock,"beat")
	};
		Def.Sprite{
		Texture = "2 4x1.png", 
		Frames = {{Delay= 0.25, Frame= 0}, {Delay= 0.25, Frame= 1}, {Delay= 0.25, Frame= 2}, {Delay= 0.25, Frame= 3}},
		OnCommand=cmd(x,80;y,420;spin;effectmagnitude,0,90,0;addx,WDX2;effectclock,"beat")
	};
		Def.Sprite{
		Texture = "2 4x1.png", 
		Frames = {{Delay= 0.25, Frame= 0}, {Delay= 0.25, Frame= 1}, {Delay= 0.25, Frame= 2}, {Delay= 0.25, Frame= 3}},
		OnCommand=cmd(x,240;y,420;spin;effectmagnitude,0,90,0;addx,WDX2;effectclock,"beat")
	};
		Def.Sprite{
		Texture = "2 4x1.png", 
		Frames = {{Delay= 0.25, Frame= 0}, {Delay= 0.25, Frame= 1}, {Delay= 0.25, Frame= 2}, {Delay= 0.25, Frame= 3}},
		OnCommand=cmd(x,400;y,420;spin;effectmagnitude,0,90,0;addx,WDX2;effectclock,"beat")
	};
		Def.Sprite{
		Texture = "2 4x1.png", 
		Frames = {{Delay= 0.25, Frame= 0}, {Delay= 0.25, Frame= 1}, {Delay= 0.25, Frame= 2}, {Delay= 0.25, Frame= 3}},
		OnCommand=cmd(x,560;y,420;spin;effectmagnitude,0,90,0;addx,WDX2;effectclock,"beat")
	};
		Def.Sprite{
		Texture = "2 4x1.png", 
		Frames = {{Delay= 0.25, Frame= 0}, {Delay= 0.25, Frame= 1}, {Delay= 0.25, Frame= 2}, {Delay= 0.25, Frame= 3}},
		OnCommand=cmd(x,720;y,420;spin;effectmagnitude,0,90,0;addx,WDX2;effectclock,"beat")
	};
		Def.Sprite{
		Texture = "2 4x1.png", 
		Frames = {{Delay= 0.25, Frame= 0}, {Delay= 0.25, Frame= 1}, {Delay= 0.25, Frame= 2}, {Delay= 0.25, Frame= 3}},
		OnCommand=cmd(x,880;y,420;spin;effectmagnitude,0,90,0;addx,WDX2;effectclock,"beat")
	};
}
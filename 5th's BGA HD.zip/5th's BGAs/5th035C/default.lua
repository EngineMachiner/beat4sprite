return Def.ActorFrame{
	LoseFocusCommand=function(self)
		self:RunCommandsOnChildren(function(child) child:visible(false):finishtweening() end, {})
	end,
	LoadActor("1 (stretch).png")..{
		OnCommand=cmd(Center;zoom,10;rainbow;set_use_effect_clock_for_texcoords,true;texcoordvelocity,0.095,0.095;customtexturerect,0,0,10,10;effectperiod,8;effectclock,'beat')
	};
		LoadActor("../Sprites/Line/005", "2 Star 2x1.png")..{
		OnCommand=function(self)
			self:effectclock('beat')
		end
	},
}
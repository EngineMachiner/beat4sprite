local WDX2 if SCREEN_WIDTH > 640 then WDX2 = -80/1.5 else WDX2 = 0 end;
local t = Def.ActorFrame{
		Def.Sprite{
		Texture = "1 1x2.png", 
		Frames = {{Delay= 1, Frame= 0}, {Delay= 1, Frame= 1}},
		OnCommand=cmd(x,320;y,60;addx,WDX2;effectclock,'beat')
	};
		Def.Sprite{
		Texture = "1 1x2.png", 
		Frames = {{Delay= 1, Frame= 0}, {Delay= 1, Frame= 1}},
		OnCommand=cmd(x,960;y,60;addx,WDX2;effectclock,'beat')
	};
		Def.Sprite{
		Texture = "1 1x2.png", 
		Frames = {{Delay= 1, Frame= 0}, {Delay= 1, Frame= 1}},
		OnCommand=cmd(x,320;y,180;addx,WDX2;effectclock,'beat')
	};
		Def.Sprite{
		Texture = "1 1x2.png", 
		Frames = {{Delay= 1, Frame= 0}, {Delay= 1, Frame= 1}},
		OnCommand=cmd(x,960;y,180;addx,WDX2;effectclock,'beat')
	};
		Def.Sprite{
		Texture = "1 1x2.png", 
		Frames = {{Delay= 1, Frame= 0}, {Delay= 1, Frame= 1}},
		OnCommand=cmd(x,320;y,300;addx,WDX2;effectclock,'beat')
	};
		Def.Sprite{
		Texture = "1 1x2.png", 
		Frames = {{Delay= 1, Frame= 0}, {Delay= 1, Frame= 1}},
		OnCommand=cmd(x,960;y,300;addx,WDX2;effectclock,'beat')
	};
		Def.Sprite{
		Texture = "1 1x2.png", 
		Frames = {{Delay= 1, Frame= 0}, {Delay= 1, Frame= 1}},
		OnCommand=cmd(x,320;y,420;addx,WDX2;effectclock,'beat')
	};
		Def.Sprite{
		Texture = "1 1x2.png", 
		Frames = {{Delay= 1, Frame= 0}, {Delay= 1, Frame= 1}},
		OnCommand=cmd(x,960;y,420;addx,WDX2;effectclock,'beat')
	};
		Def.Sprite{
		Texture = "1 1x2.png", 
		Frames = {{Delay= 1, Frame= 0}, {Delay= 1, Frame= 1}},
		OnCommand=cmd(x,320;y,540;addx,WDX2;effectclock,'beat')
	};
		Def.Sprite{
		Texture = "1 1x2.png", 
		Frames = {{Delay= 1, Frame= 0}, {Delay= 1, Frame= 1}},
		OnCommand=cmd(x,960;y,540;addx,WDX2;effectclock,'beat')
	};
};

return t;
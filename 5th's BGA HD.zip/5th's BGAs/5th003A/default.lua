local WDX2 if SCREEN_WIDTH > 640 then WDX2 = -80/1.5 else WDX2 = 0 end;
local t = Def.ActorFrame{
	LoadActor("1.png")..{
		OnCommand=cmd(Center;SetSize,640,480)
	};
	LoadActor("1.png")..{
		OnCommand=cmd(Center;SetSize,640,480;addx,640;zoomx,-1)
	};
	LoadActor("1.png")..{
		OnCommand=cmd(Center;SetSize,640,480;addx,-640;zoomx,-1)
	};
		Def.Sprite{
		Texture = "2 4x4.png", 
		Frames = {{Delay= 0.125/2, Frame= 1}, {Delay= 0.125/2, Frame= 2}, {Delay= 0.125/2, Frame= 3}, {Delay= 0.125/2, Frame= 4}, {Delay= 0.125/2, Frame= 5}, {Delay= 0.125/2, Frame= 6}, {Delay= 0.125/2, Frame= 7}, {Delay= 0.125/2, Frame= 8}, {Delay= 0.125/2, Frame= 9}, {Delay= 0.125/2, Frame= 10}, {Delay= 0.125/2, Frame= 11}, {Delay= 0.125/2, Frame= 12}, {Delay= 0.125/2, Frame= 13}, {Delay= 0.125/2, Frame= 14}, {Delay= 0.125/2, Frame= 15}, {Delay= 0.125/2, Frame= 0}},
		OnCommand=cmd(x,80;y,60;addx,WDX2;effectclock,'beat')
	};
		Def.Sprite{
		Texture = "2 4x4.png", 
		Frames = {{Delay= 0.125/2, Frame= 0}, {Delay= 0.125/2, Frame= 1}, {Delay= 0.125/2, Frame= 2}, {Delay= 0.125/2, Frame= 3}, {Delay= 0.125/2, Frame= 4}, {Delay= 0.125/2, Frame= 5}, {Delay= 0.125/2, Frame= 6}, {Delay= 0.125/2, Frame= 7}, {Delay= 0.125/2, Frame= 8}, {Delay= 0.125/2, Frame= 9}, {Delay= 0.125/2, Frame= 10}, {Delay= 0.125/2, Frame= 11}, {Delay= 0.125/2, Frame= 12}, {Delay= 0.125/2, Frame= 13}, {Delay= 0.125/2, Frame= 14}, {Delay= 0.125/2, Frame= 15}},
		OnCommand=cmd(x,240;y,60;addx,WDX2;effectclock,'beat')
	};
		Def.Sprite{
		Texture = "2 4x4.png", 
		Frames = {{Delay= 0.125/2, Frame= 2}, {Delay= 0.125/2, Frame= 3}, {Delay= 0.125/2, Frame= 4}, {Delay= 0.125/2, Frame= 5}, {Delay= 0.125/2, Frame= 6}, {Delay= 0.125/2, Frame= 7}, {Delay= 0.125/2, Frame= 8}, {Delay= 0.125/2, Frame= 9}, {Delay= 0.125/2, Frame= 10}, {Delay= 0.125/2, Frame= 11}, {Delay= 0.125/2, Frame= 12}, {Delay= 0.125/2, Frame= 13}, {Delay= 0.125/2, Frame= 14}, {Delay= 0.125/2, Frame= 15}, {Delay= 0.125/2, Frame= 0}, {Delay= 0.125/2, Frame= 1}},
		OnCommand=cmd(x,400;y,60;addx,WDX2;effectclock,'beat')
	};
		Def.Sprite{
		Texture = "2 4x4.png", 
		Frames = {{Delay= 0.125/2, Frame= 3}, {Delay= 0.125/2, Frame= 4}, {Delay= 0.125/2, Frame= 5}, {Delay= 0.125/2, Frame= 6}, {Delay= 0.125/2, Frame= 7}, {Delay= 0.125/2, Frame= 8}, {Delay= 0.125/2, Frame= 9}, {Delay= 0.125/2, Frame= 10}, {Delay= 0.125/2, Frame= 11}, {Delay= 0.125/2, Frame= 12}, {Delay= 0.125/2, Frame= 13}, {Delay= 0.125/2, Frame= 14}, {Delay= 0.125/2, Frame= 15}, {Delay= 0.125/2, Frame= 0}, {Delay= 0.125/2, Frame= 1}, {Delay= 0.125/2, Frame= 2}},
		OnCommand=cmd(x,560;y,60;addx,WDX2;effectclock,'beat')
	};
		Def.Sprite{
		Texture = "2 4x4.png", 
		Frames = {{Delay= 0.125/2, Frame= 4}, {Delay= 0.125/2, Frame= 5}, {Delay= 0.125/2, Frame= 6}, {Delay= 0.125/2, Frame= 7}, {Delay= 0.125/2, Frame= 8}, {Delay= 0.125/2, Frame= 9}, {Delay= 0.125/2, Frame= 10}, {Delay= 0.125/2, Frame= 11}, {Delay= 0.125/2, Frame= 12}, {Delay= 0.125/2, Frame= 13}, {Delay= 0.125/2, Frame= 14}, {Delay= 0.125/2, Frame= 15}, {Delay= 0.125/2, Frame= 0}, {Delay= 0.125/2, Frame= 1}, {Delay= 0.125/2, Frame= 2}, {Delay= 0.125/2, Frame= 3}},
		OnCommand=cmd(x,720;y,60;addx,WDX2;effectclock,'beat')
	};
		Def.Sprite{
		Texture = "2 4x4.png", 
		Frames = {{Delay= 0.125/2, Frame= 1}, {Delay= 0.125/2, Frame= 2}, {Delay= 0.125/2, Frame= 3}, {Delay= 0.125/2, Frame= 4}, {Delay= 0.125/2, Frame= 5}, {Delay= 0.125/2, Frame= 6}, {Delay= 0.125/2, Frame= 7}, {Delay= 0.125/2, Frame= 8}, {Delay= 0.125/2, Frame= 9}, {Delay= 0.125/2, Frame= 10}, {Delay= 0.125/2, Frame= 11}, {Delay= 0.125/2, Frame= 12}, {Delay= 0.125/2, Frame= 13}, {Delay= 0.125/2, Frame= 14}, {Delay= 0.125/2, Frame= 15}, {Delay= 0.125/2, Frame= 0}},
		OnCommand=cmd(x,880;y,60;addx,WDX2;effectclock,'beat')
	};
		Def.Sprite{
		Texture = "2 4x4.png", 
		Frames = {{Delay= 0.125/2, Frame= 1}, {Delay= 0.125/2, Frame= 2}, {Delay= 0.125/2, Frame= 3}, {Delay= 0.125/2, Frame= 4}, {Delay= 0.125/2, Frame= 5}, {Delay= 0.125/2, Frame= 6}, {Delay= 0.125/2, Frame= 7}, {Delay= 0.125/2, Frame= 8}, {Delay= 0.125/2, Frame= 9}, {Delay= 0.125/2, Frame= 10}, {Delay= 0.125/2, Frame= 11}, {Delay= 0.125/2, Frame= 12}, {Delay= 0.125/2, Frame= 13}, {Delay= 0.125/2, Frame= 14}, {Delay= 0.125/2, Frame= 15}, {Delay= 0.125/2, Frame= 0}},
		OnCommand=cmd(x,80;y,180;addx,WDX2;effectclock,'beat')
	};
		Def.Sprite{
		Texture = "2 4x4.png", 
		Frames = {{Delay= 0.125/2, Frame= 0}, {Delay= 0.125/2, Frame= 1}, {Delay= 0.125/2, Frame= 2}, {Delay= 0.125/2, Frame= 3}, {Delay= 0.125/2, Frame= 4}, {Delay= 0.125/2, Frame= 5}, {Delay= 0.125/2, Frame= 6}, {Delay= 0.125/2, Frame= 7}, {Delay= 0.125/2, Frame= 8}, {Delay= 0.125/2, Frame= 9}, {Delay= 0.125/2, Frame= 10}, {Delay= 0.125/2, Frame= 11}, {Delay= 0.125/2, Frame= 12}, {Delay= 0.125/2, Frame= 13}, {Delay= 0.125/2, Frame= 14}, {Delay= 0.125/2, Frame= 15}},
		OnCommand=cmd(x,240;y,180;addx,WDX2;effectclock,'beat')
	};
		Def.Sprite{
		Texture = "2 4x4.png", 
		Frames = {{Delay= 0.125/2, Frame= 2}, {Delay= 0.125/2, Frame= 3}, {Delay= 0.125/2, Frame= 4}, {Delay= 0.125/2, Frame= 5}, {Delay= 0.125/2, Frame= 6}, {Delay= 0.125/2, Frame= 7}, {Delay= 0.125/2, Frame= 8}, {Delay= 0.125/2, Frame= 9}, {Delay= 0.125/2, Frame= 10}, {Delay= 0.125/2, Frame= 11}, {Delay= 0.125/2, Frame= 12}, {Delay= 0.125/2, Frame= 13}, {Delay= 0.125/2, Frame= 14}, {Delay= 0.125/2, Frame= 15}, {Delay= 0.125/2, Frame= 0}, {Delay= 0.125/2, Frame= 1}},
		OnCommand=cmd(x,400;y,180;addx,WDX2;effectclock,'beat')
	};
		Def.Sprite{
		Texture = "2 4x4.png", 
		Frames = {{Delay= 0.125/2, Frame= 3}, {Delay= 0.125/2, Frame= 4}, {Delay= 0.125/2, Frame= 5}, {Delay= 0.125/2, Frame= 6}, {Delay= 0.125/2, Frame= 7}, {Delay= 0.125/2, Frame= 8}, {Delay= 0.125/2, Frame= 9}, {Delay= 0.125/2, Frame= 10}, {Delay= 0.125/2, Frame= 11}, {Delay= 0.125/2, Frame= 12}, {Delay= 0.125/2, Frame= 13}, {Delay= 0.125/2, Frame= 14}, {Delay= 0.125/2, Frame= 15}, {Delay= 0.125/2, Frame= 0}, {Delay= 0.125/2, Frame= 1}, {Delay= 0.125/2, Frame= 2}},
		OnCommand=cmd(x,560;y,180;addx,WDX2;effectclock,'beat')
	};
		Def.Sprite{
		Texture = "2 4x4.png", 
		Frames = {{Delay= 0.125/2, Frame= 4}, {Delay= 0.125/2, Frame= 5}, {Delay= 0.125/2, Frame= 6}, {Delay= 0.125/2, Frame= 7}, {Delay= 0.125/2, Frame= 8}, {Delay= 0.125/2, Frame= 9}, {Delay= 0.125/2, Frame= 10}, {Delay= 0.125/2, Frame= 11}, {Delay= 0.125/2, Frame= 12}, {Delay= 0.125/2, Frame= 13}, {Delay= 0.125/2, Frame= 14}, {Delay= 0.125/2, Frame= 15}, {Delay= 0.125/2, Frame= 0}, {Delay= 0.125/2, Frame= 1}, {Delay= 0.125/2, Frame= 2}, {Delay= 0.125/2, Frame= 3}},
		OnCommand=cmd(x,720;y,180;addx,WDX2;effectclock,'beat')
	};
		Def.Sprite{
		Texture = "2 4x4.png", 
		Frames = {{Delay= 0.125/2, Frame= 1}, {Delay= 0.125/2, Frame= 2}, {Delay= 0.125/2, Frame= 3}, {Delay= 0.125/2, Frame= 4}, {Delay= 0.125/2, Frame= 5}, {Delay= 0.125/2, Frame= 6}, {Delay= 0.125/2, Frame= 7}, {Delay= 0.125/2, Frame= 8}, {Delay= 0.125/2, Frame= 9}, {Delay= 0.125/2, Frame= 10}, {Delay= 0.125/2, Frame= 11}, {Delay= 0.125/2, Frame= 12}, {Delay= 0.125/2, Frame= 13}, {Delay= 0.125/2, Frame= 14}, {Delay= 0.125/2, Frame= 15}, {Delay= 0.125/2, Frame= 0}},
		OnCommand=cmd(x,880;y,180;addx,WDX2;effectclock,'beat')
	};
		Def.Sprite{
		Texture = "2 4x4.png", 
		Frames = {{Delay= 0.125/2, Frame= 1}, {Delay= 0.125/2, Frame= 2}, {Delay= 0.125/2, Frame= 3}, {Delay= 0.125/2, Frame= 4}, {Delay= 0.125/2, Frame= 5}, {Delay= 0.125/2, Frame= 6}, {Delay= 0.125/2, Frame= 7}, {Delay= 0.125/2, Frame= 8}, {Delay= 0.125/2, Frame= 9}, {Delay= 0.125/2, Frame= 10}, {Delay= 0.125/2, Frame= 11}, {Delay= 0.125/2, Frame= 12}, {Delay= 0.125/2, Frame= 13}, {Delay= 0.125/2, Frame= 14}, {Delay= 0.125/2, Frame= 15}, {Delay= 0.125/2, Frame= 0}},
		OnCommand=cmd(x,80;y,300;addx,WDX2;effectclock,'beat')
	};
		Def.Sprite{
		Texture = "2 4x4.png", 
		Frames = {{Delay= 0.125/2, Frame= 0}, {Delay= 0.125/2, Frame= 1}, {Delay= 0.125/2, Frame= 2}, {Delay= 0.125/2, Frame= 3}, {Delay= 0.125/2, Frame= 4}, {Delay= 0.125/2, Frame= 5}, {Delay= 0.125/2, Frame= 6}, {Delay= 0.125/2, Frame= 7}, {Delay= 0.125/2, Frame= 8}, {Delay= 0.125/2, Frame= 9}, {Delay= 0.125/2, Frame= 10}, {Delay= 0.125/2, Frame= 11}, {Delay= 0.125/2, Frame= 12}, {Delay= 0.125/2, Frame= 13}, {Delay= 0.125/2, Frame= 14}, {Delay= 0.125/2, Frame= 15}},
		OnCommand=cmd(x,240;y,300;addx,WDX2;effectclock,'beat')
	};
		Def.Sprite{
		Texture = "2 4x4.png", 
		Frames = {{Delay= 0.125/2, Frame= 2}, {Delay= 0.125/2, Frame= 3}, {Delay= 0.125/2, Frame= 4}, {Delay= 0.125/2, Frame= 5}, {Delay= 0.125/2, Frame= 6}, {Delay= 0.125/2, Frame= 7}, {Delay= 0.125/2, Frame= 8}, {Delay= 0.125/2, Frame= 9}, {Delay= 0.125/2, Frame= 10}, {Delay= 0.125/2, Frame= 11}, {Delay= 0.125/2, Frame= 12}, {Delay= 0.125/2, Frame= 13}, {Delay= 0.125/2, Frame= 14}, {Delay= 0.125/2, Frame= 15}, {Delay= 0.125/2, Frame= 0}, {Delay= 0.125/2, Frame= 1}},
		OnCommand=cmd(x,400;y,300;addx,WDX2;effectclock,'beat')
	};
		Def.Sprite{
		Texture = "2 4x4.png", 
		Frames = {{Delay= 0.125/2, Frame= 3}, {Delay= 0.125/2, Frame= 4}, {Delay= 0.125/2, Frame= 5}, {Delay= 0.125/2, Frame= 6}, {Delay= 0.125/2, Frame= 7}, {Delay= 0.125/2, Frame= 8}, {Delay= 0.125/2, Frame= 9}, {Delay= 0.125/2, Frame= 10}, {Delay= 0.125/2, Frame= 11}, {Delay= 0.125/2, Frame= 12}, {Delay= 0.125/2, Frame= 13}, {Delay= 0.125/2, Frame= 14}, {Delay= 0.125/2, Frame= 15}, {Delay= 0.125/2, Frame= 0}, {Delay= 0.125/2, Frame= 1}, {Delay= 0.125/2, Frame= 2}},
		OnCommand=cmd(x,560;y,300;addx,WDX2;effectclock,'beat')
	};
		Def.Sprite{
		Texture = "2 4x4.png", 
		Frames = {{Delay= 0.125/2, Frame= 4}, {Delay= 0.125/2, Frame= 5}, {Delay= 0.125/2, Frame= 6}, {Delay= 0.125/2, Frame= 7}, {Delay= 0.125/2, Frame= 8}, {Delay= 0.125/2, Frame= 9}, {Delay= 0.125/2, Frame= 10}, {Delay= 0.125/2, Frame= 11}, {Delay= 0.125/2, Frame= 12}, {Delay= 0.125/2, Frame= 13}, {Delay= 0.125/2, Frame= 14}, {Delay= 0.125/2, Frame= 15}, {Delay= 0.125/2, Frame= 0}, {Delay= 0.125/2, Frame= 1}, {Delay= 0.125/2, Frame= 2}, {Delay= 0.125/2, Frame= 3}},
		OnCommand=cmd(x,720;y,300;addx,WDX2;effectclock,'beat')
	};
		Def.Sprite{
		Texture = "2 4x4.png", 
		Frames = {{Delay= 0.125/2, Frame= 1}, {Delay= 0.125/2, Frame= 2}, {Delay= 0.125/2, Frame= 3}, {Delay= 0.125/2, Frame= 4}, {Delay= 0.125/2, Frame= 5}, {Delay= 0.125/2, Frame= 6}, {Delay= 0.125/2, Frame= 7}, {Delay= 0.125/2, Frame= 8}, {Delay= 0.125/2, Frame= 9}, {Delay= 0.125/2, Frame= 10}, {Delay= 0.125/2, Frame= 11}, {Delay= 0.125/2, Frame= 12}, {Delay= 0.125/2, Frame= 13}, {Delay= 0.125/2, Frame= 14}, {Delay= 0.125/2, Frame= 15}, {Delay= 0.125/2, Frame= 0}},
		OnCommand=cmd(x,880;y,300;addx,WDX2;effectclock,'beat')
	};
		Def.Sprite{
		Texture = "2 4x4.png", 
		Frames = {{Delay= 0.125/2, Frame= 1}, {Delay= 0.125/2, Frame= 2}, {Delay= 0.125/2, Frame= 3}, {Delay= 0.125/2, Frame= 4}, {Delay= 0.125/2, Frame= 5}, {Delay= 0.125/2, Frame= 6}, {Delay= 0.125/2, Frame= 7}, {Delay= 0.125/2, Frame= 8}, {Delay= 0.125/2, Frame= 9}, {Delay= 0.125/2, Frame= 10}, {Delay= 0.125/2, Frame= 11}, {Delay= 0.125/2, Frame= 12}, {Delay= 0.125/2, Frame= 13}, {Delay= 0.125/2, Frame= 14}, {Delay= 0.125/2, Frame= 15}, {Delay= 0.125/2, Frame= 0}},
		OnCommand=cmd(x,80;y,420;addx,WDX2;effectclock,'beat')
	};
		Def.Sprite{
		Texture = "2 4x4.png", 
		Frames = {{Delay= 0.125/2, Frame= 0}, {Delay= 0.125/2, Frame= 1}, {Delay= 0.125/2, Frame= 2}, {Delay= 0.125/2, Frame= 3}, {Delay= 0.125/2, Frame= 4}, {Delay= 0.125/2, Frame= 5}, {Delay= 0.125/2, Frame= 6}, {Delay= 0.125/2, Frame= 7}, {Delay= 0.125/2, Frame= 8}, {Delay= 0.125/2, Frame= 9}, {Delay= 0.125/2, Frame= 10}, {Delay= 0.125/2, Frame= 11}, {Delay= 0.125/2, Frame= 12}, {Delay= 0.125/2, Frame= 13}, {Delay= 0.125/2, Frame= 14}, {Delay= 0.125/2, Frame= 15}},
		OnCommand=cmd(x,240;y,420;addx,WDX2;effectclock,'beat')
	};
		Def.Sprite{
		Texture = "2 4x4.png", 
		Frames = {{Delay= 0.125/2, Frame= 2}, {Delay= 0.125/2, Frame= 3}, {Delay= 0.125/2, Frame= 4}, {Delay= 0.125/2, Frame= 5}, {Delay= 0.125/2, Frame= 6}, {Delay= 0.125/2, Frame= 7}, {Delay= 0.125/2, Frame= 8}, {Delay= 0.125/2, Frame= 9}, {Delay= 0.125/2, Frame= 10}, {Delay= 0.125/2, Frame= 11}, {Delay= 0.125/2, Frame= 12}, {Delay= 0.125/2, Frame= 13}, {Delay= 0.125/2, Frame= 14}, {Delay= 0.125/2, Frame= 15}, {Delay= 0.125/2, Frame= 0}, {Delay= 0.125/2, Frame= 1}},
		OnCommand=cmd(x,400;y,420;addx,WDX2;effectclock,'beat')
	};
		Def.Sprite{
		Texture = "2 4x4.png", 
		Frames = {{Delay= 0.125/2, Frame= 3}, {Delay= 0.125/2, Frame= 4}, {Delay= 0.125/2, Frame= 5}, {Delay= 0.125/2, Frame= 6}, {Delay= 0.125/2, Frame= 7}, {Delay= 0.125/2, Frame= 8}, {Delay= 0.125/2, Frame= 9}, {Delay= 0.125/2, Frame= 10}, {Delay= 0.125/2, Frame= 11}, {Delay= 0.125/2, Frame= 12}, {Delay= 0.125/2, Frame= 13}, {Delay= 0.125/2, Frame= 14}, {Delay= 0.125/2, Frame= 15}, {Delay= 0.125/2, Frame= 0}, {Delay= 0.125/2, Frame= 1}, {Delay= 0.125/2, Frame= 2}},
		OnCommand=cmd(x,560;y,420;addx,WDX2;effectclock,'beat')
	};
		Def.Sprite{
		Texture = "2 4x4.png", 
		Frames = {{Delay= 0.125/2, Frame= 4}, {Delay= 0.125/2, Frame= 5}, {Delay= 0.125/2, Frame= 6}, {Delay= 0.125/2, Frame= 7}, {Delay= 0.125/2, Frame= 8}, {Delay= 0.125/2, Frame= 9}, {Delay= 0.125/2, Frame= 10}, {Delay= 0.125/2, Frame= 11}, {Delay= 0.125/2, Frame= 12}, {Delay= 0.125/2, Frame= 13}, {Delay= 0.125/2, Frame= 14}, {Delay= 0.125/2, Frame= 15}, {Delay= 0.125/2, Frame= 0}, {Delay= 0.125/2, Frame= 1}, {Delay= 0.125/2, Frame= 2}, {Delay= 0.125/2, Frame= 3}},
		OnCommand=cmd(x,720;y,420;addx,WDX2;effectclock,'beat')
	};
		Def.Sprite{
		Texture = "2 4x4.png", 
		Frames = {{Delay= 0.125/2, Frame= 1}, {Delay= 0.125/2, Frame= 2}, {Delay= 0.125/2, Frame= 3}, {Delay= 0.125/2, Frame= 4}, {Delay= 0.125/2, Frame= 5}, {Delay= 0.125/2, Frame= 6}, {Delay= 0.125/2, Frame= 7}, {Delay= 0.125/2, Frame= 8}, {Delay= 0.125/2, Frame= 9}, {Delay= 0.125/2, Frame= 10}, {Delay= 0.125/2, Frame= 11}, {Delay= 0.125/2, Frame= 12}, {Delay= 0.125/2, Frame= 13}, {Delay= 0.125/2, Frame= 14}, {Delay= 0.125/2, Frame= 15}, {Delay= 0.125/2, Frame= 0}},
		OnCommand=cmd(x,880;y,420;addx,WDX2;effectclock,'beat')
	};
};

return t;
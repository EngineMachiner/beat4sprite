return Def.ActorFrame{

	LoseFocusCommand=function(self)
		self:RunCommandsOnChildren(function(child) child:visible(false):finishtweening() end, {})
	end,
		Def.Sprite{
		Texture = "1 2x1.png", 
		Frames = {{Delay= 0.25, Frame= 0}, {Delay= 0.25, Frame= 1}},
		OnCommand=cmd(x,80;y,60)
	};
		Def.Sprite{
		Texture = "1 2x1.png", 
		Frames = {{Delay= 0.25, Frame= 0}, {Delay= 0.25, Frame= 1}},
		OnCommand=cmd(x,240;y,60)
	};
		Def.Sprite{
		Texture = "1 2x1.png", 
		Frames = {{Delay= 0.25, Frame= 0}, {Delay= 0.25, Frame= 1}},
		OnCommand=cmd(x,400;y,60)
	};
		Def.Sprite{
		Texture = "1 2x1.png", 
		Frames = {{Delay= 0.25, Frame= 0}, {Delay= 0.25, Frame= 1}},
		OnCommand=cmd(x,560;y,60)
	};
		Def.Sprite{
		Texture = "1 2x1.png", 
		Frames = {{Delay= 0.25, Frame= 0}, {Delay= 0.25, Frame= 1}},
		OnCommand=cmd(x,720;y,60)
	};
		Def.Sprite{
		Texture = "1 2x1.png", 
		Frames = {{Delay= 0.25, Frame= 0}, {Delay= 0.25, Frame= 1}},
		OnCommand=cmd(x,880;y,60)
	};
		Def.Sprite{
		Texture = "1 2x1.png", 
		Frames = {{Delay= 0.25, Frame= 0}, {Delay= 0.25, Frame= 1}},
		OnCommand=cmd(x,80;y,180)
	};
		Def.Sprite{
		Texture = "1 2x1.png", 
		Frames = {{Delay= 0.25, Frame= 0}, {Delay= 0.25, Frame= 1}},
		OnCommand=cmd(x,240;y,180)
	};
		Def.Sprite{
		Texture = "1 2x1.png", 
		Frames = {{Delay= 0.25, Frame= 0}, {Delay= 0.25, Frame= 1}},
		OnCommand=cmd(x,400;y,180)
	};
		Def.Sprite{
		Texture = "1 2x1.png", 
		Frames = {{Delay= 0.25, Frame= 0}, {Delay= 0.25, Frame= 1}},
		OnCommand=cmd(x,560;y,180)
	};
		Def.Sprite{
		Texture = "1 2x1.png", 
		Frames = {{Delay= 0.25, Frame= 0}, {Delay= 0.25, Frame= 1}},
		OnCommand=cmd(x,720;y,180)
	};
		Def.Sprite{
		Texture = "1 2x1.png", 
		Frames = {{Delay= 0.25, Frame= 0}, {Delay= 0.25, Frame= 1}},
		OnCommand=cmd(x,880;y,180)
	};
		Def.Sprite{
		Texture = "1 2x1.png", 
		Frames = {{Delay= 0.25, Frame= 0}, {Delay= 0.25, Frame= 1}},
		OnCommand=cmd(x,80;y,300)
	};
		Def.Sprite{
		Texture = "1 2x1.png", 
		Frames = {{Delay= 0.25, Frame= 0}, {Delay= 0.25, Frame= 1}},
		OnCommand=cmd(x,240;y,300)
	};
		Def.Sprite{
		Texture = "1 2x1.png", 
		Frames = {{Delay= 0.25, Frame= 0}, {Delay= 0.25, Frame= 1}},
		OnCommand=cmd(x,400;y,300)
	};
		Def.Sprite{
		Texture = "1 2x1.png", 
		Frames = {{Delay= 0.25, Frame= 0}, {Delay= 0.25, Frame= 1}},
		OnCommand=cmd(x,560;y,300)
	};
		Def.Sprite{
		Texture = "1 2x1.png", 
		Frames = {{Delay= 0.25, Frame= 0}, {Delay= 0.25, Frame= 1}},
		OnCommand=cmd(x,720;y,300)
	};
		Def.Sprite{
		Texture = "1 2x1.png", 
		Frames = {{Delay= 0.25, Frame= 0}, {Delay= 0.25, Frame= 1}},
		OnCommand=cmd(x,880;y,300)
	};
		Def.Sprite{
		Texture = "1 2x1.png", 
		Frames = {{Delay= 0.25, Frame= 0}, {Delay= 0.25, Frame= 1}},
		OnCommand=cmd(x,80;y,420)
	};
		Def.Sprite{
		Texture = "1 2x1.png", 
		Frames = {{Delay= 0.25, Frame= 0}, {Delay= 0.25, Frame= 1}},
		OnCommand=cmd(x,240;y,420)
	};
		Def.Sprite{
		Texture = "1 2x1.png", 
		Frames = {{Delay= 0.25, Frame= 0}, {Delay= 0.25, Frame= 1}},
		OnCommand=cmd(x,400;y,420)
	};
		Def.Sprite{
		Texture = "1 2x1.png", 
		Frames = {{Delay= 0.25, Frame= 0}, {Delay= 0.25, Frame= 1}},
		OnCommand=cmd(x,560;y,420)
	};
		Def.Sprite{
		Texture = "1 2x1.png", 
		Frames = {{Delay= 0.25, Frame= 0}, {Delay= 0.25, Frame= 1}},
		OnCommand=cmd(x,720;y,420)
	};
		Def.Sprite{
		Texture = "1 2x1.png", 
		Frames = {{Delay= 0.25, Frame= 0}, {Delay= 0.25, Frame= 1}},
		OnCommand=cmd(x,880;y,420)
	};
}
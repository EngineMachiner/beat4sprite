return Def.ActorFrame{

	LoseFocusCommand=function(self)
		self:RunCommandsOnChildren(function(child) child:visible(false):finishtweening() end, {})
	end,
	
	LoadActor("B.lua")..{
		OnCommand=cmd(x,160*2;linear,8;x,0;set_tween_uses_effect_delta,true;effectclock,"beat";queuecommand,"On")
	};
	LoadActor("B.lua")..{
		OnCommand=cmd(x,0;linear,8;x,-160*2;set_tween_uses_effect_delta,true;effectclock,"beat";queuecommand,"On")
	};
}
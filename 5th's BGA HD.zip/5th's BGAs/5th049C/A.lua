local WDX2 if SCREEN_WIDTH > 640 then WDX2 = -80/1.5 else WDX2 = 0 end;
return Def.ActorFrame{
	LoseFocusCommand=function(self)
		self:RunCommandsOnChildren(function(child) child:visible(false):finishtweening() end, {})
	end,

		LoadActor("../Sprites/ParticlesDown/Static", "Circle.png")..{
		OnCommand=function(self)
			self:effectclock('beat')
			
		end
	},
	
		LoadActor("../Sprites/ParticlesDown/Static", "Circle.png")..{
		OnCommand=function(self)
			self:effectclock('beat')
			
		end
	},
	
		LoadActor("../Sprites/ParticlesDown/Static", "Circle.png")..{
		OnCommand=function(self)
			self:effectclock('beat')
			
		end
	},
	
		LoadActor("../Sprites/ParticlesDown/Static", "Circle.png")..{
		OnCommand=function(self)
			self:effectclock('beat')
			
		end
	},
	
		LoadActor("../Sprites/ParticlesDown/Static", "Circle.png")..{
		OnCommand=function(self)
			self:effectclock('beat')
			
		end
	},
	
		LoadActor("../Sprites/ParticlesDown/Static", "Circle.png")..{
		OnCommand=function(self)
			self:effectclock('beat')
			
		end
	},

		LoadActor("../Sprites/ParticlesDown/Static", "Circle.png")..{
		OnCommand=function(self)
			self:effectclock('beat')
			
		end
	},

		LoadActor("../Sprites/ParticlesDown/Static", "Circle.png")..{
		OnCommand=function(self)
			self:effectclock('beat')
			
		end
	},
	
		LoadActor("../Sprites/ParticlesDown/Static", "Circle.png")..{
		OnCommand=function(self)
			self:effectclock('beat')
			
		end
	},
	
		LoadActor("../Sprites/ParticlesDown/Static", "Circle.png")..{
		OnCommand=function(self)
			self:effectclock('beat')
			
		end
	},
	
		LoadActor("../Sprites/ParticlesDown/Static", "Circle.png")..{
		OnCommand=function(self)
			self:effectclock('beat')
			
		end
	},
	
		LoadActor("../Sprites/ParticlesDown/Static", "Circle.png")..{
		OnCommand=function(self)
			self:effectclock('beat')
			
		end
	},
	
		LoadActor("../Sprites/ParticlesDown/Static", "Circle.png")..{
		OnCommand=function(self)
			self:effectclock('beat')
			
		end
	},
	
		LoadActor("../Sprites/ParticlesDown/Static", "Circle.png")..{
		OnCommand=function(self)
			self:effectclock('beat')
			
		end
	},
	
		LoadActor("../Sprites/ParticlesDown/Static", "Circle.png")..{
		OnCommand=function(self)
			self:effectclock('beat')
			
		end
	},
}
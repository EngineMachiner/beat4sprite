local t = Def.ActorFrame{
		Def.Sprite{
		Texture = "6 (stretch).png", 
		OnCommand=cmd(Center;zoom,4;customtexturerect,0,0,4,4;diffusealpha,1;sleep,6;diffusealpha,0;set_tween_uses_effect_delta,true;effectclock,"beat";queuecommand,"On")
	};
		Def.Sprite{
		Texture = "5 (stretch).png", 
		OnCommand=cmd(Center;zoom,4;customtexturerect,0,0,4,4;diffusealpha,1;sleep,5;diffusealpha,0;sleep,1;set_tween_uses_effect_delta,true;effectclock,"beat";queuecommand,"On")
	};
		Def.Sprite{
		Texture = "4 (stretch).png", 
		OnCommand=cmd(Center;zoom,4;customtexturerect,0,0,4,4;diffusealpha,1;sleep,4;diffusealpha,0;sleep,2;set_tween_uses_effect_delta,true;effectclock,"beat";queuecommand,"On")
	};
		Def.Sprite{
		Texture = "3 (stretch).png", 
		OnCommand=cmd(Center;zoom,4;customtexturerect,0,0,4,4;diffusealpha,1;sleep,3;diffusealpha,0;sleep,3;set_tween_uses_effect_delta,true;effectclock,"beat";queuecommand,"On")
	};
		Def.Sprite{
		Texture = "2 (stretch).png", 
		OnCommand=cmd(Center;zoom,4;customtexturerect,0,0,4,4;diffusealpha,1;sleep,2;diffusealpha,0;sleep,4;set_tween_uses_effect_delta,true;effectclock,"beat";queuecommand,"On")
	};
		Def.Sprite{
		Texture = "1 (stretch).png", 
		OnCommand=cmd(Center;zoom,4;customtexturerect,0,0,4,4;diffusealpha,1;sleep,1;diffusealpha,0;sleep,5;set_tween_uses_effect_delta,true;effectclock,"beat";queuecommand,"On")
	};
};

return t;
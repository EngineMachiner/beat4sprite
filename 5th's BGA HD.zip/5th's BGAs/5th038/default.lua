return Def.ActorFrame{
	LoseFocusCommand=function(self)
		self:RunCommandsOnChildren(function(child) child:visible(false):finishtweening() end, {})
	end,

		LoadActor("A.lua")..{
		OnCommand=function(self) 
			self:effectclock('beat')
		end

	},
	
		LoadActor("A.lua")..{
		OnCommand=function(self) 
			self:effectclock('beat')
			:addx(640)
		end

	},
	
		LoadActor("A.lua")..{
		OnCommand=function(self) 
			self:effectclock('beat')
			:addx(-640)
		end

	},
	
}
local t = Def.ActorFrame{
	LoadActor("1 TileScrollDown (stretch).png")..{
		OnCommand=cmd(Center;zoom,15;customtexturerect,0,0,15,15;texcoordvelocity,-0.25-(0.25/2),-0.25-(0.25/2);set_use_effect_clock_for_texcoords,true;effectclock,'beat';rainbow;effectperiod,8)
	};
		LoadActor("../Sprites/Line/Static2", "2.png")..{
		OnCommand=function(self)
			self:effectclock('beat')
		end
	},
};

return t;
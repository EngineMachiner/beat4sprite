local WDX2 if SCREEN_WIDTH > 640 then WDX2 = -70/1.5 else WDX2 = 0 end;
local t = Def.ActorFrame{
		Def.Sprite{
		Texture = "1 2x1.png", 
		Frames = {{Delay= 1, Frame= 0}, {Delay= 1, Frame= 1}},
		OnCommand=cmd(x,77;y,60;addx,WDX2;effectclock,"beat")
	};
		Def.Sprite{
		Texture = "1 2x1.png", 
		Frames = {{Delay= 1, Frame= 0}, {Delay= 1, Frame= 1}},
		OnCommand=cmd(x,236;y,60;addx,WDX2;effectclock,"beat")
	};
		Def.Sprite{
		Texture = "1 2x1.png", 
		Frames = {{Delay= 1, Frame= 0}, {Delay= 1, Frame= 1}},
		OnCommand=cmd(x,394;y,60;addx,WDX2;effectclock,"beat")
	};
		Def.Sprite{
		Texture = "1 2x1.png", 
		Frames = {{Delay= 1, Frame= 0}, {Delay= 1, Frame= 1}},
		OnCommand=cmd(x,553;y,60;addx,WDX2;effectclock,"beat")
	};
		Def.Sprite{
		Texture = "1 2x1.png", 
		Frames = {{Delay= 1, Frame= 0}, {Delay= 1, Frame= 1}},
		OnCommand=cmd(x,711;y,60;addx,WDX2;effectclock,"beat")
	};
		Def.Sprite{
		Texture = "1 2x1.png", 
		Frames = {{Delay= 1, Frame= 0}, {Delay= 1, Frame= 1}},
		OnCommand=cmd(x,870;y,60;addx,WDX2;effectclock,"beat")
	};
		Def.Sprite{
		Texture = "1 2x1.png", 
		Frames = {{Delay= 1, Frame= 0}, {Delay= 1, Frame= 1}},
		OnCommand=cmd(x,77;y,180;addx,WDX2;effectclock,"beat")
	};
		Def.Sprite{
		Texture = "1 2x1.png", 
		Frames = {{Delay= 1, Frame= 0}, {Delay= 1, Frame= 1}},
		OnCommand=cmd(x,236;y,180;addx,WDX2;effectclock,"beat")
	};
		Def.Sprite{
		Texture = "1 2x1.png", 
		Frames = {{Delay= 1, Frame= 0}, {Delay= 1, Frame= 1}},
		OnCommand=cmd(x,394;y,180;addx,WDX2;effectclock,"beat")
	};
		Def.Sprite{
		Texture = "1 2x1.png", 
		Frames = {{Delay= 1, Frame= 0}, {Delay= 1, Frame= 1}},
		OnCommand=cmd(x,553;y,180;addx,WDX2;effectclock,"beat")
	};
		Def.Sprite{
		Texture = "1 2x1.png", 
		Frames = {{Delay= 1, Frame= 0}, {Delay= 1, Frame= 1}},
		OnCommand=cmd(x,711;y,180;addx,WDX2;effectclock,"beat")
	};
		Def.Sprite{
		Texture = "1 2x1.png", 
		Frames = {{Delay= 1, Frame= 0}, {Delay= 1, Frame= 1}},
		OnCommand=cmd(x,870;y,180;addx,WDX2;effectclock,"beat")
	};
		Def.Sprite{
		Texture = "1 2x1.png", 
		Frames = {{Delay= 1, Frame= 0}, {Delay= 1, Frame= 1}},
		OnCommand=cmd(x,77;y,300;addx,WDX2;effectclock,"beat")
	};
		Def.Sprite{
		Texture = "1 2x1.png", 
		Frames = {{Delay= 1, Frame= 0}, {Delay= 1, Frame= 1}},
		OnCommand=cmd(x,236;y,300;addx,WDX2;effectclock,"beat")
	};
		Def.Sprite{
		Texture = "1 2x1.png", 
		Frames = {{Delay= 1, Frame= 0}, {Delay= 1, Frame= 1}},
		OnCommand=cmd(x,394;y,300;addx,WDX2;effectclock,"beat")
	};
		Def.Sprite{
		Texture = "1 2x1.png", 
		Frames = {{Delay= 1, Frame= 0}, {Delay= 1, Frame= 1}},
		OnCommand=cmd(x,553;y,300;addx,WDX2;effectclock,"beat")
	};
		Def.Sprite{
		Texture = "1 2x1.png", 
		Frames = {{Delay= 1, Frame= 0}, {Delay= 1, Frame= 1}},
		OnCommand=cmd(x,711;y,300;addx,WDX2;effectclock,"beat")
	};
		Def.Sprite{
		Texture = "1 2x1.png", 
		Frames = {{Delay= 1, Frame= 0}, {Delay= 1, Frame= 1}},
		OnCommand=cmd(x,870;y,300;addx,WDX2;effectclock,"beat")
	};
		Def.Sprite{
		Texture = "1 2x1.png", 
		Frames = {{Delay= 1, Frame= 0}, {Delay= 1, Frame= 1}},
		OnCommand=cmd(x,77;y,420;addx,WDX2;effectclock,"beat")
	};
		Def.Sprite{
		Texture = "1 2x1.png", 
		Frames = {{Delay= 1, Frame= 0}, {Delay= 1, Frame= 1}},
		OnCommand=cmd(x,236;y,420;addx,WDX2;effectclock,"beat")
	};
		Def.Sprite{
		Texture = "1 2x1.png", 
		Frames = {{Delay= 1, Frame= 0}, {Delay= 1, Frame= 1}},
		OnCommand=cmd(x,394;y,420;addx,WDX2;effectclock,"beat")
	};
		Def.Sprite{
		Texture = "1 2x1.png", 
		Frames = {{Delay= 1, Frame= 0}, {Delay= 1, Frame= 1}},
		OnCommand=cmd(x,553;y,420;addx,WDX2;effectclock,"beat")
	};
		Def.Sprite{
		Texture = "1 2x1.png", 
		Frames = {{Delay= 1, Frame= 0}, {Delay= 1, Frame= 1}},
		OnCommand=cmd(x,711;y,420;addx,WDX2;effectclock,"beat")
	};
		Def.Sprite{
		Texture = "1 2x1.png", 
		Frames = {{Delay= 1, Frame= 0}, {Delay= 1, Frame= 1}},
		OnCommand=cmd(x,870;y,420;addx,WDX2;effectclock,"beat")
	};
};

return t;
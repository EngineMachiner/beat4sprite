return Def.ActorFrame{
	LoseFocusCommand=function(self)
		self:RunCommandsOnChildren(function(child) child:visible(false):finishtweening() end, {})
	end,
	LoadActor("1.lua")..{
		OnCommand=cmd(addx,128;addy,192)
	};
	LoadActor("1.lua")..{
		OnCommand=cmd(addx,128;addy,96)
	};
	LoadActor("1.lua")..{
		OnCommand=cmd(addx,-128;addy,-192)
	};
	LoadActor("1.lua")..{
		OnCommand=cmd(addx,-128;addy,-96)
	};
	LoadActor("1.lua")..{
		OnCommand=cmd()
	};
}
local WDX2 if SCREEN_WIDTH > 640 then WDX2 = -80/1.5 else WDX2 = 0 end;
return Def.ActorFrame{
	LoseFocusCommand=function(self)
		self:RunCommandsOnChildren(function(child) child:visible(false):finishtweening() end, {})
	end,
	LoadActor("1.png")..{
		OnCommand=cmd(Center;SetSize,640,480)
	};
	LoadActor("1.png")..{
		OnCommand=cmd(Center;SetSize,640,480;addx,640;zoomx,-1)
	};
	LoadActor("1.png")..{
		OnCommand=cmd(Center;SetSize,640,480;addx,-640;zoomx,-1)
	},
		LoadActor("../Sprites/Line/5x1", "Rhombus 5x1.png")..{
		OnCommand=function(self)
			self:effectclock('beat')
		end
	},
}